Option Strict On
Option Explicit On 

Imports System.DirectoryServices
Imports System.Data.OleDb
Imports System.DirectoryServices.Interop

Module General
	' Listing 7-1
	Public Sub BindToUserManObjectInAD()
		Dim objEntry As DirectoryEntry

		objEntry = New DirectoryEntry("LDAP://CN=UserMan,CN=Users,DC=userman,DC=com", "Administrator", "adminpwd")
	End Sub

	' Listing 7-2
	Public Sub SearchForSpecificObjectInAD()
		Dim objEntry As DirectoryEntry
		Dim objSearcher As DirectorySearcher
		Dim objSearchResult As SearchResult

		' Instantiate and bind to Users node in AD
		objEntry = New DirectoryEntry("LDAP://CN=Users,DC=userman,DC=com", "UserMan", "userman")

		' Set up to search for UserMan on the Users node
		objSearcher = New DirectorySearcher(objEntry, "(&(objectClass=user)(objectCategory=person)(userPrincipalName=userman@userman.com))")

		' Find the user
		objSearchResult = objSearcher.FindOne()

		' Check if the user was found
		If Not objSearchResult Is Nothing Then
			' Display path for user
			MsgBox("Users Path: " & objSearchResult.Path)
		Else
			MsgBox("User not found!")
		End If
	End Sub

	' Listing 7-3
	Public Sub SearchForAllUserObjectsInAD()
		Dim objEntry As DirectoryEntry
		Dim objSearcher As DirectorySearcher
		Dim objSearchResult As SearchResult
		Dim objSearchResults As SearchResultCollection

		' Instantiate and bind to root node in AD
		objEntry = New DirectoryEntry("LDAP://DC=userman,DC=com", "UserMan", "userman")

		' Set up to search for UserMan on the Users node
		objSearcher = New DirectorySearcher(objEntry, "(&(objectClass=user)(objectCategory=person))")

		' Find all objects of class user
		objSearchResults = objSearcher.FindAll()

		' Check if any users were found
		If Not objSearchResults Is Nothing Then
			' Loop through all users returned
			For Each objSearchResult In objSearchResults
				' Display path for user
				MsgBox("Users Path: " & objSearchResult.Path)
			Next
		Else
			MsgBox("No users were found!")
		End If
	End Sub

	' Listing 7-4
	Public Sub ReturnNonDefaultNodeProperties()
		Dim objEntry As DirectoryEntry
		Dim objSearcher As DirectorySearcher
		Dim objSearchResult As SearchResult
		Dim objProperty As DictionaryEntry

		' Instantiate and bind to Users node in AD
		objEntry = New DirectoryEntry("LDAP://CN=Users,DC=userman,DC=com", "UserMan", "userman")

		' Set up to search for UserMan on the Users node
		objSearcher = New DirectorySearcher(objEntry, "(&(objectClass=user)(objectCategory=person)(userPrincipalName=userman@userman.com))", New String(2) {"sn", "telephoneNumber", "givenName"})

		' Find the user
		objSearchResult = objSearcher.FindOne()

		' Check if the user was found
		If Not objSearchResult Is Nothing Then
			' Display user properties
			For Each objProperty In objSearchResult.Properties
				MsgBox(objProperty.Key.ToString)
			Next
		Else
			MsgBox("User not found!")
		End If
	End Sub

	' Listing 7-5
	Public Sub EditUserProperty()
		Dim objEntry As DirectoryEntry
		Dim objPropertyValues As PropertyValueCollection

		' Bind to UserMan user object
		objEntry = New DirectoryEntry("LDAP://CN=UserMan,CN=Users,DC=userman,DC=com", "Administrator", "adminpwd")

		' Change the e-mail address for the user
		objEntry.Properties("mail")(0) = "userman@userman.com"
		' Commit the changes to the AD database
		objEntry.CommitChanges()
	End Sub

	' Listing 7-6
	Public Sub AddNewUserProperty()
		Dim objEntry As DirectoryEntry
		Dim objPropertyValues As PropertyValueCollection

		' Bind to UserMan user object
		objEntry = New DirectoryEntry("LDAP://CN=UserMan,CN=Users,DC=userman,DC=com", "Administrator", "adminpwd")

		' Add new e-mail address
		objEntry.Properties("mail").Add("userman@userman.com")
		' Commit the changes to the AD database
		objEntry.CommitChanges()
	End Sub

	' Listing 7-7
	Public Sub AccessADWithOleDb()
		Dim cnnAD As OleDbConnection
		Dim cmmAD As OleDbCommand
		Dim drdAD As OleDbDataReader

		' Instantiate and open connection
		cnnAD = New OleDbConnection("Provider=ADsDSOObject;User Id=UserMan;Password=userman")
		cnnAD.Open()
		' Instantiate command
		cmmAD = New OleDbCommand("SELECT cn, AdsPath FROM 'LDAP://userman.com' WHERE objectCategory='person' AND objectClass='user' AND cn='UserMan'", cnnAD)

		' Retrieve rows in data reader
		drdAD = cmmAD.ExecuteReader()
	End Sub

	' Listing 7-8
	Public Sub GetSIDAndSAMAccountNameFromAD()
		Dim cnnAD As OleDbConnection
		Dim cmmAD As OleDbCommand
		Dim drdAD As OleDbDataReader
		Dim strSAMAccountName As String
		Dim strSID As String

		' Instantiate and open connection
		cnnAD = New OleDbConnection("Provider=ADsDSOObject;User Id=UserMan;Password=userman")
		cnnAD.Open()
		' Instantiate command
		cmmAD = New OleDbCommand("SELECT objectSid, samAccountName FROM 'LDAP://userman.com' WHERE objectCategory='person' AND objectClass='user' AND cn='UserMan'", cnnAD)

		' Retrieve rows in data reader
		drdAD = cmmAD.ExecuteReader()
		' Go to first row
		drdAD.Read()
		' Get SAM Account name
		strSAMAccountName = drdAD("samAccountName").ToString
		' Get SID
		strSID = drdAD("objectSid").ToString
	End Sub
End Module