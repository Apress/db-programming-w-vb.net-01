Imports System.Data.SqlClient

Module General
	Private Const PR_STR_CONNECTION_STRING As String = "Data Source=USERMANPC;" & _
	 "User ID=UserMan;Password=userman;Initial Catalog=UserMan"

	' Listing 6-8
	Public Sub TestUpdateTrigger()
		Const STR_SQL_USER_SELECT As String = "SELECT * FROM tblUser"
		Const STR_SQL_USER_DELETE As String = "DELETE FROM tblUser WHERE Id=@Id"
		Const STR_SQL_USER_INSERT As String = "INSERT INTO tblUser(FirstName, LastName, LoginName) VALUES(@FirstName, @LastName, @LoginName)"
		Const STR_SQL_USER_UPDATE As String = "UPDATE tblUser SET FirstName=@FirstName, LastName=@LastName, LoginName=@LoginName WHERE Id=@Id"

		Dim cnnUserMan As SqlConnection
		Dim cmmUser As SqlCommand
		Dim dadUser As SqlDataAdapter
		Dim dstUser As DataSet

		Dim cmmUserSelect As SqlCommand
		Dim cmmUserDelete As SqlCommand
		Dim cmmUserInsert As SqlCommand
		Dim cmmUserUpdate As SqlCommand

		Dim prmSQLDelete, prmSQLUpdate, prmSQLInsert As SqlParameter

		' Instantiate and open the connection
		cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
		cnnUserMan.Open()

		' Instantiate and initialize command
		cmmUser = New SqlCommand("SELECT * FROM tblUser", cnnUserMan)
		' Instantiate the commands
		cmmUserSelect = New SqlCommand(STR_SQL_USER_SELECT, cnnUserMan)
		cmmUserDelete = New SqlCommand(STR_SQL_USER_DELETE, cnnUserMan)
		cmmUserInsert = New SqlCommand(STR_SQL_USER_INSERT, cnnUserMan)
		cmmUserUpdate = New SqlCommand(STR_SQL_USER_UPDATE, cnnUserMan)
		' Instantiate command and data set
		cmmUser = New SqlCommand(STR_SQL_USER_SELECT, cnnUserMan)
		dstUser = New DataSet()

		dadUser = New SqlDataAdapter()
		dadUser.SelectCommand = cmmUserSelect
		dadUser.InsertCommand = cmmUserInsert
		dadUser.DeleteCommand = cmmUserDelete
		dadUser.UpdateCommand = cmmUserUpdate

		' Add parameters
		cmmUserDelete.Parameters.Add("@FirstName", SqlDbType.VarChar, 50, "FirstName")
		cmmUserDelete.Parameters.Add("@LastName", SqlDbType.VarChar, 50, "LastName")
		cmmUserDelete.Parameters.Add("@LoginName", SqlDbType.VarChar, 50, "LoginName")
		prmSQLDelete = dadUser.DeleteCommand.Parameters.Add("@Id", SqlDbType.Int, 0, "Id")
		prmSQLDelete.Direction = ParameterDirection.Input
		prmSQLDelete.SourceVersion = DataRowVersion.Original

		cmmUserUpdate.Parameters.Add("@FirstName", SqlDbType.VarChar, 50, "FirstName")
		cmmUserUpdate.Parameters.Add("@LastName", SqlDbType.VarChar, 50, "LastName")
		cmmUserUpdate.Parameters.Add("@LoginName", SqlDbType.VarChar, 50, "LoginName")
		prmSQLUpdate = dadUser.UpdateCommand.Parameters.Add("@Id", SqlDbType.Int, 0, "Id")
		prmSQLUpdate.Direction = ParameterDirection.Input
		prmSQLUpdate.SourceVersion = DataRowVersion.Original

		cmmUserInsert.Parameters.Add("@FirstName", SqlDbType.VarChar, 50, "FirstName")
		cmmUserInsert.Parameters.Add("@LastName", SqlDbType.VarChar, 50, "LastName")
		cmmUserInsert.Parameters.Add("@LoginName", SqlDbType.VarChar, 50, "LoginName")

		' Populate the data set from the view
		dadUser.Fill(dstUser, "tblUser")

		' Change the name of user in the second row
		dstUser.Tables("tblUser").Rows(1)("LastName") = "Thomsen"
		dstUser.Tables("tblUser").Rows(1)("FirstName") = Nothing

		Try
			' Propagate changes back to the data source
			dadUser.Update(dstUser, "tblUser")
		Catch objE As Exception
			MsgBox(objE.Message)
		End Try
	End Sub
End Module