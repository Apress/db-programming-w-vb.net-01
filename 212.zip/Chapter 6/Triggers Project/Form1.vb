Public Class Form1
	Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

	Public Sub New()
		MyBase.New()

		'This call is required by the Windows Form Designer.
		InitializeComponent()

		'Add any initialization after the InitializeComponent() call

	End Sub

	'Form overrides dispose to clean up the component list.
	Public Overrides Sub Dispose()
		MyBase.Dispose()
		If Not (components Is Nothing) Then
			components.Dispose()
		End If
	End Sub
	Private WithEvents btnTestUpdateTrigger As System.Windows.Forms.Button

	'Required by the Windows Form Designer
	Private components As System.ComponentModel.Container

	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.  
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
		Me.btnTestUpdateTrigger = New System.Windows.Forms.Button()
		Me.SuspendLayout()
		'
		'btnTestUpdateTrigger
		'
		Me.btnTestUpdateTrigger.Location = New System.Drawing.Point(51, 173)
		Me.btnTestUpdateTrigger.Name = "btnTestUpdateTrigger"
		Me.btnTestUpdateTrigger.Size = New System.Drawing.Size(154, 23)
		Me.btnTestUpdateTrigger.TabIndex = 0
		Me.btnTestUpdateTrigger.Text = "Test Update Trigger"
		'
		'Form1
		'
		Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
		Me.ClientSize = New System.Drawing.Size(271, 273)
		Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnTestUpdateTrigger})
		Me.Name = "Form1"
		Me.Text = "Triggers Project"
		Me.ResumeLayout(False)

	End Sub

#End Region

	Private Sub btnTestUpdateTrigger_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTestUpdateTrigger.Click
		TestUpdateTrigger()
	End Sub
End Class
