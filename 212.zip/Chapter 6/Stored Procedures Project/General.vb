Option Strict On
Option Explicit On 

Imports System.Data.SqlClient

Module General
	Private Const PR_STR_CONNECTION_STRING As String = "Data Source=USERMANPC;" & _
	 "User ID=UserMan;Password=userman;Initial Catalog=UserMan"

	' Listing 6-1
	Public Sub ExecuteSimpleSP()
		Dim cnnUserMan As SqlConnection
		Dim cmmUser As SqlCommand
		Dim lngNumUsers As Long

		' Instantiate and open the connection
		cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
		cnnUserMan.Open()

		' Instantiate and initialize command
		cmmUser = New SqlCommand("SimpleStoredProcedure", cnnUserMan)
		cmmUser.CommandType = CommandType.StoredProcedure

		lngNumUsers = CLng(cmmUser.ExecuteScalar)
		MsgBox(lngNumUsers.ToString)
	End Sub

	' Listing 6-2
	Public Sub ExecuteSimpleRowReturningSP()
		Dim cnnUserMan As SqlConnection
		Dim cmmUser As SqlCommand
		Dim drdUser As SqlDataReader

		' Instantiate and open the connection
		cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
		cnnUserMan.Open()

		' Instantiate and initialize command
		cmmUser = New SqlCommand("uspGetUsers", cnnUserMan)
		cmmUser.CommandType = CommandType.StoredProcedure

		' Retrieve all user rows
		drdUser = cmmUser.ExecuteReader()
	End Sub

	' Listing 6-3
	Public Sub GetUsersByLastName()
		Dim cnnUserMan As SqlConnection
		Dim cmmUser As SqlCommand
		Dim drdUser As SqlDataReader
		Dim prmLastName As SqlParameter

		' Instantiate and open the connection
		cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
		cnnUserMan.Open()

		' Instantiate and initialize command
		cmmUser = New SqlCommand("uspGetUsersByLastName", cnnUserMan)
		cmmUser.CommandType = CommandType.StoredProcedure
		' Instantiate, initialize and add parameter to command
		prmLastName = cmmUser.Parameters.Add("@strLastName", SqlDbType.VarChar, 50)
		' Indicate this is an input parameter
		prmLastName.Direction = ParameterDirection.Input
		' Set the value of the parameter
		prmLastName.Value = "Doe"

		' Return all users with a last name of Doe
		drdUser = cmmUser.ExecuteReader()
	End Sub

	' Listing 6-4
	Public Sub GetUsersAndRights()
		Dim cnnUserMan As SqlConnection
		Dim cmmUser As SqlCommand
		Dim drdUser As SqlDataReader
		Dim prmNumRows As SqlParameter

		' Instantiate and open the connection
		cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
		cnnUserMan.Open()

		' Instantiate and initialize command
		cmmUser = New SqlCommand("uspGetUsersAndRights", cnnUserMan)
		cmmUser.CommandType = CommandType.StoredProcedure
		' Instantiate, initialize and add parameter to command
		prmNumRows = cmmUser.Parameters.Add("@lngNumRows", SqlDbType.Int)
		' Indicate this is an output parameter
		prmNumRows.Direction = ParameterDirection.Output
		' Get first batch of rows (users)
		drdUser = cmmUser.ExecuteReader()

		' Display the last name of all user rows
		Do While drdUser.Read()
			MsgBox(drdUser("LastName").ToString)
		Loop

		' Get next batch of rows (user rights)
		If drdUser.NextResult() Then
			' Display the id of all rights
			Do While drdUser.Read()
				MsgBox(drdUser("RightsId").ToString)
			Loop
		End If
	End Sub

	' Listing 6-5
	Public Sub GetRETURN_VALUE()
		Dim cnnUserMan As SqlConnection
		Dim cmmUser As SqlCommand
		Dim drdUser As SqlDataReader
		Dim prmNumRows As SqlParameter
		Dim lngResult As Long

		' Instantiate and open the connection
		cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
		cnnUserMan.Open()

		' Instantiate and initialize command
		cmmUser = New SqlCommand("uspGetRETURN_VALUE", cnnUserMan)
		cmmUser.CommandType = CommandType.StoredProcedure
		' Instantiate, initialize and add parameter to command
		prmNumRows = cmmUser.Parameters.Add("@RETURN_VALUE", SqlDbType.Int)
		' Indicate this is a return value parameter
		prmNumRows.Direction = ParameterDirection.ReturnValue
		' Get RETURN_VALUE
		lngResult = CLng(cmmUser.ExecuteScalar())
	End Sub
End Module