Public Class Form1
	Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

	Public Sub New()
		MyBase.New()

		'This call is required by the Windows Form Designer.
		InitializeComponent()

		'Add any initialization after the InitializeComponent() call

	End Sub

	'Form overrides dispose to clean up the component list.
	Public Overloads Overrides Sub Dispose()
		MyBase.Dispose()
		If Not (components Is Nothing) Then
			components.Dispose()
		End If
	End Sub
	Private WithEvents btnExecuteSimpleSP As System.Windows.Forms.Button
	Friend WithEvents btnExecuteSimpleRowReturningSP As System.Windows.Forms.Button
	Friend WithEvents btnGetUserByLastName As System.Windows.Forms.Button
	Friend WithEvents btnGetUsersAndRights As System.Windows.Forms.Button
	Friend WithEvents btnGetRETURN_VALUE As System.Windows.Forms.Button

	'Required by the Windows Form Designer
	Private components As System.ComponentModel.Container

	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.  
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
		Me.btnExecuteSimpleSP = New System.Windows.Forms.Button()
		Me.btnExecuteSimpleRowReturningSP = New System.Windows.Forms.Button()
		Me.btnGetUserByLastName = New System.Windows.Forms.Button()
		Me.btnGetUsersAndRights = New System.Windows.Forms.Button()
		Me.btnGetRETURN_VALUE = New System.Windows.Forms.Button()
		Me.SuspendLayout()
		'
		'btnExecuteSimpleSP
		'
		Me.btnExecuteSimpleSP.Location = New System.Drawing.Point(23, 166)
		Me.btnExecuteSimpleSP.Name = "btnExecuteSimpleSP"
		Me.btnExecuteSimpleSP.Size = New System.Drawing.Size(119, 23)
		Me.btnExecuteSimpleSP.TabIndex = 0
		Me.btnExecuteSimpleSP.Text = "Execute Simple SP"
		'
		'btnExecuteSimpleRowReturningSP
		'
		Me.btnExecuteSimpleRowReturningSP.Location = New System.Drawing.Point(150, 166)
		Me.btnExecuteSimpleRowReturningSP.Name = "btnExecuteSimpleRowReturningSP"
		Me.btnExecuteSimpleRowReturningSP.Size = New System.Drawing.Size(188, 23)
		Me.btnExecuteSimpleRowReturningSP.TabIndex = 0
		Me.btnExecuteSimpleRowReturningSP.Text = "Execute Simple Row Returning SP"
		'
		'btnGetUserByLastName
		'
		Me.btnGetUserByLastName.Location = New System.Drawing.Point(346, 166)
		Me.btnGetUserByLastName.Name = "btnGetUserByLastName"
		Me.btnGetUserByLastName.Size = New System.Drawing.Size(188, 23)
		Me.btnGetUserByLastName.TabIndex = 0
		Me.btnGetUserByLastName.Text = "Get Users by Last Name"
		'
		'btnGetUsersAndRights
		'
		Me.btnGetUsersAndRights.Location = New System.Drawing.Point(346, 196)
		Me.btnGetUsersAndRights.Name = "btnGetUsersAndRights"
		Me.btnGetUsersAndRights.Size = New System.Drawing.Size(188, 23)
		Me.btnGetUsersAndRights.TabIndex = 0
		Me.btnGetUsersAndRights.Text = "Get Users and Rights"
		'
		'btnGetRETURN_VALUE
		'
		Me.btnGetRETURN_VALUE.Location = New System.Drawing.Point(346, 226)
		Me.btnGetRETURN_VALUE.Name = "btnGetRETURN_VALUE"
		Me.btnGetRETURN_VALUE.Size = New System.Drawing.Size(188, 23)
		Me.btnGetRETURN_VALUE.TabIndex = 0
		Me.btnGetRETURN_VALUE.Text = "Get RETURN_VALUE"
		'
		'Form1
		'
		Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
		Me.ClientSize = New System.Drawing.Size(550, 273)
		Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnGetRETURN_VALUE, Me.btnGetUsersAndRights, Me.btnGetUserByLastName, Me.btnExecuteSimpleRowReturningSP, Me.btnExecuteSimpleSP})
		Me.Name = "Form1"
		Me.Text = "Stored Procedures Project"
		Me.ResumeLayout(False)

	End Sub

#End Region

	Private Sub btnExecuteSimpleSP_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExecuteSimpleSP.Click
		ExecuteSimpleSP()
	End Sub

	Private Sub btnExecuteSimpleRowReturningSP_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExecuteSimpleRowReturningSP.Click
		ExecuteSimpleRowReturningSP()
	End Sub

	Private Sub btnGetUserByLastName_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGetUserByLastName.Click
		GetUsersByLastName()
	End Sub

	Private Sub btnGetUsersAndRights_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGetUsersAndRights.Click
		GetUsersAndRights()
	End Sub

	Private Sub btnGetRETURN_VALUE_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGetRETURN_VALUE.Click
		GetRETURN_VALUE()
	End Sub
End Class
