Public Class Form1
	Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

	Public Sub New()
		MyBase.New()

		'This call is required by the Windows Form Designer.
		InitializeComponent()

		'Add any initialization after the InitializeComponent() call

	End Sub

	'Form overrides dispose to clean up the component list.
	Public Overrides Sub Dispose()
		MyBase.Dispose()
		If Not (components Is Nothing) Then
			components.Dispose()
		End If
	End Sub
	Private WithEvents btnRetrieveRowsFromView As System.Windows.Forms.Button
	Friend WithEvents btnManipulateDataFromSingleTable As System.Windows.Forms.Button

	'Required by the Windows Form Designer
	Private components As System.ComponentModel.Container

	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.  
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
		Me.btnManipulateDataFromSingleTable = New System.Windows.Forms.Button()
		Me.btnRetrieveRowsFromView = New System.Windows.Forms.Button()
		Me.SuspendLayout()
		'
		'btnManipulateDataFromSingleTable
		'
		Me.btnManipulateDataFromSingleTable.Location = New System.Drawing.Point(174, 212)
		Me.btnManipulateDataFromSingleTable.Name = "btnManipulateDataFromSingleTable"
		Me.btnManipulateDataFromSingleTable.Size = New System.Drawing.Size(187, 23)
		Me.btnManipulateDataFromSingleTable.TabIndex = 0
		Me.btnManipulateDataFromSingleTable.Text = "Manipulate Data from Single Table"
		'
		'btnRetrieveRowsFromView
		'
		Me.btnRetrieveRowsFromView.Location = New System.Drawing.Point(16, 212)
		Me.btnRetrieveRowsFromView.Name = "btnRetrieveRowsFromView"
		Me.btnRetrieveRowsFromView.Size = New System.Drawing.Size(151, 23)
		Me.btnRetrieveRowsFromView.TabIndex = 0
		Me.btnRetrieveRowsFromView.Text = "Retrieve Rows From View"
		'
		'Form1
		'
		Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
		Me.ClientSize = New System.Drawing.Size(378, 273)
		Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnManipulateDataFromSingleTable, Me.btnRetrieveRowsFromView})
		Me.Name = "Form1"
		Me.Text = "Views Project"
		Me.ResumeLayout(False)

	End Sub

#End Region

	Private Sub btnRetrieveRowsFromView_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRetrieveRowsFromView.Click
		RetrieveRowsFromView()
	End Sub

	Private Sub btnManipulateDataFromSingleTable_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnManipulateDataFromSingleTable.Click
		ManipulatingDataInAViewBasedOnSingleTable()
	End Sub
End Class
