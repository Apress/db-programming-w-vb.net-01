Public Class frmUser
	Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

	Public Sub New()
		MyBase.New()

		'This call is required by the Windows Form Designer.
		InitializeComponent()

		'Add any initialization after the InitializeComponent() call

	End Sub

	'Form overrides dispose to clean up the component list.
	Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
		If disposing Then
			If Not (components Is Nothing) Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(disposing)
	End Sub
	Friend WithEvents OleDbSelectCommand1 As System.Data.OleDb.OleDbCommand
	Friend WithEvents OleDbInsertCommand1 As System.Data.OleDb.OleDbCommand
	Friend WithEvents OleDbUpdateCommand1 As System.Data.OleDb.OleDbCommand
	Friend WithEvents OleDbDeleteCommand1 As System.Data.OleDb.OleDbCommand
	Friend WithEvents objUser As WinForm_Data_Bound_Controls_Project.User
	Friend WithEvents OleDbConnection1 As System.Data.OleDb.OleDbConnection
	Friend WithEvents OleDbDataAdapter1 As System.Data.OleDb.OleDbDataAdapter
	Friend WithEvents btnLoad As System.Windows.Forms.Button
	Friend WithEvents btnUpdate As System.Windows.Forms.Button
	Friend WithEvents btnCancelAll As System.Windows.Forms.Button
	Friend WithEvents mfp_lblId As System.Windows.Forms.Label
	Friend WithEvents mfp_lblADName As System.Windows.Forms.Label
	Friend WithEvents mfp_lblFirstName As System.Windows.Forms.Label
	Friend WithEvents mfp_editId As System.Windows.Forms.TextBox
	Friend WithEvents mfp_editADName As System.Windows.Forms.TextBox
	Friend WithEvents mfp_editFirstName As System.Windows.Forms.TextBox
	Friend WithEvents mfp_lblLastName As System.Windows.Forms.Label
	Friend WithEvents mfp_lblLoginName As System.Windows.Forms.Label
	Friend WithEvents mfp_lblPassword As System.Windows.Forms.Label
	Friend WithEvents mfp_editLastName As System.Windows.Forms.TextBox
	Friend WithEvents mfp_editLoginName As System.Windows.Forms.TextBox
	Friend WithEvents mfp_editPassword As System.Windows.Forms.TextBox
	Friend WithEvents mfp_btnNavFirst As System.Windows.Forms.Button
	Friend WithEvents mfp_btnNavPrev As System.Windows.Forms.Button
	Friend WithEvents mfp_lblNavLocation As System.Windows.Forms.Label
	Friend WithEvents mfp_btnNavNext As System.Windows.Forms.Button
	Friend WithEvents mfp_btnNavLast As System.Windows.Forms.Button
	Friend WithEvents mfp_btnAdd As System.Windows.Forms.Button
	Friend WithEvents mfp_btnDelete As System.Windows.Forms.Button
	Friend WithEvents mfp_btnCancel As System.Windows.Forms.Button

	'Required by the Windows Form Designer
	Private components As System.ComponentModel.Container

	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.  
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
		Me.mfp_editLastName = New System.Windows.Forms.TextBox()
		Me.objUser = New WinForm_Data_Bound_Controls_Project.User()
		Me.btnUpdate = New System.Windows.Forms.Button()
		Me.OleDbSelectCommand1 = New System.Data.OleDb.OleDbCommand()
		Me.OleDbConnection1 = New System.Data.OleDb.OleDbConnection()
		Me.mfp_lblNavLocation = New System.Windows.Forms.Label()
		Me.mfp_btnNavPrev = New System.Windows.Forms.Button()
		Me.mfp_btnCancel = New System.Windows.Forms.Button()
		Me.mfp_btnNavLast = New System.Windows.Forms.Button()
		Me.mfp_lblFirstName = New System.Windows.Forms.Label()
		Me.mfp_btnDelete = New System.Windows.Forms.Button()
		Me.btnCancelAll = New System.Windows.Forms.Button()
		Me.OleDbUpdateCommand1 = New System.Data.OleDb.OleDbCommand()
		Me.mfp_lblPassword = New System.Windows.Forms.Label()
		Me.mfp_editPassword = New System.Windows.Forms.TextBox()
		Me.mfp_btnNavNext = New System.Windows.Forms.Button()
		Me.mfp_lblLoginName = New System.Windows.Forms.Label()
		Me.btnLoad = New System.Windows.Forms.Button()
		Me.mfp_editLoginName = New System.Windows.Forms.TextBox()
		Me.mfp_lblLastName = New System.Windows.Forms.Label()
		Me.mfp_btnNavFirst = New System.Windows.Forms.Button()
		Me.mfp_editFirstName = New System.Windows.Forms.TextBox()
		Me.OleDbDeleteCommand1 = New System.Data.OleDb.OleDbCommand()
		Me.mfp_lblADName = New System.Windows.Forms.Label()
		Me.mfp_lblId = New System.Windows.Forms.Label()
		Me.mfp_editId = New System.Windows.Forms.TextBox()
		Me.mfp_btnAdd = New System.Windows.Forms.Button()
		Me.mfp_editADName = New System.Windows.Forms.TextBox()
		Me.OleDbDataAdapter1 = New System.Data.OleDb.OleDbDataAdapter()
		Me.OleDbInsertCommand1 = New System.Data.OleDb.OleDbCommand()
		CType(Me.objUser, System.ComponentModel.ISupportInitialize).BeginInit()
		Me.SuspendLayout()
		'
		'mfp_editLastName
		'
		Me.mfp_editLastName.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.objUser, "tblUser.LastName"))
		Me.mfp_editLastName.Location = New System.Drawing.Point(340, 76)
		Me.mfp_editLastName.Name = "mfp_editLastName"
		Me.mfp_editLastName.TabIndex = 12
		Me.mfp_editLastName.Text = ""
		'
		'objUser
		'
		Me.objUser.DataSetName = "User"
		Me.objUser.Locale = New System.Globalization.CultureInfo("en-US")
		Me.objUser.Namespace = "http://www.tempuri.org/User.xsd"
		'
		'btnUpdate
		'
		Me.btnUpdate.Location = New System.Drawing.Point(365, 10)
		Me.btnUpdate.Name = "btnUpdate"
		Me.btnUpdate.TabIndex = 1
		Me.btnUpdate.Text = "&Update"
		'
		'OleDbSelectCommand1
		'
		Me.OleDbSelectCommand1.CommandText = "SELECT Id, ADName, ADSID, FirstName, LastName, LoginName, Password FROM tblUser"
		Me.OleDbSelectCommand1.Connection = Me.OleDbConnection1
		'
		'OleDbConnection1
		'
		Me.OleDbConnection1.ConnectionString = "Provider=SQLOLEDB.1;Password=userman;Persist Security Info=True;User ID=UserMan;" & _
		 "Initial Catalog=UserMan;Data Source=USERMANPC;Use Procedure for Prepare=1;" & _
		 "Auto Translate=True;Packet Size=4096;Workstation ID=USERMANPC;Use Encryption " & _
		 "for Data=False;Tag with column collation when possible=False"
		'
		'mfp_lblNavLocation
		'
		Me.mfp_lblNavLocation.BackColor = System.Drawing.Color.White
		Me.mfp_lblNavLocation.Location = New System.Drawing.Point(270, 175)
		Me.mfp_lblNavLocation.Name = "mfp_lblNavLocation"
		Me.mfp_lblNavLocation.Size = New System.Drawing.Size(95, 23)
		Me.mfp_lblNavLocation.TabIndex = 17
		Me.mfp_lblNavLocation.Text = "No Records"
		Me.mfp_lblNavLocation.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		'
		'mfp_btnNavPrev
		'
		Me.mfp_btnNavPrev.Location = New System.Drawing.Point(235, 175)
		Me.mfp_btnNavPrev.Name = "mfp_btnNavPrev"
		Me.mfp_btnNavPrev.Size = New System.Drawing.Size(35, 23)
		Me.mfp_btnNavPrev.TabIndex = 16
		Me.mfp_btnNavPrev.Text = "<"
		'
		'mfp_btnCancel
		'
		Me.mfp_btnCancel.Location = New System.Drawing.Point(365, 208)
		Me.mfp_btnCancel.Name = "mfp_btnCancel"
		Me.mfp_btnCancel.TabIndex = 22
		Me.mfp_btnCancel.Text = "&Cancel"
		'
		'mfp_btnNavLast
		'
		Me.mfp_btnNavLast.Location = New System.Drawing.Point(400, 175)
		Me.mfp_btnNavLast.Name = "mfp_btnNavLast"
		Me.mfp_btnNavLast.Size = New System.Drawing.Size(40, 23)
		Me.mfp_btnNavLast.TabIndex = 19
		Me.mfp_btnNavLast.Text = ">>"
		'
		'mfp_lblFirstName
		'
		Me.mfp_lblFirstName.Location = New System.Drawing.Point(10, 142)
		Me.mfp_lblFirstName.Name = "mfp_lblFirstName"
		Me.mfp_lblFirstName.TabIndex = 5
		Me.mfp_lblFirstName.Text = "FirstName"
		'
		'mfp_btnDelete
		'
		Me.mfp_btnDelete.Location = New System.Drawing.Point(280, 208)
		Me.mfp_btnDelete.Name = "mfp_btnDelete"
		Me.mfp_btnDelete.TabIndex = 21
		Me.mfp_btnDelete.Text = "&Delete"
		'
		'btnCancelAll
		'
		Me.btnCancelAll.Location = New System.Drawing.Point(365, 43)
		Me.btnCancelAll.Name = "btnCancelAll"
		Me.btnCancelAll.TabIndex = 2
		Me.btnCancelAll.Text = "Ca&ncel All"
		'
		'OleDbUpdateCommand1
		'
		Me.OleDbUpdateCommand1.CommandText = "UPDATE tblUser SET ADName = ?, ADSID = ?, FirstName = ?, LastName = ?, LoginName " & _
		"= ?, Password = ? WHERE (Id = ?) AND (ADName = ? OR ? IS NULL AND ADName IS NULL" & _
		") AND (ADSID = ? OR ? IS NULL AND ADSID IS NULL) AND (FirstName = ? OR ? IS NULL" & _
		" AND FirstName IS NULL) AND (LastName = ? OR ? IS NULL AND LastName IS NULL) AND" & _
		" (LoginName = ?) AND (Password = ?); SELECT Id, ADName, ADSID, FirstName, LastNa" & _
		"me, LoginName, Password FROM tblUser WHERE (Id = ?)"
		Me.OleDbUpdateCommand1.Connection = Me.OleDbConnection1
		Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("ADName", System.Data.OleDb.OleDbType.VarChar, 100, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "ADName", System.Data.DataRowVersion.Current, Nothing))
		Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("ADSID", System.Data.OleDb.OleDbType.Guid, 16, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "ADSID", System.Data.DataRowVersion.Current, Nothing))
		Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("FirstName", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "FirstName", System.Data.DataRowVersion.Current, Nothing))
		Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("LastName", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "LastName", System.Data.DataRowVersion.Current, Nothing))
		Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("LoginName", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "LoginName", System.Data.DataRowVersion.Current, Nothing))
		Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Password", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Password", System.Data.DataRowVersion.Current, Nothing))
		Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_Id", System.Data.OleDb.OleDbType.Integer, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Id", System.Data.DataRowVersion.Original, Nothing))
		Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_ADName", System.Data.OleDb.OleDbType.VarChar, 100, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "ADName", System.Data.DataRowVersion.Original, Nothing))
		Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_ADName1", System.Data.OleDb.OleDbType.VarChar, 100, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "ADName", System.Data.DataRowVersion.Original, Nothing))
		Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_ADSID", System.Data.OleDb.OleDbType.Guid, 16, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "ADSID", System.Data.DataRowVersion.Original, Nothing))
		Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_ADSID1", System.Data.OleDb.OleDbType.Guid, 16, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "ADSID", System.Data.DataRowVersion.Original, Nothing))
		Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_FirstName", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "FirstName", System.Data.DataRowVersion.Original, Nothing))
		Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_FirstName1", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "FirstName", System.Data.DataRowVersion.Original, Nothing))
		Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_LastName", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "LastName", System.Data.DataRowVersion.Original, Nothing))
		Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_LastName1", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "LastName", System.Data.DataRowVersion.Original, Nothing))
		Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_LoginName", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "LoginName", System.Data.DataRowVersion.Original, Nothing))
		Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_Password", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Password", System.Data.DataRowVersion.Original, Nothing))
		Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Select_Id", System.Data.OleDb.OleDbType.Integer, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Id", System.Data.DataRowVersion.Current, Nothing))
		'
		'mfp_lblPassword
		'
		Me.mfp_lblPassword.Location = New System.Drawing.Point(230, 142)
		Me.mfp_lblPassword.Name = "mfp_lblPassword"
		Me.mfp_lblPassword.TabIndex = 11
		Me.mfp_lblPassword.Text = "Password"
		'
		'mfp_editPassword
		'
		Me.mfp_editPassword.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.objUser, "tblUser.Password"))
		Me.mfp_editPassword.Location = New System.Drawing.Point(340, 142)
		Me.mfp_editPassword.Name = "mfp_editPassword"
		Me.mfp_editPassword.TabIndex = 14
		Me.mfp_editPassword.Text = ""
		'
		'mfp_btnNavNext
		'
		Me.mfp_btnNavNext.Location = New System.Drawing.Point(365, 175)
		Me.mfp_btnNavNext.Name = "mfp_btnNavNext"
		Me.mfp_btnNavNext.Size = New System.Drawing.Size(35, 23)
		Me.mfp_btnNavNext.TabIndex = 18
		Me.mfp_btnNavNext.Text = ">"
		'
		'mfp_lblLoginName
		'
		Me.mfp_lblLoginName.Location = New System.Drawing.Point(230, 109)
		Me.mfp_lblLoginName.Name = "mfp_lblLoginName"
		Me.mfp_lblLoginName.TabIndex = 10
		Me.mfp_lblLoginName.Text = "LoginName"
		'
		'btnLoad
		'
		Me.btnLoad.Location = New System.Drawing.Point(10, 10)
		Me.btnLoad.Name = "btnLoad"
		Me.btnLoad.TabIndex = 0
		Me.btnLoad.Text = "&Load"
		'
		'mfp_editLoginName
		'
		Me.mfp_editLoginName.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.objUser, "tblUser.LoginName"))
		Me.mfp_editLoginName.Location = New System.Drawing.Point(340, 109)
		Me.mfp_editLoginName.Name = "mfp_editLoginName"
		Me.mfp_editLoginName.TabIndex = 13
		Me.mfp_editLoginName.Text = ""
		'
		'mfp_lblLastName
		'
		Me.mfp_lblLastName.Location = New System.Drawing.Point(230, 76)
		Me.mfp_lblLastName.Name = "mfp_lblLastName"
		Me.mfp_lblLastName.TabIndex = 9
		Me.mfp_lblLastName.Text = "LastName"
		'
		'mfp_btnNavFirst
		'
		Me.mfp_btnNavFirst.Location = New System.Drawing.Point(195, 175)
		Me.mfp_btnNavFirst.Name = "mfp_btnNavFirst"
		Me.mfp_btnNavFirst.Size = New System.Drawing.Size(40, 23)
		Me.mfp_btnNavFirst.TabIndex = 15
		Me.mfp_btnNavFirst.Text = "<<"
		'
		'mfp_editFirstName
		'
		Me.mfp_editFirstName.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.objUser, "tblUser.FirstName"))
		Me.mfp_editFirstName.Location = New System.Drawing.Point(120, 142)
		Me.mfp_editFirstName.Name = "mfp_editFirstName"
		Me.mfp_editFirstName.TabIndex = 8
		Me.mfp_editFirstName.Text = ""
		'
		'OleDbDeleteCommand1
		'
		Me.OleDbDeleteCommand1.CommandText = "DELETE FROM tblUser WHERE (Id = ?) AND (ADName = ? OR ? IS NULL AND ADName IS NUL" & _
		"L) AND (ADSID = ? OR ? IS NULL AND ADSID IS NULL) AND (FirstName = ? OR ? IS NUL" & _
		"L AND FirstName IS NULL) AND (LastName = ? OR ? IS NULL AND LastName IS NULL) AN" & _
		"D (LoginName = ?) AND (Password = ?)"
		Me.OleDbDeleteCommand1.Connection = Me.OleDbConnection1
		Me.OleDbDeleteCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Id", System.Data.OleDb.OleDbType.Integer, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Id", System.Data.DataRowVersion.Original, Nothing))
		Me.OleDbDeleteCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("ADName", System.Data.OleDb.OleDbType.VarChar, 100, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "ADName", System.Data.DataRowVersion.Original, Nothing))
		Me.OleDbDeleteCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("ADName1", System.Data.OleDb.OleDbType.VarChar, 100, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "ADName", System.Data.DataRowVersion.Original, Nothing))
		Me.OleDbDeleteCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("ADSID", System.Data.OleDb.OleDbType.Guid, 16, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "ADSID", System.Data.DataRowVersion.Original, Nothing))
		Me.OleDbDeleteCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("ADSID1", System.Data.OleDb.OleDbType.Guid, 16, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "ADSID", System.Data.DataRowVersion.Original, Nothing))
		Me.OleDbDeleteCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("FirstName", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "FirstName", System.Data.DataRowVersion.Original, Nothing))
		Me.OleDbDeleteCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("FirstName1", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "FirstName", System.Data.DataRowVersion.Original, Nothing))
		Me.OleDbDeleteCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("LastName", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "LastName", System.Data.DataRowVersion.Original, Nothing))
		Me.OleDbDeleteCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("LastName1", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "LastName", System.Data.DataRowVersion.Original, Nothing))
		Me.OleDbDeleteCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("LoginName", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "LoginName", System.Data.DataRowVersion.Original, Nothing))
		Me.OleDbDeleteCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Password", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Password", System.Data.DataRowVersion.Original, Nothing))
		'
		'mfp_lblADName
		'
		Me.mfp_lblADName.Location = New System.Drawing.Point(10, 109)
		Me.mfp_lblADName.Name = "mfp_lblADName"
		Me.mfp_lblADName.TabIndex = 4
		Me.mfp_lblADName.Text = "ADName"
		'
		'mfp_lblId
		'
		Me.mfp_lblId.Location = New System.Drawing.Point(10, 76)
		Me.mfp_lblId.Name = "mfp_lblId"
		Me.mfp_lblId.TabIndex = 3
		Me.mfp_lblId.Text = "Id"
		'
		'mfp_editId
		'
		Me.mfp_editId.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.objUser, "tblUser.Id"))
		Me.mfp_editId.Location = New System.Drawing.Point(120, 76)
		Me.mfp_editId.Name = "mfp_editId"
		Me.mfp_editId.TabIndex = 6
		Me.mfp_editId.Text = ""
		'
		'mfp_btnAdd
		'
		Me.mfp_btnAdd.Location = New System.Drawing.Point(195, 208)
		Me.mfp_btnAdd.Name = "mfp_btnAdd"
		Me.mfp_btnAdd.TabIndex = 20
		Me.mfp_btnAdd.Text = "&Add"
		'
		'mfp_editADName
		'
		Me.mfp_editADName.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.objUser, "tblUser.ADName"))
		Me.mfp_editADName.Location = New System.Drawing.Point(120, 109)
		Me.mfp_editADName.Name = "mfp_editADName"
		Me.mfp_editADName.TabIndex = 7
		Me.mfp_editADName.Text = ""
		'
		'OleDbDataAdapter1
		'
		Me.OleDbDataAdapter1.DeleteCommand = Me.OleDbDeleteCommand1
		Me.OleDbDataAdapter1.InsertCommand = Me.OleDbInsertCommand1
		Me.OleDbDataAdapter1.SelectCommand = Me.OleDbSelectCommand1
		Me.OleDbDataAdapter1.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "tblUser", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("Id", "Id"), New System.Data.Common.DataColumnMapping("ADName", "ADName"), New System.Data.Common.DataColumnMapping("ADSID", "ADSID"), New System.Data.Common.DataColumnMapping("FirstName", "FirstName"), New System.Data.Common.DataColumnMapping("LastName", "LastName"), New System.Data.Common.DataColumnMapping("LoginName", "LoginName"), New System.Data.Common.DataColumnMapping("Password", "Password")})})
		Me.OleDbDataAdapter1.UpdateCommand = Me.OleDbUpdateCommand1
		'
		'OleDbInsertCommand1
		'
		Me.OleDbInsertCommand1.CommandText = "INSERT INTO tblUser(ADName, ADSID, FirstName, LastName, LoginName, Password) VALU" & _
		"ES (?, ?, ?, ?, ?, ?); SELECT Id, ADName, ADSID, FirstName, LastName, LoginName," & _
		" Password FROM tblUser WHERE (Id = @@IDENTITY)"
		Me.OleDbInsertCommand1.Connection = Me.OleDbConnection1
		Me.OleDbInsertCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("ADName", System.Data.OleDb.OleDbType.VarChar, 100, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "ADName", System.Data.DataRowVersion.Current, Nothing))
		Me.OleDbInsertCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("ADSID", System.Data.OleDb.OleDbType.Guid, 16, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "ADSID", System.Data.DataRowVersion.Current, Nothing))
		Me.OleDbInsertCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("FirstName", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "FirstName", System.Data.DataRowVersion.Current, Nothing))
		Me.OleDbInsertCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("LastName", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "LastName", System.Data.DataRowVersion.Current, Nothing))
		Me.OleDbInsertCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("LoginName", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "LoginName", System.Data.DataRowVersion.Current, Nothing))
		Me.OleDbInsertCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Password", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Password", System.Data.DataRowVersion.Current, Nothing))
		'
		'frmUser
		'
		Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
		Me.ClientSize = New System.Drawing.Size(442, 256)
		Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnLoad, Me.btnUpdate, Me.btnCancelAll, Me.mfp_lblId, Me.mfp_lblADName, Me.mfp_lblFirstName, Me.mfp_editId, Me.mfp_editADName, Me.mfp_editFirstName, Me.mfp_lblLastName, Me.mfp_lblLoginName, Me.mfp_lblPassword, Me.mfp_editLastName, Me.mfp_editLoginName, Me.mfp_editPassword, Me.mfp_btnNavFirst, Me.mfp_btnNavPrev, Me.mfp_lblNavLocation, Me.mfp_btnNavNext, Me.mfp_btnNavLast, Me.mfp_btnAdd, Me.mfp_btnDelete, Me.mfp_btnCancel})
		Me.Name = "frmUser"
		Me.Text = "WinForm Data Bound Controls Project"
		CType(Me.objUser, System.ComponentModel.ISupportInitialize).EndInit()
		Me.ResumeLayout(False)

	End Sub

#End Region

	Private Sub mfp_btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mfp_btnCancel.Click
		Me.BindingContext(objUser, "tblUser").CancelCurrentEdit()
		Me.objUser_PositionChanged()
	End Sub

	Private Sub mfp_btnDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mfp_btnDelete.Click
		If (Me.BindingContext(objUser, "tblUser").Count > 0) Then
			Me.BindingContext(objUser, "tblUser").RemoveAt(Me.BindingContext(objUser, "tblUser").Position)
			Me.objUser_PositionChanged()
		End If
	End Sub

	Private Sub mfp_btnAdd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mfp_btnAdd.Click
		Try
			'Clear out the current edits
			Me.BindingContext(objUser, "tblUser").EndCurrentEdit()
			Me.BindingContext(objUser, "tblUser").AddNew()
		Catch eEndEdit As System.Exception
			System.Windows.Forms.MessageBox.Show(eEndEdit.Message)
		End Try

		Me.objUser_PositionChanged()
	End Sub

	Private Sub btnUpdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUpdate.Click
		Try
			Me.UpdateDataSet()
		Catch eUpdate As System.Exception
			System.Windows.Forms.MessageBox.Show(eUpdate.Message)
		End Try
		Me.objUser_PositionChanged()
	End Sub

	Private Sub btnLoad_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLoad.Click
		Try
			Me.LoadDataSet()
		Catch eLoad As System.Exception
			System.Windows.Forms.MessageBox.Show(eLoad.Message)
		End Try

		Me.objUser_PositionChanged()
	End Sub

	Private Sub mfp_btnNavFirst_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mfp_btnNavFirst.Click
		Me.BindingContext(objUser, "tblUser").Position = 0
		Me.objUser_PositionChanged()
	End Sub

	Private Sub mfp_btnNavLast_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mfp_btnNavLast.Click
		Me.BindingContext(objUser, "tblUser").Position = (Me.objUser.Tables("tblUser").Rows.Count - 1)
		Me.objUser_PositionChanged()
	End Sub

	Private Sub mfp_btnNavPrev_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mfp_btnNavPrev.Click
		Me.BindingContext(objUser, "tblUser").Position = (Me.BindingContext(objUser, "tblUser").Position - 1)
		Me.objUser_PositionChanged()
	End Sub

	Private Sub mfp_btnNavNext_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mfp_btnNavNext.Click
		Me.BindingContext(objUser, "tblUser").Position = (Me.BindingContext(objUser, "tblUser").Position + 1)
		Me.objUser_PositionChanged()
	End Sub

	Private Sub objUser_PositionChanged()
		Me.mfp_lblNavLocation.Text = (((Me.BindingContext(objUser, "tblUser").Position + 1).ToString + " of  ") _
		  + Me.BindingContext(objUser, "tblUser").Count.ToString)
	End Sub

	Private Sub btnCancelAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancelAll.Click
		Me.objUser.RejectChanges()
	End Sub

	Public Sub UpdateDataSet()
		'Get a new dataset that holds only the changes that have been made to the main dataset
		Dim objDataSetChanges As WinForm_Data_Bound_Controls_Project.User = New WinForm_Data_Bound_Controls_Project.User()
		Dim objDataSetUpdated As System.Data.DataSet = New WinForm_Data_Bound_Controls_Project.User()

		'Clear out the current edits
		Me.BindingContext(objUser, "tblUser").EndCurrentEdit()
		'Get a new dataset that holds only the changes that have been made to the main dataset
		objDataSetChanges = CType(objUser.GetChanges, WinForm_Data_Bound_Controls_Project.User)

		'Check to see if the objCustomersDatasetChanges holds any records
		If (Not (objDataSetChanges) Is Nothing) Then
			Try
				'Call the update method passing inthe dataset and any parameters
				Me.UpdateDataSource(objDataSetChanges)
			Catch eUpdate As System.Exception
				'If the update failed and is part of a transaction, this is the place to put your rollback
				Throw eUpdate
			End Try

			'If the update succeeded and is part of a transaction, this is the place to put your commit
			'Add code to Check the returned dataset - objCustomersDataSetUpdate for any errors that may have been
			'pushed into the row object's error
			'Merge the returned changes back into the main dataset
			Try
				objUser.Merge(objDataSetUpdated)
			Catch eUpdateMerge As System.Exception
				'Add exception handling code here
				Throw eUpdateMerge
			End Try

			'Commit the changes that were just merged
			'This moves any rows marked as updated, inserted or changed to being marked as original values
			objUser.AcceptChanges()
		End If
	End Sub

	Public Sub LoadDataSet()
		Dim objDataSetTemp As WinForm_Data_Bound_Controls_Project.User

		objDataSetTemp = New WinForm_Data_Bound_Controls_Project.User()

		Try
			'Execute the SelectCommand on the DatasetCommmand and fill the dataset
			Me.FillDataSet(objDataSetTemp)
		Catch eFillDataSet As System.Exception
			'Add exception handling code here.
			Throw eFillDataSet
		End Try

		Try
			'Merge the records that were just pulled from the data store into the main dataset
			objUser.Merge(objDataSetTemp)
		Catch eLoadMerge As System.Exception
			'Add exception handling code here
			Throw eLoadMerge
		End Try
	End Sub

	Public Function UpdateDataSource(ByVal dataSet As WinForm_Data_Bound_Controls_Project.User) As System.Int32
		Me.OleDbConnection1.Open()

		Dim UpdatedRows As System.Data.DataSet
		Dim InsertedRows As System.Data.DataSet
		Dim DeletedRows As System.Data.DataSet
		Dim AffectedRows As Integer = 0

		UpdatedRows = dataSet.GetChanges(System.Data.DataRowState.Modified)
		InsertedRows = dataSet.GetChanges(System.Data.DataRowState.Added)
		DeletedRows = dataSet.GetChanges(System.Data.DataRowState.Deleted)

		Try
			If (Not (UpdatedRows) Is Nothing) Then
				AffectedRows = OleDbDataAdapter1.Update(UpdatedRows)
			End If

			If (Not (InsertedRows) Is Nothing) Then
				AffectedRows = (AffectedRows + OleDbDataAdapter1.Update(InsertedRows))
			End If

			If (Not (DeletedRows) Is Nothing) Then
				AffectedRows = (AffectedRows + OleDbDataAdapter1.Update(DeletedRows))
			End If
		Catch updateException As System.Exception
			Throw updateException
		Finally
			Me.OleDbConnection1.Close()
		End Try
	End Function

	Public Sub FillDataSet(ByVal dataSet As WinForm_Data_Bound_Controls_Project.User)
		Me.OleDbConnection1.Open()

		dataSet.EnforceConstraints = False

		Try
			Me.OleDbDataAdapter1.Fill(dataSet)
		Catch fillException As System.Exception
			Throw fillException
		Finally
			dataSet.EnforceConstraints = True
			Me.OleDbConnection1.Close()
		End Try
	End Sub
End Class