Module General
	' Listing 9-3-2
	Public Sub InstantiateMustInheritClass()
		'Dim objMustInherit As New CMustInherit()
	End Sub

	' Listing 9-4-2
	Public Sub InstantiateMustInheritClassWrapper()
		Dim objMustInherit As New CWrapper()
	End Sub

	' To be used with Listing 9-5
	Public Sub OverridePropertyInOverridableClass()
		Dim objOverridable As New CWrapper1()
	End Sub

	' Listing 9-1-1
	Public Interface IUserMan
		Property TestProperty() As String
		Sub TestMethod()
	End Interface

	' Listing 9-1-3
	Public Sub CreateUserManObject()
		Dim objUserMan As New CUserMan()
	End Sub
End Module
