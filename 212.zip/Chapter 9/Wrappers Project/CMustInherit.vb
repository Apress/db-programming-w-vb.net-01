' Listing 9-3-1
Public MustInherit Class CMustInherit
	Private prstrTest As String

	Public Property Test() As String
		Get
			Test = prstrTest
		End Get

		Set(ByVal vstrTest As String)
			prstrTest = vstrTest
		End Set
	End Property
End Class
