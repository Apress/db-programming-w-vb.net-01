Public Class CUser
	' Listing 9-6
	' User table column values
	Private prlngId As Long
	Private prstrADName As String
	Private prguiADSID As Guid
	Private prstrFirstName As String
	Private prstrLastName As String
	Private prstrLoginName As String
	Private prstrPassword As String

	' Listing 9-9
	' User table column max lengths
	Private prshtADNameMaxLen As Short
	Private prshtFirstNameMaxLen As Short
	Private prshtLastNameMaxLen As Short
	Private prshtLoginNameMaxLen As Short
	Private prshtPasswordMaxLen As Short

	' Listing 9-7
	Public ReadOnly Property Id() As Long
		Get
			Id = prlngId
		End Get
	End Property

	' Listing 9-8 & Listing 9-10
	Public Property ADName() As String
		Get
			ADName = prstrADName
		End Get

		Set(ByVal vstrADName As String)
			If Len(vstrADName) <= prshtADNameMaxLen Then
				prstrADName = vstrADName
			Else
				prstrADName = Left(vstrADName, prshtADNameMaxLen)
			End If
		End Set
	End Property

	Public Property ADSID() As Guid
		Get
			ADSID = prguiADSID
		End Get

		Set(ByVal vguiADSID As Guid)
			prguiADSID = vguiADSID
		End Set
	End Property

	Public Property FirstName() As String
		Get
			FirstName = prstrFirstName
		End Get

		Set(ByVal vstrFirstName As String)
			If Len(vstrFirstName) <= prshtFirstNameMaxLen Then
				prstrFirstName = vstrFirstName
			Else
				prstrFirstName = Left(vstrFirstName, prshtFirstNameMaxLen)
			End If
		End Set
	End Property

	Public Property LastName() As String
		Get
			LastName = prstrLastName
		End Get

		Set(ByVal vstrLastName As String)
			If Len(vstrLastName) <= prshtLastNameMaxLen Then
				prstrLastName = vstrLastName
			Else
				prstrLastName = Left(vstrLastName, prshtLastNameMaxLen)
			End If
		End Set
	End Property

	Public Property LoginName() As String
		Get
			LoginName = prstrLoginName
		End Get

		Set(ByVal vstrLoginName As String)
			If Len(vstrLoginName) <= prshtLoginNameMaxLen Then
				prstrLoginName = vstrLoginName
			Else
				prstrLoginName = Left(vstrLoginName, prshtLoginNameMaxLen)
			End If
		End Set
	End Property

	Public Property Password() As String
		Get
			Password = prstrPassword
		End Get

		Set(ByVal vstrPassword As String)
			If Len(vstrPassword) <= prshtPasswordMaxLen Then
				prstrPassword = vstrPassword
			Else
				prstrPassword = Left(vstrPassword, prshtPasswordMaxLen)
			End If
		End Set
	End Property
End Class