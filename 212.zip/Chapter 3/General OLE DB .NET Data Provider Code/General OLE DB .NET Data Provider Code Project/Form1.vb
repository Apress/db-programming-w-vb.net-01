Public Class Form1
	Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

	Public Sub New()
		MyBase.New()

		'This call is required by the Windows Form Designer.
		InitializeComponent()

		'Add any initialization after the InitializeComponent() call

	End Sub

	'Form overrides dispose to clean up the component list.
	Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
		If disposing Then
			If Not (components Is Nothing) Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(disposing)
	End Sub
	Friend WithEvents btnOpenConnection As System.Windows.Forms.Button
	Friend WithEvents btnDisableAutomaticConnectionPooling As System.Windows.Forms.Button
	Friend WithEvents btnClearConnectionPool As System.Windows.Forms.Button
	Friend WithEvents btnNestTransactions As System.Windows.Forms.Button
	Friend WithEvents btnDetermineIsolationLevel As System.Windows.Forms.Button
	Friend WithEvents btnMisc As System.Windows.Forms.Button
	Friend WithEvents btnBeginTransaction As System.Windows.Forms.Button
	Friend WithEvents btnInstantiateCommand As System.Windows.Forms.Button
	Friend WithEvents btnExecuteNonQuery As System.Windows.Forms.Button
	Friend WithEvents btnExecuteReader As System.Windows.Forms.Button
	Friend WithEvents btnExecuteScalar As System.Windows.Forms.Button
	Friend WithEvents btnInstantiateDataReader As System.Windows.Forms.Button
	Friend WithEvents btnReadRowsFromDataReader As System.Windows.Forms.Button
	Friend WithEvents lblDEscription As System.Windows.Forms.Label
	Friend WithEvents btnInstantiateDataAdapter As System.Windows.Forms.Button
	Friend WithEvents btnSetDataAdapterCommands As System.Windows.Forms.Button
	Friend WithEvents btnPopulateDataSetFromRecordset As System.Windows.Forms.Button
	Friend WithEvents btnUpdateDataSet As System.Windows.Forms.Button
	Friend WithEvents btnClearDataSet As System.Windows.Forms.Button
	Friend WithEvents btnCloneDataSetStructure As System.Windows.Forms.Button
	Friend WithEvents btnCopyDataSet As System.Windows.Forms.Button
	Friend WithEvents btnMergeDataSetWithDataRows As System.Windows.Forms.Button
	Friend WithEvents btnMergeDataSets As System.Windows.Forms.Button
	Friend WithEvents btnMergeDataSetWithDataTable As System.Windows.Forms.Button
	Friend WithEvents btnDetectAllDataSetChanges As System.Windows.Forms.Button
	Friend WithEvents btnDetectDifferentDataSetChanges As System.Windows.Forms.Button
	Friend WithEvents btnAcceptOrRejectDataSetChanges As System.Windows.Forms.Button
	Friend WithEvents btnBuildDataTable As System.Windows.Forms.Button
	Friend WithEvents btnClearDataTable As System.Windows.Forms.Button
	Friend WithEvents btnCloneDataTableStructure As System.Windows.Forms.Button
	Friend WithEvents btnCopyDataTable As System.Windows.Forms.Button
	Friend WithEvents btnSearchDataTable As System.Windows.Forms.Button
	Friend WithEvents btnSearchDataView As System.Windows.Forms.Button

	'Required by the Windows Form Designer
	Private components As System.ComponentModel.Container

	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.  
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
		Me.btnUpdateDataSet = New System.Windows.Forms.Button()
		Me.btnBeginTransaction = New System.Windows.Forms.Button()
		Me.btnMisc = New System.Windows.Forms.Button()
		Me.btnNestTransactions = New System.Windows.Forms.Button()
		Me.btnExecuteNonQuery = New System.Windows.Forms.Button()
		Me.btnDetermineIsolationLevel = New System.Windows.Forms.Button()
		Me.lblDEscription = New System.Windows.Forms.Label()
		Me.btnPopulateDataSetFromRecordset = New System.Windows.Forms.Button()
		Me.btnDisableAutomaticConnectionPooling = New System.Windows.Forms.Button()
		Me.btnInstantiateDataReader = New System.Windows.Forms.Button()
		Me.btnClearConnectionPool = New System.Windows.Forms.Button()
		Me.btnExecuteScalar = New System.Windows.Forms.Button()
		Me.btnCloneDataSetStructure = New System.Windows.Forms.Button()
		Me.btnSetDataAdapterCommands = New System.Windows.Forms.Button()
		Me.btnOpenConnection = New System.Windows.Forms.Button()
		Me.btnCopyDataSet = New System.Windows.Forms.Button()
		Me.btnReadRowsFromDataReader = New System.Windows.Forms.Button()
		Me.btnInstantiateCommand = New System.Windows.Forms.Button()
		Me.btnExecuteReader = New System.Windows.Forms.Button()
		Me.btnInstantiateDataAdapter = New System.Windows.Forms.Button()
		Me.btnClearDataSet = New System.Windows.Forms.Button()
		Me.btnMergeDataSetWithDataRows = New System.Windows.Forms.Button()
		Me.btnMergeDataSets = New System.Windows.Forms.Button()
		Me.btnMergeDataSetWithDataTable = New System.Windows.Forms.Button()
		Me.btnDetectAllDataSetChanges = New System.Windows.Forms.Button()
		Me.btnDetectDifferentDataSetChanges = New System.Windows.Forms.Button()
		Me.btnAcceptOrRejectDataSetChanges = New System.Windows.Forms.Button()
		Me.btnBuildDataTable = New System.Windows.Forms.Button()
		Me.btnClearDataTable = New System.Windows.Forms.Button()
		Me.btnCloneDataTableStructure = New System.Windows.Forms.Button()
		Me.btnCopyDataTable = New System.Windows.Forms.Button()
		Me.btnSearchDataTable = New System.Windows.Forms.Button()
		Me.btnSearchDataView = New System.Windows.Forms.Button()
		Me.SuspendLayout()
		'
		'btnUpdateDataSet
		'
		Me.btnUpdateDataSet.AccessibleRole = System.Windows.Forms.AccessibleRole.PageTabList
		Me.btnUpdateDataSet.Location = New System.Drawing.Point(536, 210)
		Me.btnUpdateDataSet.Name = "btnUpdateDataSet"
		Me.btnUpdateDataSet.Size = New System.Drawing.Size(183, 23)
		Me.btnUpdateDataSet.TabIndex = 0
		Me.btnUpdateDataSet.Text = "Update DataSet"
		'
		'btnBeginTransaction
		'
		Me.btnBeginTransaction.AccessibleRole = System.Windows.Forms.AccessibleRole.PageTabList
		Me.btnBeginTransaction.Location = New System.Drawing.Point(2, 184)
		Me.btnBeginTransaction.Name = "btnBeginTransaction"
		Me.btnBeginTransaction.Size = New System.Drawing.Size(203, 23)
		Me.btnBeginTransaction.TabIndex = 0
		Me.btnBeginTransaction.Text = "Begin Transaction"
		'
		'btnMisc
		'
		Me.btnMisc.AccessibleRole = System.Windows.Forms.AccessibleRole.PageTabList
		Me.btnMisc.Location = New System.Drawing.Point(4, 56)
		Me.btnMisc.Name = "btnMisc"
		Me.btnMisc.Size = New System.Drawing.Size(203, 23)
		Me.btnMisc.TabIndex = 0
		Me.btnMisc.Text = "Misc."
		'
		'btnNestTransactions
		'
		Me.btnNestTransactions.AccessibleRole = System.Windows.Forms.AccessibleRole.PageTabList
		Me.btnNestTransactions.Location = New System.Drawing.Point(2, 212)
		Me.btnNestTransactions.Name = "btnNestTransactions"
		Me.btnNestTransactions.Size = New System.Drawing.Size(203, 23)
		Me.btnNestTransactions.TabIndex = 0
		Me.btnNestTransactions.Text = "Nest Transactions"
		'
		'btnExecuteNonQuery
		'
		Me.btnExecuteNonQuery.AccessibleRole = System.Windows.Forms.AccessibleRole.PageTabList
		Me.btnExecuteNonQuery.Location = New System.Drawing.Point(210, 116)
		Me.btnExecuteNonQuery.Name = "btnExecuteNonQuery"
		Me.btnExecuteNonQuery.Size = New System.Drawing.Size(152, 23)
		Me.btnExecuteNonQuery.TabIndex = 0
		Me.btnExecuteNonQuery.Text = "Execute Non Query"
		'
		'btnDetermineIsolationLevel
		'
		Me.btnDetermineIsolationLevel.AccessibleRole = System.Windows.Forms.AccessibleRole.PageTabList
		Me.btnDetermineIsolationLevel.Location = New System.Drawing.Point(2, 240)
		Me.btnDetermineIsolationLevel.Name = "btnDetermineIsolationLevel"
		Me.btnDetermineIsolationLevel.Size = New System.Drawing.Size(203, 23)
		Me.btnDetermineIsolationLevel.TabIndex = 0
		Me.btnDetermineIsolationLevel.Text = "Determine Transaction Isolation Level"
		'
		'lblDEscription
		'
		Me.lblDEscription.Location = New System.Drawing.Point(118, 13)
		Me.lblDEscription.Name = "lblDEscription"
		Me.lblDEscription.Size = New System.Drawing.Size(520, 35)
		Me.lblDEscription.TabIndex = 1
		Me.lblDEscription.Text = "Not all of the source code has a corresponding button, so please look in the Code" & _
		"Behind file (.vb), for code that doesn't have a button. You can attcah the code " & _
		"to the Misc. button if you want to run it."
		'
		'btnPopulateDataSetFromRecordset
		'
		Me.btnPopulateDataSetFromRecordset.AccessibleRole = System.Windows.Forms.AccessibleRole.PageTabList
		Me.btnPopulateDataSetFromRecordset.Location = New System.Drawing.Point(536, 182)
		Me.btnPopulateDataSetFromRecordset.Name = "btnPopulateDataSetFromRecordset"
		Me.btnPopulateDataSetFromRecordset.Size = New System.Drawing.Size(183, 23)
		Me.btnPopulateDataSetFromRecordset.TabIndex = 0
		Me.btnPopulateDataSetFromRecordset.Text = "Populate DataSet from Recordset"
		'
		'btnDisableAutomaticConnectionPooling
		'
		Me.btnDisableAutomaticConnectionPooling.AccessibleRole = System.Windows.Forms.AccessibleRole.PageTabList
		Me.btnDisableAutomaticConnectionPooling.Location = New System.Drawing.Point(2, 116)
		Me.btnDisableAutomaticConnectionPooling.Name = "btnDisableAutomaticConnectionPooling"
		Me.btnDisableAutomaticConnectionPooling.Size = New System.Drawing.Size(203, 23)
		Me.btnDisableAutomaticConnectionPooling.TabIndex = 0
		Me.btnDisableAutomaticConnectionPooling.Text = "Disable Connection Pooling"
		'
		'btnInstantiateDataReader
		'
		Me.btnInstantiateDataReader.AccessibleRole = System.Windows.Forms.AccessibleRole.PageTabList
		Me.btnInstantiateDataReader.Location = New System.Drawing.Point(368, 88)
		Me.btnInstantiateDataReader.Name = "btnInstantiateDataReader"
		Me.btnInstantiateDataReader.Size = New System.Drawing.Size(163, 23)
		Me.btnInstantiateDataReader.TabIndex = 0
		Me.btnInstantiateDataReader.Text = "Instantiate DataReader"
		'
		'btnClearConnectionPool
		'
		Me.btnClearConnectionPool.AccessibleRole = System.Windows.Forms.AccessibleRole.PageTabList
		Me.btnClearConnectionPool.Location = New System.Drawing.Point(2, 144)
		Me.btnClearConnectionPool.Name = "btnClearConnectionPool"
		Me.btnClearConnectionPool.Size = New System.Drawing.Size(203, 23)
		Me.btnClearConnectionPool.TabIndex = 0
		Me.btnClearConnectionPool.Text = "Clear Connection Pool"
		'
		'btnExecuteScalar
		'
		Me.btnExecuteScalar.AccessibleRole = System.Windows.Forms.AccessibleRole.PageTabList
		Me.btnExecuteScalar.Location = New System.Drawing.Point(210, 172)
		Me.btnExecuteScalar.Name = "btnExecuteScalar"
		Me.btnExecuteScalar.Size = New System.Drawing.Size(152, 23)
		Me.btnExecuteScalar.TabIndex = 0
		Me.btnExecuteScalar.Text = "Execute Scalar"
		'
		'btnCloneDataSetStructure
		'
		Me.btnCloneDataSetStructure.AccessibleRole = System.Windows.Forms.AccessibleRole.PageTabList
		Me.btnCloneDataSetStructure.Location = New System.Drawing.Point(536, 264)
		Me.btnCloneDataSetStructure.Name = "btnCloneDataSetStructure"
		Me.btnCloneDataSetStructure.Size = New System.Drawing.Size(183, 23)
		Me.btnCloneDataSetStructure.TabIndex = 0
		Me.btnCloneDataSetStructure.Text = "Clone DataSet Structure"
		'
		'btnSetDataAdapterCommands
		'
		Me.btnSetDataAdapterCommands.AccessibleRole = System.Windows.Forms.AccessibleRole.PageTabList
		Me.btnSetDataAdapterCommands.Location = New System.Drawing.Point(536, 116)
		Me.btnSetDataAdapterCommands.Name = "btnSetDataAdapterCommands"
		Me.btnSetDataAdapterCommands.Size = New System.Drawing.Size(182, 23)
		Me.btnSetDataAdapterCommands.TabIndex = 0
		Me.btnSetDataAdapterCommands.Text = "Set DataAdapter Commands"
		'
		'btnOpenConnection
		'
		Me.btnOpenConnection.AccessibleRole = System.Windows.Forms.AccessibleRole.PageTabList
		Me.btnOpenConnection.Location = New System.Drawing.Point(2, 88)
		Me.btnOpenConnection.Name = "btnOpenConnection"
		Me.btnOpenConnection.Size = New System.Drawing.Size(203, 23)
		Me.btnOpenConnection.TabIndex = 0
		Me.btnOpenConnection.Text = "Open Connection"
		'
		'btnCopyDataSet
		'
		Me.btnCopyDataSet.AccessibleRole = System.Windows.Forms.AccessibleRole.PageTabList
		Me.btnCopyDataSet.Location = New System.Drawing.Point(536, 290)
		Me.btnCopyDataSet.Name = "btnCopyDataSet"
		Me.btnCopyDataSet.Size = New System.Drawing.Size(183, 23)
		Me.btnCopyDataSet.TabIndex = 0
		Me.btnCopyDataSet.Text = "Copy DataSet Structure && Data"
		'
		'btnReadRowsFromDataReader
		'
		Me.btnReadRowsFromDataReader.AccessibleRole = System.Windows.Forms.AccessibleRole.PageTabList
		Me.btnReadRowsFromDataReader.Location = New System.Drawing.Point(368, 116)
		Me.btnReadRowsFromDataReader.Name = "btnReadRowsFromDataReader"
		Me.btnReadRowsFromDataReader.Size = New System.Drawing.Size(163, 23)
		Me.btnReadRowsFromDataReader.TabIndex = 0
		Me.btnReadRowsFromDataReader.Text = "Read Rows from DataReader"
		'
		'btnInstantiateCommand
		'
		Me.btnInstantiateCommand.AccessibleRole = System.Windows.Forms.AccessibleRole.PageTabList
		Me.btnInstantiateCommand.Location = New System.Drawing.Point(210, 88)
		Me.btnInstantiateCommand.Name = "btnInstantiateCommand"
		Me.btnInstantiateCommand.Size = New System.Drawing.Size(152, 23)
		Me.btnInstantiateCommand.TabIndex = 0
		Me.btnInstantiateCommand.Text = "Instantiate Command"
		'
		'btnExecuteReader
		'
		Me.btnExecuteReader.AccessibleRole = System.Windows.Forms.AccessibleRole.PageTabList
		Me.btnExecuteReader.Location = New System.Drawing.Point(210, 144)
		Me.btnExecuteReader.Name = "btnExecuteReader"
		Me.btnExecuteReader.Size = New System.Drawing.Size(152, 23)
		Me.btnExecuteReader.TabIndex = 0
		Me.btnExecuteReader.Text = "Execute Reader"
		'
		'btnInstantiateDataAdapter
		'
		Me.btnInstantiateDataAdapter.AccessibleRole = System.Windows.Forms.AccessibleRole.PageTabList
		Me.btnInstantiateDataAdapter.Location = New System.Drawing.Point(536, 88)
		Me.btnInstantiateDataAdapter.Name = "btnInstantiateDataAdapter"
		Me.btnInstantiateDataAdapter.Size = New System.Drawing.Size(182, 23)
		Me.btnInstantiateDataAdapter.TabIndex = 0
		Me.btnInstantiateDataAdapter.Text = "Instantiate DataAdapter"
		'
		'btnClearDataSet
		'
		Me.btnClearDataSet.AccessibleRole = System.Windows.Forms.AccessibleRole.PageTabList
		Me.btnClearDataSet.Location = New System.Drawing.Point(536, 238)
		Me.btnClearDataSet.Name = "btnClearDataSet"
		Me.btnClearDataSet.Size = New System.Drawing.Size(183, 23)
		Me.btnClearDataSet.TabIndex = 0
		Me.btnClearDataSet.Text = "Clear DataSet"
		'
		'btnMergeDataSetWithDataRows
		'
		Me.btnMergeDataSetWithDataRows.AccessibleRole = System.Windows.Forms.AccessibleRole.PageTabList
		Me.btnMergeDataSetWithDataRows.Location = New System.Drawing.Point(536, 316)
		Me.btnMergeDataSetWithDataRows.Name = "btnMergeDataSetWithDataRows"
		Me.btnMergeDataSetWithDataRows.Size = New System.Drawing.Size(183, 23)
		Me.btnMergeDataSetWithDataRows.TabIndex = 0
		Me.btnMergeDataSetWithDataRows.Text = "Merge DataSet with DataRows"
		'
		'btnMergeDataSets
		'
		Me.btnMergeDataSets.AccessibleRole = System.Windows.Forms.AccessibleRole.PageTabList
		Me.btnMergeDataSets.Location = New System.Drawing.Point(536, 342)
		Me.btnMergeDataSets.Name = "btnMergeDataSets"
		Me.btnMergeDataSets.Size = New System.Drawing.Size(183, 23)
		Me.btnMergeDataSets.TabIndex = 0
		Me.btnMergeDataSets.Text = "Merge DataSets"
		'
		'btnMergeDataSetWithDataTable
		'
		Me.btnMergeDataSetWithDataTable.AccessibleRole = System.Windows.Forms.AccessibleRole.PageTabList
		Me.btnMergeDataSetWithDataTable.Location = New System.Drawing.Point(536, 368)
		Me.btnMergeDataSetWithDataTable.Name = "btnMergeDataSetWithDataTable"
		Me.btnMergeDataSetWithDataTable.Size = New System.Drawing.Size(183, 23)
		Me.btnMergeDataSetWithDataTable.TabIndex = 0
		Me.btnMergeDataSetWithDataTable.Text = "Merge DataSet with DataTable"
		'
		'btnDetectAllDataSetChanges
		'
		Me.btnDetectAllDataSetChanges.AccessibleRole = System.Windows.Forms.AccessibleRole.PageTabList
		Me.btnDetectAllDataSetChanges.Location = New System.Drawing.Point(536, 394)
		Me.btnDetectAllDataSetChanges.Name = "btnDetectAllDataSetChanges"
		Me.btnDetectAllDataSetChanges.Size = New System.Drawing.Size(183, 23)
		Me.btnDetectAllDataSetChanges.TabIndex = 0
		Me.btnDetectAllDataSetChanges.Text = "Detect All DataSet Changes"
		'
		'btnDetectDifferentDataSetChanges
		'
		Me.btnDetectDifferentDataSetChanges.AccessibleRole = System.Windows.Forms.AccessibleRole.PageTabList
		Me.btnDetectDifferentDataSetChanges.Location = New System.Drawing.Point(536, 420)
		Me.btnDetectDifferentDataSetChanges.Name = "btnDetectDifferentDataSetChanges"
		Me.btnDetectDifferentDataSetChanges.Size = New System.Drawing.Size(184, 23)
		Me.btnDetectDifferentDataSetChanges.TabIndex = 0
		Me.btnDetectDifferentDataSetChanges.Text = "Detect Different DataSet Changes"
		'
		'btnAcceptOrRejectDataSetChanges
		'
		Me.btnAcceptOrRejectDataSetChanges.AccessibleRole = System.Windows.Forms.AccessibleRole.PageTabList
		Me.btnAcceptOrRejectDataSetChanges.Location = New System.Drawing.Point(536, 446)
		Me.btnAcceptOrRejectDataSetChanges.Name = "btnAcceptOrRejectDataSetChanges"
		Me.btnAcceptOrRejectDataSetChanges.Size = New System.Drawing.Size(184, 23)
		Me.btnAcceptOrRejectDataSetChanges.TabIndex = 0
		Me.btnAcceptOrRejectDataSetChanges.Text = "Accept or Reject Changes"
		'
		'btnBuildDataTable
		'
		Me.btnBuildDataTable.AccessibleRole = System.Windows.Forms.AccessibleRole.PageTabList
		Me.btnBuildDataTable.Location = New System.Drawing.Point(368, 210)
		Me.btnBuildDataTable.Name = "btnBuildDataTable"
		Me.btnBuildDataTable.Size = New System.Drawing.Size(163, 23)
		Me.btnBuildDataTable.TabIndex = 0
		Me.btnBuildDataTable.Text = "Build DataTable"
		'
		'btnClearDataTable
		'
		Me.btnClearDataTable.AccessibleRole = System.Windows.Forms.AccessibleRole.PageTabList
		Me.btnClearDataTable.Location = New System.Drawing.Point(368, 238)
		Me.btnClearDataTable.Name = "btnClearDataTable"
		Me.btnClearDataTable.Size = New System.Drawing.Size(163, 23)
		Me.btnClearDataTable.TabIndex = 0
		Me.btnClearDataTable.Text = "Clear DataTable"
		'
		'btnCloneDataTableStructure
		'
		Me.btnCloneDataTableStructure.AccessibleRole = System.Windows.Forms.AccessibleRole.PageTabList
		Me.btnCloneDataTableStructure.Location = New System.Drawing.Point(368, 264)
		Me.btnCloneDataTableStructure.Name = "btnCloneDataTableStructure"
		Me.btnCloneDataTableStructure.Size = New System.Drawing.Size(163, 23)
		Me.btnCloneDataTableStructure.TabIndex = 0
		Me.btnCloneDataTableStructure.Text = "Clone DataTable"
		'
		'btnCopyDataTable
		'
		Me.btnCopyDataTable.AccessibleRole = System.Windows.Forms.AccessibleRole.PageTabList
		Me.btnCopyDataTable.Location = New System.Drawing.Point(368, 290)
		Me.btnCopyDataTable.Name = "btnCopyDataTable"
		Me.btnCopyDataTable.Size = New System.Drawing.Size(163, 23)
		Me.btnCopyDataTable.TabIndex = 0
		Me.btnCopyDataTable.Text = "Copy DataTable"
		'
		'btnSearchDataTable
		'
		Me.btnSearchDataTable.AccessibleRole = System.Windows.Forms.AccessibleRole.PageTabList
		Me.btnSearchDataTable.Location = New System.Drawing.Point(368, 316)
		Me.btnSearchDataTable.Name = "btnSearchDataTable"
		Me.btnSearchDataTable.Size = New System.Drawing.Size(163, 23)
		Me.btnSearchDataTable.TabIndex = 0
		Me.btnSearchDataTable.Text = "Search DataTable"
		'
		'btnSearchDataView
		'
		Me.btnSearchDataView.AccessibleRole = System.Windows.Forms.AccessibleRole.PageTabList
		Me.btnSearchDataView.Location = New System.Drawing.Point(368, 368)
		Me.btnSearchDataView.Name = "btnSearchDataView"
		Me.btnSearchDataView.Size = New System.Drawing.Size(163, 23)
		Me.btnSearchDataView.TabIndex = 0
		Me.btnSearchDataView.Text = "Search DataView"
		'
		'Form1
		'
		Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
		Me.ClientSize = New System.Drawing.Size(728, 475)
		Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnSearchDataView, Me.btnSearchDataTable, Me.btnCopyDataTable, Me.btnCloneDataTableStructure, Me.btnClearDataTable, Me.btnBuildDataTable, Me.btnAcceptOrRejectDataSetChanges, Me.btnDetectDifferentDataSetChanges, Me.btnDetectAllDataSetChanges, Me.btnMergeDataSetWithDataTable, Me.btnMergeDataSets, Me.btnMergeDataSetWithDataRows, Me.btnCopyDataSet, Me.btnCloneDataSetStructure, Me.btnClearDataSet, Me.btnUpdateDataSet, Me.btnPopulateDataSetFromRecordset, Me.btnSetDataAdapterCommands, Me.btnInstantiateDataAdapter, Me.lblDEscription, Me.btnReadRowsFromDataReader, Me.btnInstantiateDataReader, Me.btnExecuteScalar, Me.btnExecuteReader, Me.btnExecuteNonQuery, Me.btnInstantiateCommand, Me.btnBeginTransaction, Me.btnMisc, Me.btnDetermineIsolationLevel, Me.btnNestTransactions, Me.btnClearConnectionPool, Me.btnDisableAutomaticConnectionPooling, Me.btnOpenConnection})
		Me.Name = "Form1"
		Me.Text = "General OLE DB .NET Data Provider Code"
		Me.ResumeLayout(False)

	End Sub

#End Region

	Private Sub btnOpenConnection_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOpenConnection.Click
		OpenConnection()
	End Sub

	Private Sub btnDisableAutomaticConnectionPooling_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDisableAutomaticConnectionPooling.Click
		DisableAutomaticConnectionPooling()
	End Sub

	Private Sub btnClearConnectionPool_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClearConnectionPool.Click
		ClearConnectionPool()
	End Sub

	Private Sub btnBeginTransaction_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
		BeginNonDefaultIsolationLevelTransaction()
	End Sub

	Private Sub btnNestTransactions_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNestTransactions.Click
		NestTransactions()
	End Sub

	Private Sub btnDetermineIsolationLevel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDetermineIsolationLevel.Click
		DetermineTransactionIsolationLevel()
	End Sub

	Private Sub btnMisc_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnMisc.Click
		CheckForNullValueInColumn(3)
	End Sub

	Private Sub btnInstantiateCommand_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnInstantiateCommand.Click
		InstantiateCommandObject()
	End Sub

	Private Sub btnExecuteNonQuery_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExecuteNonQuery.Click
		ExecuteNonQueryCommand()
	End Sub

	Private Sub btnExecuteReader_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExecuteReader.Click
		ExecuteReaderCommand()
	End Sub

	Private Sub btnExecuteScalar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExecuteScalar.Click
		ExecuteScalarCommand()
	End Sub

	Private Sub btnInstantiateDataReader_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnInstantiateDataReader.Click
		InstantiateDataReader()
	End Sub

	Private Sub btnReadRowsFromDataReader_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnReadRowsFromDataReader.Click
		ReadRowsFromDataReader()
	End Sub

	Private Sub btnInstantiateDataAdapter_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnInstantiateDataAdapter.Click
		InstantiateAndInitializeDataAdapter()
	End Sub

	Private Sub btnSetDataAdapterCommands_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSetDataAdapterCommands.Click
		SetDataAdapterCommandProperties()
	End Sub

	Private Sub btnPopulateDataSetFromRecordset_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPopulateDataSetFromRecordset.Click
		FillDataSetFromRecordset()
	End Sub

	Private Sub btnUpdateDataSet_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUpdateDataSet.Click
		UpdateDataSet()
	End Sub

	Private Sub btnClearDataSet_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClearDataSet.Click
		ClearDataSet()
	End Sub

	Private Sub btnCloneDataSetStructure_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCloneDataSetStructure.Click
		CloneDataSetStructure()
	End Sub

	Private Sub btnCopyDataSet_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCopyDataSet.Click
		CopyDataSetStructureAndData()
	End Sub

	Private Sub btnMergeDataSetWithDataRows_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnMergeDataSetWithDataRows.Click
		MergeDataSetWithDataRows()
	End Sub

	Private Sub btnMergeDataSets_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnMergeDataSets.Click
		MergeDataSets()
	End Sub

	Private Sub btnMergeDataSetWithDataTable_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnMergeDataSetWithDataTable.Click
		MergeDataSetWithDataTable()
	End Sub

	Private Sub btnDetectAllDataSetChanges_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDetectAllDataSetChanges.Click
		DetectAllDataSetChanges()
	End Sub

	Private Sub btnDetectDifferentDataSetChanges_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDetectDifferentDataSetChanges.Click
		DetectDifferentDataSetChanges()
	End Sub

	Private Sub btnAcceptOrRejectDataSetChanges_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAcceptOrRejectDataSetChanges.Click
		AcceptOrRejectDataSetChanges()
	End Sub

	Private Sub btnBuildDataTable_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBuildDataTable.Click
		BuildDataTable()
	End Sub

	Private Sub btnClearDataTable_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClearDataTable.Click
		ClearDataTable()
	End Sub

	Private Sub btnCloneDataTableStructure_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCloneDataTableStructure.Click
		CloneDataTableStructure()
	End Sub

	Private Sub btnCopyDataTable_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCopyDataTable.Click
		CopyDataTable()
	End Sub

	Private Sub btnSearchDataTable_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSearchDataTable.Click
		SearchDataTable()
	End Sub

	Private Sub btnSearchDataView_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSearchDataView.Click
		SearchDataView()
	End Sub
End Class
