Option Strict On

Imports System.Data.OleDb
Imports System.Xml
Imports ADODB

Module General
	Private Const PR_STR_CONNECTION_STRING As String = "Provider=SQLOLEDB;Data Source=USERMANPC;" & _
	 "User ID=UserMan;Password=userman;Initial Catalog=UserMan"

	' Listing 3A-1
	Public Sub OpenConnection(Optional ByVal vstrConnectionString As String = PR_STR_CONNECTION_STRING)
		' Declare connection object
		Dim cnnUserMan As OleDbConnection

		' Instantiate the connection object
		cnnUserMan = New OleDbConnection()
		' Set up connection string
		cnnUserMan.ConnectionString = vstrConnectionString

		' Open the connection
		cnnUserMan.Open()
	End Sub

	Public Sub DisableAutomaticConnectionPooling()
		Dim cnnUserMan As OleDbConnection

		' Instantiate and open the connection
		cnnUserMan = New OleDbConnection(PR_STR_CONNECTION_STRING & ";OLE DB Services=-4")
		cnnUserMan.Open()
	End Sub

	' Listing 3A-3
	Public Sub ClearConnectionPool()
		' Declare connection object
		Dim cnnUserMan As OleDbConnection

		' Instantiate the connection object
		cnnUserMan = New OleDbConnection(PR_STR_CONNECTION_STRING)
		' Open the connection
		cnnUserMan.Open()

		' Do your stuff
		' ...

		' Close connection and release pool
		cnnUserMan.Close()
		cnnUserMan.ReleaseObjectPool()
	End Sub

	' Listing 3A-5
	Public Sub BeginNonDefaultIsolationLevelTransaction()
		Dim cnnUserMan As OleDbConnection
		Dim strSQL As String
		Dim traUserMan As OleDbTransaction

		' Instantiate the connection
		cnnUserMan = New OleDbConnection(PR_STR_CONNECTION_STRING)
		' Open the connection
		cnnUserMan.Open()
		' Build query string
		strSQL = "SELECT * FROM tblUser"
		' Begin transaction
		traUserMan = cnnUserMan.BeginTransaction(IsolationLevel.ReadCommitted)
	End Sub

	' Listing 3A-9
	Public Sub NestTransactions()
		Dim cnnUserMan As OleDbConnection
		Dim traUserManMain As OleDbTransaction
		Dim traUserManFamily As OleDbTransaction
		Dim traUserManAddress As OleDbTransaction
		Dim strSQL As String

		' Instantiate the connection
		cnnUserMan = New OleDbConnection(PR_STR_CONNECTION_STRING)
		' Open the connection
		cnnUserMan.Open()
		' Build query string
		strSQL = "SELECT * FROM tblUser"

		' Start main transaction
		traUserManMain = cnnUserMan.BeginTransaction()
		' Update family tables
		' ...
		' Begin nested transaction
		traUserManFamily = traUserManMain.Begin()
		' Update address tables
		' ...
		' Begin nested transaction
		traUserManAddress = traUserManFamily.Begin()
		' Roll back address table updates
		traUserManAddress.Rollback()
	End Sub

	' Listing 3A-10
	Public Sub DetermineTransactionIsolationLevel()
		Const STR_MAIN_TRANSACTION_NAME As String = "MainTransaction"

		Dim cnnUserMan As OleDbConnection
		Dim traUserMan As OleDbTransaction
		Dim intIsolationLevel As Integer

		' Instantiate the connection
		cnnUserMan = New OleDbConnection(PR_STR_CONNECTION_STRING)
		' Open the connection
		cnnUserMan.Open()

		' Start transaction with non-default isolation level
		traUserMan = cnnUserMan.BeginTransaction(IsolationLevel.ReadCommitted)

		' Return the isolation level as text
		MsgBox(traUserMan.IsolationLevel.ToString)
		' Return the isolation level as an integer value
		intIsolationLevel = traUserMan.IsolationLevel
		MsgBox(intIsolationLevel)
	End Sub

	' Listing 3A-11
	Public Sub CheckBeginTransactionMethodException()
		Const STR_MAIN_TRANSACTION_NAME As String = "MainTransaction"

		Dim cnnUserMan As OleDbConnection
		Dim traUserMan As OleDbTransaction

		' Instantiate the connection
		cnnUserMan = New OleDbConnection(PR_STR_CONNECTION_STRING)
		' Open the connection
		' If the following line is commented out, the BeginTransaction exception will be thrown.
		cnnUserMan.Open()

		Try
			' Start transaction with non-default isolation level
			traUserMan = cnnUserMan.BeginTransaction(IsolationLevel.ReadCommitted)
		Catch objException As Exception
			' Check if a BeginTransaction method threw the exception
			If objException.TargetSite.Name = "BeginTransaction" Then
				MsgBox("The BeginTransaction method threw the exception!")
			End If
		End Try
	End Sub

	' Listing 3A-12
	Public Sub CheckConnectionStringPropertyException()
		Dim cnnUserMan As OleDbConnection

		' Instantiate the connection
		cnnUserMan = New OleDbConnection(PR_STR_CONNECTION_STRING)
		' Open the connection
		cnnUserMan.Open()

		Try
			' Set the connection string
			cnnUserMan.ConnectionString = PR_STR_CONNECTION_STRING
		Catch objException As Exception
			' Check if setting the ConnectionString threw the exception
			If objException.TargetSite.Name = "set_ConnectionString" Then
				MsgBox("The ConnectionString property threw the exception!")
			End If
		End Try
	End Sub

	' Listing 3A-14
	Public Sub CheckChangeDatabaseMethodException()
		Dim cnnUserMan As OleDbConnection

		Try
			' Instantiate the connection
			cnnUserMan = New OleDbConnection(PR_STR_CONNECTION_STRING)
			' Open the connection
			' If the following line is commented out, the ChangeDatabase exception will be thrown
			'cnnUserMan.Open()
			' Change database
			cnnUserMan.ChangeDatabase("master")
		Catch objException As Exception
			' Check if we tried to change database on an invalid connection
			If objException.TargetSite.Name = "ChangeDatabase" Then
				MsgBox("The ChangeDatabase method threw the exception!")
			End If
		End Try
	End Sub

	' Listing 3A-15
	Public Sub CheckOpenMethodException()
		Dim cnnUserMan As OleDbConnection

		Try
			' Instantiate the connection
			cnnUserMan = New OleDbConnection(PR_STR_CONNECTION_STRING)
			' Open the connection
			cnnUserMan.Open()
			' Open the connection
			cnnUserMan.Open()
		Catch objException As Exception
			' Check if we tried to open an already open connection
			If objException.TargetSite.Name = "Open" Then
				MsgBox("The Open method threw the exception!")
			End If
		End Try
	End Sub

	' Listing 3A-16
	Public Sub TraversingAllOleDbErrors()
		Dim cnnUserMan As OleDbConnection

		Try
			' Instantiate the connection
			cnnUserMan = New OleDbConnection(PR_STR_CONNECTION_STRING)
			' Open the connection
			cnnUserMan.Open()
			' Do your stuff...
			' ...
		Catch objException As OleDbException
			' This Catch block will handle all exceptions that 
			' the OleDbAdapter cannot handle
			Dim objError As OleDbError

			For Each objError In objException.Errors
				MsgBox(objException.Message)
			Next
		Catch objException As Exception
			' This Catch block will catch all exceptions that
			' the OleDbAdapter can handle
			MsgBox(objException.Message)
		End Try
	End Sub

	' Listing 3A-17
	Public Sub InstantiateCommandObject()
		Dim cnnUserMan As OleDbConnection
		Dim cmmUserMan As OleDbCommand
		Dim strSQL As String

		' Instantiate the connection
		cnnUserMan = New OleDbConnection(PR_STR_CONNECTION_STRING)
		' Open the connection
		cnnUserMan.Open()
		' Build query string
		strSQL = "SELECT * FROM tblUser"
		' Instantiate the command
		cmmUserMan = New OleDbCommand(strSQL, cnnUserMan)
	End Sub

	' Listing 3A-18
	Public Sub ExecuteNonQueryCommand()
		Dim cnnUserMan As OleDbConnection
		Dim cmmUserMan As OleDbCommand
		Dim strSQL As String

		' Instantiate the connection
		cnnUserMan = New OleDbConnection(PR_STR_CONNECTION_STRING)
		' Open the connection
		cnnUserMan.Open()
		' Build delete query string
		strSQL = "DELETE FROM tblUser WHERE LoginName='User99'"
		' Instantiate and execute the delete command
		cmmUserMan = New OleDbCommand(strSQL, cnnUserMan)
		cmmUserMan.ExecuteNonQuery()
		' Build insert query string
		strSQL = "INSERT INTO tblUser (LoginName) VALUES('User99')"
		' Instantiate and execute the insert command
		cmmUserMan = New OleDbCommand(strSQL, cnnUserMan)
		cmmUserMan.ExecuteNonQuery()
	End Sub

	' Listing 3A-19
	Public Sub ExecuteReaderCommand()
		Dim cnnUserMan As OleDbConnection
		Dim cmmUserMan As OleDbCommand
		Dim drdTest As OleDbDataReader
		Dim strSQL As String

		' Instantiate the connection
		cnnUserMan = New OleDbConnection(PR_STR_CONNECTION_STRING)
		' Open the connection
		cnnUserMan.Open()
		' Build query string
		strSQL = "SELECT * FROM tblUser"
		' Instantiate and execute the command
		cmmUserMan = New OleDbCommand(strSQL, cnnUserMan)
		drdTest = cmmUserMan.ExecuteReader()
	End Sub

	' Listing 3A-20
	Public Sub ExecuteScalarCommand()
		Dim cnnUserMan As OleDbConnection
		Dim cmmUserMan As OleDbCommand
		Dim intNumRows As Integer
		Dim strSQL As String

		' Instantiate the connection
		cnnUserMan = New OleDbConnection(PR_STR_CONNECTION_STRING)
		' Open the connection
		cnnUserMan.Open()
		' Build query string
		strSQL = "SELECT COUNT(*) FROM tblUser"
		' Instantiate the command
		cmmUserMan = New OleDbCommand(strSQL, cnnUserMan)
		' Save the number of rows in the table
		intNumRows = CInt(cmmUserMan.ExecuteScalar().ToString)
	End Sub

	' Listing 3A-22
	Public Sub CheckCommandTimeoutPropertyException()
		Dim cnnUserMan As OleDbConnection
		Dim cmmUserMan As OleDbCommand
		Dim strSQL As String

		Try
			' Instantiate the connection
			cnnUserMan = New OleDbConnection(PR_STR_CONNECTION_STRING)
			' Open the connection
			cnnUserMan.Open()
			' Build query string
			strSQL = "SELECT * FROM tblUser"
			' Instantiate the command
			cmmUserMan = New OleDbCommand(strSQL, cnnUserMan)
			' Change command timeout
			cmmUserMan.CommandTimeout = -1
		Catch objException As ArgumentException
			' Check if we tried to set command timeout to an invalid value
			If objException.TargetSite.Name = "set_CommandTimeout" Then
				MsgBox("The CommandTimeout property threw the exception.")
			End If
		End Try
	End Sub

	' Listing 3A-25
	Public Sub CheckUpdateRowSourcePropertyException()
		Dim cnnUserMan As OleDbConnection
		Dim cmmUserMan As OleDbCommand
		Dim strSQL As String

		Try
			' Instantiate the connection
			cnnUserMan = New OleDbConnection(PR_STR_CONNECTION_STRING)
			' Open the connection
			cnnUserMan.Open()
			' Build query string
			strSQL = "SELECT * FROM tblUser"
			' Instantiate the command
			cmmUserMan = New OleDbCommand(strSQL, cnnUserMan)
			' Change Row source Update
			' You need to turn Option Strict Off for this to compile
			'cmmUserMan.UpdatedRowSource = 5
		Catch objException As ArgumentException
			' Check if we tried to set the row source update to an invalid value
			If objException.TargetSite.Name = "set_UpdatedRowSource" Then
				MsgBox("The UpdatedRowSource property threw the exception.")
			End If
		End Try
	End Sub

	' Listing 3A-26
	Public Sub InstantiateDataReader()
		Dim cnnUserMan As OleDbConnection
		Dim cmmUserMan As OleDbCommand
		Dim drdUserMan As OleDbDataReader
		Dim strSQL As String

		' Instantiate the connection
		cnnUserMan = New OleDbConnection(PR_STR_CONNECTION_STRING)
		' Open the connection
		cnnUserMan.Open()
		' Build query string
		strSQL = "SELECT * FROM tblUser"
		' Instantiate the command
		cmmUserMan = New OleDbCommand(strSQL, cnnUserMan)
		' Instantiate data reader using the ExecuteReader method 
		' of the command class
		drdUserMan = cmmUserMan.ExecuteReader()
	End Sub

	' Listing 3A-27
	Public Sub ReadRowsFromDataReader()
		Dim cnnUserMan As OleDbConnection
		Dim cmmUserMan As OleDbCommand
		Dim drdUser As OleDbDataReader
		Dim strSQL As String
		Dim lngCounter As Long = 0

		' Instantiate the connection
		cnnUserMan = New OleDbConnection(PR_STR_CONNECTION_STRING)
		' Open the connection
		cnnUserMan.Open()
		' Build query string
		strSQL = "SELECT * FROM tblUser"
		' Instantiate the command
		cmmUserMan = New OleDbCommand(strSQL, cnnUserMan)
		' Excute command and return rows in data reader
		drdUser = cmmUserMan.ExecuteReader()
		' Loop through all the returned rows
		Do While drdUser.Read
			lngCounter = lngCounter + 1
		Loop

		' Display the number of rows returned
		MsgBox(CStr(lngCounter))
	End Sub

	Public Sub CheckForNullValueInColumn(ByVal vintColumn As Integer)
		Dim cnnUserMan As OleDbConnection
		Dim cmmUserMan As OleDbCommand
		Dim drdUser As OleDbDataReader
		Dim strSQL As String

		' Instantiate the connection
		cnnUserMan = New OleDbConnection(PR_STR_CONNECTION_STRING)
		' Open the connection
		cnnUserMan.Open()
		' Build query string
		strSQL = "SELECT * FROM tblUser"
		' Instantiate the command
		cmmUserMan = New OleDbCommand(strSQL, cnnUserMan)
		' Excute command and return rows in data reader
		drdUser = cmmUserMan.ExecuteReader()
		' Advance reader to first row
		drdUser.Read()
		' Check if the column contains a NULL value
		If drdUser.IsDBNull(vintColumn) Then
			MsgBox("Column " & CStr(vintColumn) & " contains a NULL value!")
		Else
			MsgBox("Column " & CStr(vintColumn) & " does not contain a NULL value!")
		End If
	End Sub

	' Listing 3A-31
	Public Sub InstantiateAndInitializeDataAdapter()
		Const STR_SQL_USER As String = "SELECT * FROM tblUser"

		Dim cnnUserMan As OleDbConnection
		Dim cmmUser As OleDbCommand
		Dim dadDefaultConstructor As OleDbDataAdapter
		Dim dadOleDbCommandArgument As OleDbDataAdapter
		Dim dadOleDbConnectionArgument As OleDbDataAdapter
		Dim dadStringArguments As OleDbDataAdapter

		' Instantiate and open the connection
		cnnUserMan = New OleDbConnection(PR_STR_CONNECTION_STRING)
		cnnUserMan.Open()
		' Instantiate the command
		cmmUser = New OleDbCommand(STR_SQL_USER)

		' Instantiate data adapters
		dadDefaultConstructor = New OleDbDataAdapter()
		dadOleDbCommandArgument = New OleDbDataAdapter(cmmUser)
		dadOleDbConnectionArgument = New OleDbDataAdapter(STR_SQL_USER, cnnUserMan)
		dadStringArguments = New OleDbDataAdapter(STR_SQL_USER, PR_STR_CONNECTION_STRING)
		' Initialize data adapters
		dadDefaultConstructor.SelectCommand = cmmUser
		dadDefaultConstructor.SelectCommand.Connection = cnnUserMan
	End Sub

	' Listing 3A-33
	Public Sub SetDataAdapterCommandProperties()
		Const STR_SQL_USER_SELECT As String = "SELECT * FROM tblUser"
		Const STR_SQL_USER_DELETE As String = "DELETE FROM tblUser WHERE Id=@Id"
		Const STR_SQL_USER_INSERT As String = "INSERT INTO tblUser(FirstName, " & _
		 "LastName, LoginName, Password) VALUES(@FirstName, @LastName, @LoginName, @Password)"
		Const STR_SQL_USER_UPDATE As String = "UPDATE tblUser SET FirstName=" & _
		 "@FirstName, LastName=@LastName, LoginName=@LoginName, Password=@Password WHERE Id=@Id"

		Dim cnnUserMan As OleDbConnection
		Dim cmmUserSelect As OleDbCommand
		Dim cmmUserDelete As OleDbCommand
		Dim cmmUserInsert As OleDbCommand
		Dim cmmUserUpdate As OleDbCommand
		Dim dadUserMan As OleDbDataAdapter
		Dim prmSQLDelete, prmSQLUpdate, prmSQLInsert As OleDbParameter

		' Instantiate and open the connection
		cnnUserMan = New OleDbConnection(PR_STR_CONNECTION_STRING)
		cnnUserMan.Open()
		' Instantiate the commands
		cmmUserSelect = New OleDbCommand(STR_SQL_USER_SELECT, cnnUserMan)
		cmmUserDelete = New OleDbCommand(STR_SQL_USER_DELETE, cnnUserMan)
		cmmUserInsert = New OleDbCommand(STR_SQL_USER_INSERT, cnnUserMan)
		cmmUserUpdate = New OleDbCommand(STR_SQL_USER_UPDATE, cnnUserMan)

		' Instantiate data adapter
		dadUserMan = New OleDbDataAdapter(STR_SQL_USER_SELECT, cnnUserMan)
		' Set data adapter command properties
		dadUserMan.SelectCommand = cmmUserSelect
		dadUserMan.InsertCommand = cmmUserInsert
		dadUserMan.DeleteCommand = cmmUserDelete
		dadUserMan.UpdateCommand = cmmUserUpdate

		' Add Delete command parameters
		cmmUserDelete.Parameters.Add("@FirstName", OleDbType.VarChar, 50, "FirstName")
		cmmUserDelete.Parameters.Add("@LastName", OleDbType.VarChar, 50, "LastName")
		cmmUserDelete.Parameters.Add("@LoginName", OleDbType.VarChar, 50, "LoginName")
		cmmUserDelete.Parameters.Add("@Password", OleDbType.VarChar, 50, "Password")

		prmSQLDelete = dadUserMan.DeleteCommand.Parameters.Add("@Id", OleDbType.Integer, Nothing, "Id")
		prmSQLDelete.Direction = ParameterDirection.Input
		prmSQLDelete.SourceVersion = DataRowVersion.Original

		' Add Update command parameters
		cmmUserUpdate.Parameters.Add("@FirstName", OleDbType.VarChar, 50, "FirstName")
		cmmUserUpdate.Parameters.Add("@LastName", OleDbType.VarChar, 50, "LastName")
		cmmUserUpdate.Parameters.Add("@LoginName", OleDbType.VarChar, 50, "LoginName")
		cmmUserUpdate.Parameters.Add("@Password", OleDbType.VarChar, 50, "Password")

		prmSQLUpdate = dadUserMan.UpdateCommand.Parameters.Add("@Id", OleDbType.Integer, Nothing, "Id")
		prmSQLUpdate.Direction = ParameterDirection.Input
		prmSQLUpdate.SourceVersion = DataRowVersion.Original

		' Add insert command parameters
		cmmUserInsert.Parameters.Add("@FirstName", OleDbType.VarChar, 50, "FirstName")
		cmmUserInsert.Parameters.Add("@LastName", OleDbType.VarChar, 50, "LastName")
		cmmUserInsert.Parameters.Add("@LoginName", OleDbType.VarChar, 50, "LoginName")
		cmmUserInsert.Parameters.Add("@Password", OleDbType.VarChar, 50, "Password")
	End Sub

	Public Sub InstantiateDataSet()
		Dim dstUnnamed1 As New DataSet()
		Dim dstNamed1 As New DataSet("UserManDataSet")

		Dim dstUnnamed2 As DataSet
		Dim dstNamed2 As DataSet

		dstUnnamed2 = New DataSet()
		dstNamed2 = New DataSet("UserManDataSet")
	End Sub

	' Listing 3B-2
	Public Sub FillDataSetFromRecordset()
		Const STR_SQL_USER_SELECT As String = "SELECT * FROM tblUser"

		Dim cnnUserMan As OleDbConnection
		Dim dadUserMan As OleDbDataAdapter
		Dim dstUserMan As DataSet

		Dim rstUser As ADODB.Recordset
		Dim cnnADOUserMan As ADODB.Connection

		Dim intNumRows As Integer

		' Instantiate and open the connections
		cnnUserMan = New OleDbConnection(PR_STR_CONNECTION_STRING)
		cnnUserMan.Open()
		cnnADOUserMan = New ADODB.Connection()
		cnnADOUserMan.Open(PR_STR_CONNECTION_STRING)

		' Instantiate data adapter
		dadUserMan = New OleDbDataAdapter(STR_SQL_USER_SELECT, cnnUserMan)

		' Instantiate dataset
		dstUserMan = New DataSet()
		' Instantiate recordset
		rstUser = New ADODB.Recordset()

		' Populate recordset
		rstUser.Open(STR_SQL_USER_SELECT, cnnADOUserMan)
		' Fill dataset
		intNumRows = dadUserMan.Fill(dstUserMan, rstUser, "tblUser")
	End Sub

	' Listing 3B-3
	Public Sub UpdateDataSet()
		Const STR_SQL_USER_SELECT As String = "SELECT * FROM tblUser"
		Const STR_SQL_USER_DELETE As String = "DELETE FROM tblUser WHERE Id=?"
		Const STR_SQL_USER_INSERT As String = "INSERT INTO tblUser(FirstName" & _
		 ", LastName, LoginName, Password) VALUES(?, ?, ?, ?)"
		Const STR_SQL_USER_UPDATE As String = "UPDATE tblUser SET FirstName=" & _
		 "?, LastName=?, LoginName=?, Password=? WHERE Id=?"

		Dim cnnUserMan As OleDbConnection
		Dim cmmUserSelect As OleDbCommand
		Dim cmmUserDelete As OleDbCommand
		Dim cmmUserInsert As OleDbCommand
		Dim cmmUserUpdate As OleDbCommand
		Dim dadUserMan As OleDbDataAdapter
		Dim dstUserMan, dstChanges As DataSet
		Dim drwUser As DataRow
		Dim prmSQLDelete, prmSQLUpdate, prmSQLInsert As OleDbParameter

		' Instantiate and open the connection
		cnnUserMan = New OleDbConnection(PR_STR_CONNECTION_STRING)
		cnnUserMan.Open()

		' Instantiate the commands
		cmmUserSelect = New OleDbCommand(STR_SQL_USER_SELECT, cnnUserMan)
		cmmUserDelete = New OleDbCommand(STR_SQL_USER_DELETE, cnnUserMan)
		cmmUserInsert = New OleDbCommand(STR_SQL_USER_INSERT, cnnUserMan)
		cmmUserUpdate = New OleDbCommand(STR_SQL_USER_UPDATE, cnnUserMan)

		' Instantiate data adapter
		dadUserMan = New OleDbDataAdapter(STR_SQL_USER_SELECT, cnnUserMan)
		' Set data adapter command properties
		dadUserMan.SelectCommand = cmmUserSelect
		dadUserMan.InsertCommand = cmmUserInsert
		dadUserMan.DeleteCommand = cmmUserDelete
		dadUserMan.UpdateCommand = cmmUserUpdate

		' Add Delete command parameters
		cmmUserDelete.Parameters.Add("@FirstName", OleDbType.VarChar, 50)
		cmmUserDelete.Parameters.Add("@LastName", OleDbType.VarChar, 50)
		cmmUserDelete.Parameters.Add("@LoginName", OleDbType.VarChar, 50)
		cmmUserDelete.Parameters.Add("@Password", OleDbType.VarChar, 50)

		prmSQLDelete = dadUserMan.DeleteCommand.Parameters.Add("@Id", OleDbType.Integer, Nothing)
		prmSQLDelete.Direction = ParameterDirection.Input
		prmSQLDelete.SourceVersion = DataRowVersion.Original

		' Add Update command parameters
		cmmUserUpdate.Parameters.Add("@FirstName", OleDbType.VarChar, 50)
		cmmUserUpdate.Parameters.Add("@LastName", OleDbType.VarChar, 50)
		cmmUserUpdate.Parameters.Add("@LoginName", OleDbType.VarChar, 50)
		cmmUserUpdate.Parameters.Add("@Password", OleDbType.VarChar, 50)

		prmSQLUpdate = dadUserMan.UpdateCommand.Parameters.Add("@Id", OleDbType.Integer, Nothing)
		prmSQLUpdate.Direction = ParameterDirection.Input
		prmSQLUpdate.SourceVersion = DataRowVersion.Original

		' Add insert command parameters
		cmmUserInsert.Parameters.Add("@FirstName", OleDbType.VarChar, 50, "FirstName")
		cmmUserInsert.Parameters.Add("@LastName", OleDbType.VarChar, 50, "LastName")
		cmmUserInsert.Parameters.Add("@LoginName", OleDbType.VarChar, 50, "LoginName")
		cmmUserInsert.Parameters.Add("@Password", OleDbType.VarChar, 50, "Password")

		' Instantiate dataset
		dstUserMan = New DataSet()
		' Populate the data set
		dadUserMan.Fill(dstUserMan, "tblUser")

		' Add new row
		drwUser = dstUserMan.Tables("tblUser").NewRow()
		drwUser("FirstName") = "New User"
		drwUser("LastName") = "New User LastName"
		drwUser("LoginName") = "NewUser"
		drwUser("Password") = "password"
		dstUserMan.Tables("tblUser").Rows.Add(drwUser)

		' Update an existing row (with index 3)
		dstUserMan.Tables("tblUser").Rows(3)("FirstName") = "FirstName"
		dstUserMan.Tables("tblUser").Rows(3)("LastName") = "LastName"
		dstUserMan.Tables("tblUser").Rows(3)("LoginName") = "User3"

		' Delete row with index 4
		dstUserMan.Tables("tblUser").Rows(4).Delete()

		' Check if any data has changed in the data set
		If dstUserMan.HasChanges() Then
			' Save all changed rows in a new data set
			dstChanges = dstUserMan.GetChanges()
			' Check if the changed rows contains any errors
			If dstChanges.HasErrors() Then
				' Reject the changes
				dstUserMan.RejectChanges()
			Else
				' Update the data source
				dadUserMan.Update(dstChanges, "tblUser")
			End If
		End If
	End Sub

	' Listing 3B-4
	Public Sub ClearDataSet()
		Dim cnnUserMan As OleDbConnection
		Dim cmmUser As OleDbCommand
		Dim dadUser As OleDbDataAdapter
		Dim dstUser As DataSet

		' Instantiate and open the connection
		cnnUserMan = New OleDbConnection(PR_STR_CONNECTION_STRING)
		cnnUserMan.Open()
		' Instantiate the command
		cmmUser = New OleDbCommand("SELECT * FROM tblUser", cnnUserMan)
		' Instantiate and initialize the data adapter
		dadUser = New OleDbDataAdapter()
		dadUser.SelectCommand = cmmUser
		' Instantiate data set
		dstUser = New DataSet()
		' Fill the data set
		dadUser.Fill(dstUser, "tblUser")
		' Do your stuff
		' ...
		' Clear the data from the data set
		dstUser.Clear()
	End Sub

	' Listing 3B-5
	Public Sub CloneDataSetStructure()
		Dim cnnUserMan As OleDbConnection
		Dim cmmUser As OleDbCommand
		Dim dadUser As OleDbDataAdapter
		Dim dstUser As DataSet
		Dim dstClone As DataSet

		' Instantiate and open the connection
		cnnUserMan = New OleDbConnection(PR_STR_CONNECTION_STRING)
		cnnUserMan.Open()
		' Instantiate the command and data set
		cmmUser = New OleDbCommand("SELECT * FROM tblUser", cnnUserMan)
		dstUser = New DataSet()
		' Instantiate and initialize the data adapter
		dadUser = New OleDbDataAdapter("SELECT * FROM tblUser", cnnUserMan)
		dadUser.SelectCommand = cmmUser
		' Fill the data set
		dadUser.Fill(dstUser, "tblUser")
		' Clone the data set
		dstClone = dstUser.Clone()
	End Sub

	' Listing 3B-6
	Public Sub CopyDataSetStructureAndData()
		Dim cnnUserMan As OleDbConnection
		Dim cmmUser As OleDbCommand
		Dim dadUser As OleDbDataAdapter
		Dim dstUser As DataSet
		Dim dstCopy As DataSet

		' Instantiate and open the connection
		cnnUserMan = New OleDbConnection(PR_STR_CONNECTION_STRING)
		cnnUserMan.Open()
		' Instantiate the command and data set
		cmmUser = New OleDbCommand("SELECT * FROM tblUser", cnnUserMan)
		dstUser = New DataSet()
		' Instantiate and initialize the data adapter
		dadUser = New OleDbDataAdapter("SELECT * FROM tblUser", cnnUserMan)
		dadUser.SelectCommand = cmmUser
		' Fill the data set
		dadUser.Fill(dstUser, "tblUser")
		' Copy the data set
		dstCopy = dstUser.Copy()
	End Sub

	' Listing 3B-7
	Public Sub MergeDataSetWithDataRows()
		Dim cnnUserMan As OleDbConnection
		Dim cmmUser As OleDbCommand
		Dim dadUser As OleDbDataAdapter
		Dim dstUser As DataSet
		Dim dtbUser As DataTable
		Dim arrdrwUser(0) As DataRow
		Dim drwUser As DataRow

		' Instantiate and open the connection
		cnnUserMan = New OleDbConnection(PR_STR_CONNECTION_STRING)
		cnnUserMan.Open()
		' Instantiate the command, data set and data table
		cmmUser = New OleDbCommand("SELECT * FROM tblUser", cnnUserMan)
		dstUser = New DataSet()
		dtbUser = New DataTable()
		' Instantiate and initialize the data adapter
		dadUser = New OleDbDataAdapter("SELECT * FROM tblUser", cnnUserMan)
		dadUser.SelectCommand = cmmUser
		' Fill the data set
		dadUser.Fill(dstUser, "tblUser")
		' Create new row and fill with data
		drwUser = dstUser.Tables("tblUser").NewRow()
		drwUser("LoginName") = "NewUser1"
		drwUser("FirstName") = "New"
		drwUser("LastName") = "User"
		arrdrwUser.SetValue(drwUser, 0)
		' Merge the data set with the data row array
		dstUser.Merge(arrdrwUser)
	End Sub

	' Listing 3B-8
	Public Sub MergeDataSets()
		Dim cnnUserMan As OleDbConnection
		Dim cmmUser As OleDbCommand
		Dim dadUser As OleDbDataAdapter
		Dim dstUser As DataSet
		Dim dstCopy As DataSet

		' Instantiate and open the connection
		cnnUserMan = New OleDbConnection(PR_STR_CONNECTION_STRING)
		cnnUserMan.Open()
		' Instantiate the command and data set
		cmmUser = New OleDbCommand("SELECT * FROM tblUser", cnnUserMan)
		dstUser = New DataSet()
		' Instantiate and initialize the data adapter
		dadUser = New OleDbDataAdapter("SELECT * FROM tblUser", cnnUserMan)
		dadUser.SelectCommand = cmmUser
		' Fill the data set
		: dadUser.Fill(dstUser, "tblUser")
		' Copy the data set
		dstCopy = dstUser.Copy()
		' Do your stuff with the data sets
		' ...
		' Merge the two data sets
		dstUser.Merge(dstCopy)
	End Sub

	' Listing 3B-9
	Public Sub MergeDataSetWithDataTable()
		Dim cnnUserMan As OleDbConnection
		Dim cmmUser As OleDbCommand
		Dim dadUser As OleDbDataAdapter
		Dim dstUser As DataSet
		Dim dtbUser As DataTable

		' Instantiate and open the connection
		cnnUserMan = New OleDbConnection(PR_STR_CONNECTION_STRING)
		cnnUserMan.Open()
		' Instantiate the command, data set and data table
		cmmUser = New OleDbCommand("SELECT * FROM tblUser", cnnUserMan)
		dstUser = New DataSet()
		dtbUser = New DataTable()
		' Instantiate and initialize the data adapter
		dadUser = New OleDbDataAdapter("SELECT * FROM tblUser", cnnUserMan)
		dadUser.SelectCommand = cmmUser
		' Fill the data set and data table
		dadUser.Fill(dstUser, "tblUser")
		dadUser.Fill(dtbUser)
		' Do your stuff with the data set and the data table
		' ...
		' Merge the data set with the data table
		dstUser.Merge(dtbUser)
	End Sub

	' Listing 3B-10
	Public Sub DetectAllDataSetChanges()
		Dim cnnUserMan As OleDbConnection
		Dim cmmUser As OleDbCommand
		Dim dadUser As OleDbDataAdapter
		Dim dstUser As DataSet
		Dim dstChanges As DataSet

		' Instantiate and open the connection
		cnnUserMan = New OleDbConnection(PR_STR_CONNECTION_STRING)
		cnnUserMan.Open()
		' Instantiate the command and data set
		cmmUser = New OleDbCommand("SELECT * FROM tblUser", cnnUserMan)
		dstUser = New DataSet()
		' Instantiate and initialize the data adapter
		dadUser = New OleDbDataAdapter("SELECT * FROM tblUser", cnnUserMan)
		dadUser.SelectCommand = cmmUser
		' Fill the data set
		dadUser.Fill(dstUser, "tblUser")
		' Do your stuff with the data set
		' ...
		' Check if any data has changed in the data set
		If dstUser.HasChanges() Then
			' Save all changes in a new data set
			dstChanges = dstUser.GetChanges()
		End If
	End Sub

	' Listing 3B-11
	Public Sub DetectDifferentDataSetChanges()
		Dim cnnUserMan As OleDbConnection
		Dim cmmUser As OleDbCommand
		Dim dadUser As OleDbDataAdapter
		Dim dstUser As DataSet
		Dim dstChanges As DataSet
		Dim dstAdditions As DataSet
		Dim dstDeletions As DataSet

		' Instantiate and open the connection
		cnnUserMan = New OleDbConnection(PR_STR_CONNECTION_STRING)
		cnnUserMan.Open()
		' Instantiate the command and data set
		cmmUser = New OleDbCommand("SELECT * FROM tblUser", cnnUserMan)
		dstUser = New DataSet()
		' Instantiate and initialize the data adapter
		dadUser = New OleDbDataAdapter("SELECT * FROM tblUser", cnnUserMan)
		dadUser.SelectCommand = cmmUser
		' Fill the data set
		dadUser.Fill(dstUser, "tblUser")
		' Do your stuff with the data set
		' ...
		' Check if any data has changed in the data set
		If dstUser.HasChanges() Then
			' Save all modified rows in a new data set
			dstChanges = dstUser.GetChanges(DataRowState.Modified)
			' Save all added rows in a new data set
			dstAdditions = dstUser.GetChanges(DataRowState.Added)
			' Save all deleted rows in a new data set
			dstDeletions = dstUser.GetChanges(DataRowState.Deleted)
		End If
	End Sub

	' Listing 3B-12
	Public Sub AcceptOrRejectDataSetChanges()
		Dim cnnUserMan As OleDbConnection
		Dim cmmUser As OleDbCommand
		Dim dadUser As OleDbDataAdapter
		Dim dstUser, dstChanges As DataSet
		Dim drwUser As DataRow
		Dim intCounter As Integer

		' Instantiate and open the connection
		cnnUserMan = New OleDbConnection(PR_STR_CONNECTION_STRING)
		cnnUserMan.Open()
		' Instantiate the command and the data set
		cmmUser = New OleDbCommand("SELECT * FROM tblUser", cnnUserMan)
		dstUser = New DataSet()
		' Instantiate and initialize the data adapter
		dadUser = New OleDbDataAdapter("SELECT * FROM tblUser", cnnUserMan)
		dadUser.SelectCommand = cmmUser
		' Fill the data set
		dadUser.Fill(dstUser, "tblUser")
		' Create a new data row with the schema from the user table
		drwUser = dstUser.Tables("tblUser").NewRow()
		' Enter values in the data row columns
		drwUser("LoginName") = "NewUser1"
		drwUser("FirstName") = "New"
		drwUser("LastName") = "User"
		' Add the data row to the user table
		dstUser.Tables("tblUser").Rows.Add(drwUser)
		' Check if any data has changed in the data set
		If dstUser.HasChanges() Then
			' Save all changed rows in a new data set
			dstChanges = dstUser.GetChanges()
			' Check if the changed rows contains any errors
			If dstChanges.HasErrors() Then
				' Display the row state of all rows before rejecting changes
				For intCounter = 0 To dstUser.Tables(0).Rows.Count - 1
					MsgBox("HasErrors=True, Before RejectChanges, RowState=" & _
					 dstUser.Tables(0).Rows(intCounter).RowState.ToString & _
					 ", LoginName=" & _
					 dstUser.Tables(0).Rows(intCounter)("LoginName").ToString)
				Next
				' Reject the changes to the data set
				dstUser.RejectChanges()
				' Display the row state of all rows after rejecting changes
				For intCounter = 0 To dstUser.Tables(0).Rows.Count - 1
					MsgBox("HasErrors=True, After RejectChanges, RowState=" & _
					 dstUser.Tables(0).Rows(intCounter).RowState.ToString & _
					 ", LoginName=" & _
					 dstUser.Tables(0).Rows(intCounter)("LoginName").ToString)
				Next
			Else
				' Display the row state of all rows before accepting changes
				For intCounter = 0 To dstUser.Tables(0).Rows.Count - 1
					MsgBox("HasErrors=False, Before AcceptChanges, RowState=" & _
					 dstUser.Tables(0).Rows(intCounter).RowState.ToString & _
					 ", LoginName=" & _
					 dstUser.Tables(0).Rows(intCounter)("LoginName").ToString)
				Next
				' Accept the changes to the data set
				dstUser.AcceptChanges()
				' Display the row state of all rows after accepting changes
				For intCounter = 0 To dstUser.Tables(0).Rows.Count - 1
					MsgBox("HasErrors=False, After AcceptChanges, RowState=" & _
					 dstUser.Tables(0).Rows(intCounter).RowState.ToString & _
					 ", LoginName=" & _
					 dstUser.Tables(0).Rows(intCounter)("LoginName").ToString)
				Next
			End If
		End If
	End Sub

	Public Sub InstantiateDataTable()
		Dim dtbNoArgumentsWithInitialize As New DataTable()
		Dim dtbTableNameArgumentWithInitialize As New DataTable("TableName")

		Dim dtbNoArgumentsWithoutInitialize As DataTable
		Dim dtbTableNameArgumentWithoutInitialize As DataTable

		dtbNoArgumentsWithoutInitialize = New DataTable()
		dtbTableNameArgumentWithoutInitialize = New DataTable("TableName")
	End Sub

	' Listing 3B-13
	Public Sub BuildDataTable()
		Dim dtbUser As DataTable
		Dim drwUser As DataRow
		Dim dclUser As DataColumn
		Dim arrdclPrimaryKey(0) As DataColumn

		dtbUser = New DataTable("tblUser")

		' Create table structure
		dclUser = New DataColumn()
		dclUser.ColumnName = "Id"
		dclUser.DataType = Type.GetType("System.Int32")
		dclUser.AutoIncrement = True
		dclUser.AutoIncrementSeed = 1
		dclUser.AutoIncrementStep = 1
		dclUser.AllowDBNull = False
		' Add column to data table structure
		dtbUser.Columns.Add(dclUser)
		' Add column to PK array
		arrdclPrimaryKey(0) = dclUser
		' Set primary key
		dtbUser.PrimaryKey = arrdclPrimaryKey

		dclUser = New DataColumn()
		dclUser.ColumnName = "ADName"
		dclUser.DataType = Type.GetType("System.String")
		' Add column to data table structure
		dtbUser.Columns.Add(dclUser)

		dclUser = New DataColumn()
		dclUser.ColumnName = "ADSID"
		dclUser.DataType = Type.GetType("System.Guid")
		' Add column to data table structure
		dtbUser.Columns.Add(dclUser)

		dclUser = New DataColumn()
		dclUser.ColumnName = "FirstName"
		dclUser.DataType = Type.GetType("System.String")
		' Add column to data table structure
		dtbUser.Columns.Add(dclUser)

		dclUser = New DataColumn()
		dclUser.ColumnName = "LastName"
		dclUser.DataType = Type.GetType("System.String")
		' Add column to data table structure
		dtbUser.Columns.Add(dclUser)

		dclUser = New DataColumn()
		dclUser.ColumnName = "LoginName"
		dclUser.DataType = Type.GetType("System.String")
		dclUser.AllowDBNull = False
		dclUser.Unique = True
		' Add column to data table structure
		dtbUser.Columns.Add(dclUser)
		dclUser = New DataColumn()
		dclUser.ColumnName = "Password"
		dclUser.DataType = Type.GetType("System.String")
		dclUser.AllowDBNull = False
		' Add column to data table structure
		dtbUser.Columns.Add(dclUser)
	End Sub

	' Listing 3B-14
	Public Sub ClearDataTable()
		Dim cnnUserMan As OleDbConnection
		Dim cmmUser As OleDbCommand
		Dim dadUser As OleDbDataAdapter
		Dim dtbUser As DataTable

		' Instantiate and open the connection
		cnnUserMan = New OleDbConnection(PR_STR_CONNECTION_STRING)

		cnnUserMan.Open()
		' Instantiate the command
		cmmUser = New OleDbCommand("SELECT * FROM tblUser", cnnUserMan)
		' Instantiate and initialize the data adapter
		dadUser = New OleDbDataAdapter()
		dadUser.SelectCommand = cmmUser
		' Instantiate data table
		dtbUser = New DataTable("tblUser")
		' Fill the data table
		dadUser.Fill(dtbUser)
		' Do your stuff
		' ...
		' Clear the data from the data table
		dtbUser.Clear()
	End Sub

	' Listing 3B-15
	Public Sub CloneDataTableStructure()
		Dim cnnUserMan As OleDbConnection
		Dim cmmUser As OleDbCommand
		Dim dadUser As OleDbDataAdapter
		Dim dtbUser As DataTable
		Dim dtbClone As DataTable

		' Instantiate and open the connection
		cnnUserMan = New OleDbConnection(PR_STR_CONNECTION_STRING)
		cnnUserMan.Open()
		' Instantiate the command and data table
		cmmUser = New OleDbCommand("SELECT * FROM tblUser", cnnUserMan)
		dtbUser = New DataTable()
		' Instantiate and initialize the data adapter
		dadUser = New OleDbDataAdapter("SELECT * FROM tblUser", cnnUserMan)
		dadUser.SelectCommand = cmmUser
		' Fill the data table
		dadUser.Fill(dtbUser)
		' Clone the data table
		dtbClone = dtbUser.Clone()
	End Sub

	' Listing 3B-16
	Public Sub CopyDataTable()
		Dim cnnUserMan As OleDbConnection
		Dim cmmUser As OleDbCommand
		Dim dadUser As OleDbDataAdapter
		Dim dtbUser As DataTable
		Dim dtbCopy As DataTable

		' Instantiate and open the connection
		cnnUserMan = New OleDbConnection(PR_STR_CONNECTION_STRING)
		cnnUserMan.Open()
		' Instantiate the command and data tables
		cmmUser = New OleDbCommand("SELECT * FROM tblUser", cnnUserMan)
		dtbUser = New DataTable()
		' Instantiate and initialize the data adapter
		dadUser = New OleDbDataAdapter("SELECT * FROM tblUser", cnnUserMan)
		dadUser.SelectCommand = cmmUser
		' Fill the data table
		dadUser.Fill(dtbUser)
		' Copy the data table
		dtbCopy = dtbUser.Copy()
	End Sub

	' Listing 3B-17
	Public Sub SearchDataTable()
		Dim cnnUserMan As OleDbConnection
		Dim cmmUser As OleDbCommand
		Dim dadUser As OleDbDataAdapter
		Dim dtbUser As DataTable
		Dim intCounter As Integer

		' Instantiate and open the connection
		cnnUserMan = New OleDbConnection(PR_STR_CONNECTION_STRING)
		cnnUserMan.Open()
		' Instantiate the command and data table
		cmmUser = New OleDbCommand("SELECT * FROM tblUser", cnnUserMan)
		dtbUser = New DataTable()
		' Instantiate and initialize the data adapter
		dadUser = New OleDbDataAdapter("SELECT * FROM tblUser", cnnUserMan)
		dadUser.SelectCommand = cmmUser
		' Fill the data table
		dadUser.Fill(dtbUser)
		' Filter the data table view
		dtbUser.DefaultView.RowFilter = "LastName = 'Doe'"

		' Loop through all the rows in the data table view
		For intCounter = 0 To dtbUser.DefaultView.Count - 1
			MsgBox(dtbUser.DefaultView(0).Row("LastName").ToString())
		Next
	End Sub

	Public Sub InstantiateDataView()
		Dim dstUser As New DataSet()

		Dim dvwNoArgumentsWithInitializer As New DataView()
		Dim dvwTableArgumentWithInitializer As New DataView(dstUser.Tables("tblUser"))

		Dim dvwNoArgumentsWithoutInitializer As DataView
		Dim dvwTableArgumentWithoutInitializer As DataView

		dvwNoArgumentsWithoutInitializer = New DataView()
		dvwTableArgumentWithoutInitializer = New DataView(dstUser.Tables("tblUser"))
	End Sub

	' Listing 3B-18
	Public Sub SearchDataView()
		Dim cnnUserMan As OleDbConnection
		Dim cmmUser As OleDbCommand
		Dim dadUser As OleDbDataAdapter
		Dim dtbUser As DataTable
		Dim dvwUser As DataView
		Dim objPKValue As Object
		Dim intIndex As Integer

		' Instantiate and open the connection
		cnnUserMan = New OleDbConnection(PR_STR_CONNECTION_STRING)
		cnnUserMan.Open()
		' Instantiate the command and data table
		cmmUser = New OleDbCommand("SELECT * FROM tblUser", cnnUserMan)
		dtbUser = New DataTable()
		' Instantiate and initialize the data adapter
		dadUser = New OleDbDataAdapter("SELECT * FROM tblUser", cnnUserMan)
		dadUser.SelectCommand = cmmUser
		' Fill the data table
		dadUser.Fill(dtbUser)
		' Filter the data table view
		dtbUser.DefaultView.RowFilter = "LastName = 'Doe'"
		' Create the new data view
		dvwUser = dtbUser.DefaultView
		' Specify a sort order
		dvwUser.Sort = "Id ASC"
		' Find the user with an id of 1
		objPKValue = 1
		intIndex = dvwUser.Find(objPKValue)
	End Sub

	Public Sub InstantiateDataRow()
		Dim dtbUser As New DataTable()
		Dim drwUser As DataRow

		drwUser = dtbUser.NewRow()
	End Sub
End Module