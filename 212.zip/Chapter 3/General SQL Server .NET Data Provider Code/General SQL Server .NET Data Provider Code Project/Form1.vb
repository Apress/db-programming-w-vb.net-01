Public Class Form1
	Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

	Public Sub New()
		MyBase.New()

		'This call is required by the Windows Form Designer.
		InitializeComponent()

		'Add any initialization after the InitializeComponent() call

	End Sub

	'Form overrides dispose to clean up the component list.
	Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
		If disposing Then
			If Not (components Is Nothing) Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(disposing)
	End Sub
	Friend WithEvents btnOpenConnection As System.Windows.Forms.Button
	Friend WithEvents btnCheckConnectionPooling As System.Windows.Forms.Button
	Friend WithEvents btnBeginTransaction As System.Windows.Forms.Button
	Friend WithEvents btnSavePoints As System.Windows.Forms.Button
	Friend WithEvents btnDetermineIsolationLevel As System.Windows.Forms.Button
	Friend WithEvents btnMisc As System.Windows.Forms.Button
	Friend WithEvents btnInstantiateCommand As System.Windows.Forms.Button
	Friend WithEvents btnExecuteNonQuery As System.Windows.Forms.Button
	Friend WithEvents btnExecuteReader As System.Windows.Forms.Button
	Friend WithEvents btnExecuteScalar As System.Windows.Forms.Button
	Friend WithEvents btnExecuteXmlReader As System.Windows.Forms.Button
	Friend WithEvents btnInstantiateDataReader As System.Windows.Forms.Button
	Friend WithEvents btnReadRowsFromDataReader As System.Windows.Forms.Button
	Friend WithEvents btnReadRowsFromXmlReader As System.Windows.Forms.Button
	Friend WithEvents btnInstantiateXmlReader As System.Windows.Forms.Button
	Friend WithEvents lblDescription As System.Windows.Forms.Label
	Friend WithEvents btnInstantiateDataAdapter As System.Windows.Forms.Button
	Friend WithEvents btnSetDataAdapterCommands As System.Windows.Forms.Button
	Friend WithEvents btnUpdateDataSet As System.Windows.Forms.Button
	Friend WithEvents btnClearDataSet As System.Windows.Forms.Button
	Friend WithEvents btnCloneDataSetStructure As System.Windows.Forms.Button
	Friend WithEvents btnCopyDataSet As System.Windows.Forms.Button
	Friend WithEvents btnMergeDataSetWithDataRows As System.Windows.Forms.Button
	Friend WithEvents btnMergeDataSets As System.Windows.Forms.Button
	Friend WithEvents btnMergeDataSetWithDataTable As System.Windows.Forms.Button
	Friend WithEvents btnDetectAllDataSetChanges As System.Windows.Forms.Button
	Friend WithEvents btnDetectDifferentChanges As System.Windows.Forms.Button
	Friend WithEvents btnAcceptOrRejectDataSetChanges As System.Windows.Forms.Button
	Friend WithEvents btnBuildDataTable As System.Windows.Forms.Button
	Friend WithEvents btnClearDataTable As System.Windows.Forms.Button
	Friend WithEvents btnCloneDataTableStructure As System.Windows.Forms.Button
	Friend WithEvents btnCopyDataTable As System.Windows.Forms.Button
	Friend WithEvents btnSearchDataTable As System.Windows.Forms.Button
	Friend WithEvents btnSearchDataView As System.Windows.Forms.Button

	'Required by the Windows Form Designer
	Private components As System.ComponentModel.Container

	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.  
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
		Me.btnBuildDataTable = New System.Windows.Forms.Button()
		Me.btnDetermineIsolationLevel = New System.Windows.Forms.Button()
		Me.btnExecuteNonQuery = New System.Windows.Forms.Button()
		Me.btnCopyDataTable = New System.Windows.Forms.Button()
		Me.btnMergeDataSetWithDataRows = New System.Windows.Forms.Button()
		Me.btnDetectDifferentChanges = New System.Windows.Forms.Button()
		Me.btnClearDataSet = New System.Windows.Forms.Button()
		Me.btnCloneDataSetStructure = New System.Windows.Forms.Button()
		Me.btnSetDataAdapterCommands = New System.Windows.Forms.Button()
		Me.btnMergeDataSetWithDataTable = New System.Windows.Forms.Button()
		Me.btnExecuteXmlReader = New System.Windows.Forms.Button()
		Me.btnExecuteReader = New System.Windows.Forms.Button()
		Me.btnCopyDataSet = New System.Windows.Forms.Button()
		Me.btnSavePoints = New System.Windows.Forms.Button()
		Me.btnMergeDataSets = New System.Windows.Forms.Button()
		Me.btnInstantiateDataReader = New System.Windows.Forms.Button()
		Me.btnInstantiateDataAdapter = New System.Windows.Forms.Button()
		Me.btnUpdateDataSet = New System.Windows.Forms.Button()
		Me.btnReadRowsFromDataReader = New System.Windows.Forms.Button()
		Me.btnInstantiateCommand = New System.Windows.Forms.Button()
		Me.btnInstantiateXmlReader = New System.Windows.Forms.Button()
		Me.btnCheckConnectionPooling = New System.Windows.Forms.Button()
		Me.btnMisc = New System.Windows.Forms.Button()
		Me.btnReadRowsFromXmlReader = New System.Windows.Forms.Button()
		Me.btnClearDataTable = New System.Windows.Forms.Button()
		Me.btnOpenConnection = New System.Windows.Forms.Button()
		Me.btnAcceptOrRejectDataSetChanges = New System.Windows.Forms.Button()
		Me.btnCloneDataTableStructure = New System.Windows.Forms.Button()
		Me.lblDescription = New System.Windows.Forms.Label()
		Me.btnExecuteScalar = New System.Windows.Forms.Button()
		Me.btnBeginTransaction = New System.Windows.Forms.Button()
		Me.btnDetectAllDataSetChanges = New System.Windows.Forms.Button()
		Me.btnSearchDataTable = New System.Windows.Forms.Button()
		Me.btnSearchDataView = New System.Windows.Forms.Button()
		Me.SuspendLayout()
		'
		'btnBuildDataTable
		'
		Me.btnBuildDataTable.Location = New System.Drawing.Point(336, 260)
		Me.btnBuildDataTable.Name = "btnBuildDataTable"
		Me.btnBuildDataTable.Size = New System.Drawing.Size(161, 23)
		Me.btnBuildDataTable.TabIndex = 0
		Me.btnBuildDataTable.Text = "Build DataTable"
		'
		'btnDetermineIsolationLevel
		'
		Me.btnDetermineIsolationLevel.Location = New System.Drawing.Point(2, 248)
		Me.btnDetermineIsolationLevel.Name = "btnDetermineIsolationLevel"
		Me.btnDetermineIsolationLevel.Size = New System.Drawing.Size(203, 23)
		Me.btnDetermineIsolationLevel.TabIndex = 0
		Me.btnDetermineIsolationLevel.Text = "Determine Transaction Isolation Level"
		'
		'btnExecuteNonQuery
		'
		Me.btnExecuteNonQuery.Location = New System.Drawing.Point(208, 150)
		Me.btnExecuteNonQuery.Name = "btnExecuteNonQuery"
		Me.btnExecuteNonQuery.Size = New System.Drawing.Size(124, 23)
		Me.btnExecuteNonQuery.TabIndex = 0
		Me.btnExecuteNonQuery.Text = "Execute Non Query"
		'
		'btnCopyDataTable
		'
		Me.btnCopyDataTable.Location = New System.Drawing.Point(336, 338)
		Me.btnCopyDataTable.Name = "btnCopyDataTable"
		Me.btnCopyDataTable.Size = New System.Drawing.Size(161, 23)
		Me.btnCopyDataTable.TabIndex = 0
		Me.btnCopyDataTable.Text = "Copy DataTable"
		'
		'btnMergeDataSetWithDataRows
		'
		Me.btnMergeDataSetWithDataRows.Location = New System.Drawing.Point(502, 338)
		Me.btnMergeDataSetWithDataRows.Name = "btnMergeDataSetWithDataRows"
		Me.btnMergeDataSetWithDataRows.Size = New System.Drawing.Size(184, 23)
		Me.btnMergeDataSetWithDataRows.TabIndex = 0
		Me.btnMergeDataSetWithDataRows.Text = "Merge DataSet with DataRows"
		'
		'btnDetectDifferentChanges
		'
		Me.btnDetectDifferentChanges.Location = New System.Drawing.Point(502, 442)
		Me.btnDetectDifferentChanges.Name = "btnDetectDifferentChanges"
		Me.btnDetectDifferentChanges.Size = New System.Drawing.Size(184, 23)
		Me.btnDetectDifferentChanges.TabIndex = 0
		Me.btnDetectDifferentChanges.Text = "Detect Different DataSet Changes"
		'
		'btnClearDataSet
		'
		Me.btnClearDataSet.Location = New System.Drawing.Point(502, 260)
		Me.btnClearDataSet.Name = "btnClearDataSet"
		Me.btnClearDataSet.Size = New System.Drawing.Size(184, 23)
		Me.btnClearDataSet.TabIndex = 0
		Me.btnClearDataSet.Text = "Clear DataSet"
		'
		'btnCloneDataSetStructure
		'
		Me.btnCloneDataSetStructure.Location = New System.Drawing.Point(502, 286)
		Me.btnCloneDataSetStructure.Name = "btnCloneDataSetStructure"
		Me.btnCloneDataSetStructure.Size = New System.Drawing.Size(184, 23)
		Me.btnCloneDataSetStructure.TabIndex = 0
		Me.btnCloneDataSetStructure.Text = "Clone DataSet Structure"
		'
		'btnSetDataAdapterCommands
		'
		Me.btnSetDataAdapterCommands.Location = New System.Drawing.Point(502, 150)
		Me.btnSetDataAdapterCommands.Name = "btnSetDataAdapterCommands"
		Me.btnSetDataAdapterCommands.Size = New System.Drawing.Size(184, 23)
		Me.btnSetDataAdapterCommands.TabIndex = 0
		Me.btnSetDataAdapterCommands.Text = "Set DataAdapter Commands"
		'
		'btnMergeDataSetWithDataTable
		'
		Me.btnMergeDataSetWithDataTable.Location = New System.Drawing.Point(502, 390)
		Me.btnMergeDataSetWithDataTable.Name = "btnMergeDataSetWithDataTable"
		Me.btnMergeDataSetWithDataTable.Size = New System.Drawing.Size(184, 23)
		Me.btnMergeDataSetWithDataTable.TabIndex = 0
		Me.btnMergeDataSetWithDataTable.Text = "Merge DataSet with DataTable"
		'
		'btnExecuteXmlReader
		'
		Me.btnExecuteXmlReader.Location = New System.Drawing.Point(208, 234)
		Me.btnExecuteXmlReader.Name = "btnExecuteXmlReader"
		Me.btnExecuteXmlReader.Size = New System.Drawing.Size(124, 23)
		Me.btnExecuteXmlReader.TabIndex = 0
		Me.btnExecuteXmlReader.Text = "Execute XmlReader"
		'
		'btnExecuteReader
		'
		Me.btnExecuteReader.Location = New System.Drawing.Point(208, 178)
		Me.btnExecuteReader.Name = "btnExecuteReader"
		Me.btnExecuteReader.Size = New System.Drawing.Size(124, 23)
		Me.btnExecuteReader.TabIndex = 0
		Me.btnExecuteReader.Text = "Execute Reader"
		'
		'btnCopyDataSet
		'
		Me.btnCopyDataSet.Location = New System.Drawing.Point(502, 312)
		Me.btnCopyDataSet.Name = "btnCopyDataSet"
		Me.btnCopyDataSet.Size = New System.Drawing.Size(184, 23)
		Me.btnCopyDataSet.TabIndex = 0
		Me.btnCopyDataSet.Text = "Copy DataSet Structure && Data"
		'
		'btnSavePoints
		'
		Me.btnSavePoints.Location = New System.Drawing.Point(2, 220)
		Me.btnSavePoints.Name = "btnSavePoints"
		Me.btnSavePoints.Size = New System.Drawing.Size(203, 23)
		Me.btnSavePoints.TabIndex = 0
		Me.btnSavePoints.Text = "Use Transaction Save Points"
		'
		'btnMergeDataSets
		'
		Me.btnMergeDataSets.Location = New System.Drawing.Point(502, 364)
		Me.btnMergeDataSets.Name = "btnMergeDataSets"
		Me.btnMergeDataSets.Size = New System.Drawing.Size(184, 23)
		Me.btnMergeDataSets.TabIndex = 0
		Me.btnMergeDataSets.Text = "Merge DataSets"
		'
		'btnInstantiateDataReader
		'
		Me.btnInstantiateDataReader.Location = New System.Drawing.Point(336, 122)
		Me.btnInstantiateDataReader.Name = "btnInstantiateDataReader"
		Me.btnInstantiateDataReader.Size = New System.Drawing.Size(161, 23)
		Me.btnInstantiateDataReader.TabIndex = 0
		Me.btnInstantiateDataReader.Text = "Instantiate DataReader"
		'
		'btnInstantiateDataAdapter
		'
		Me.btnInstantiateDataAdapter.Location = New System.Drawing.Point(502, 122)
		Me.btnInstantiateDataAdapter.Name = "btnInstantiateDataAdapter"
		Me.btnInstantiateDataAdapter.Size = New System.Drawing.Size(184, 23)
		Me.btnInstantiateDataAdapter.TabIndex = 0
		Me.btnInstantiateDataAdapter.Text = "Instantiate DataAdapter"
		'
		'btnUpdateDataSet
		'
		Me.btnUpdateDataSet.Location = New System.Drawing.Point(502, 234)
		Me.btnUpdateDataSet.Name = "btnUpdateDataSet"
		Me.btnUpdateDataSet.Size = New System.Drawing.Size(184, 23)
		Me.btnUpdateDataSet.TabIndex = 0
		Me.btnUpdateDataSet.Text = "Update DataSet"
		'
		'btnReadRowsFromDataReader
		'
		Me.btnReadRowsFromDataReader.Location = New System.Drawing.Point(336, 150)
		Me.btnReadRowsFromDataReader.Name = "btnReadRowsFromDataReader"
		Me.btnReadRowsFromDataReader.Size = New System.Drawing.Size(161, 23)
		Me.btnReadRowsFromDataReader.TabIndex = 0
		Me.btnReadRowsFromDataReader.Text = "Read Rows from DataReader"
		'
		'btnInstantiateCommand
		'
		Me.btnInstantiateCommand.Location = New System.Drawing.Point(208, 122)
		Me.btnInstantiateCommand.Name = "btnInstantiateCommand"
		Me.btnInstantiateCommand.Size = New System.Drawing.Size(124, 23)
		Me.btnInstantiateCommand.TabIndex = 0
		Me.btnInstantiateCommand.Text = "Instantiate Command"
		'
		'btnInstantiateXmlReader
		'
		Me.btnInstantiateXmlReader.Location = New System.Drawing.Point(336, 178)
		Me.btnInstantiateXmlReader.Name = "btnInstantiateXmlReader"
		Me.btnInstantiateXmlReader.Size = New System.Drawing.Size(161, 23)
		Me.btnInstantiateXmlReader.TabIndex = 0
		Me.btnInstantiateXmlReader.Text = "Instantiate XmlReader"
		'
		'btnCheckConnectionPooling
		'
		Me.btnCheckConnectionPooling.Location = New System.Drawing.Point(2, 150)
		Me.btnCheckConnectionPooling.Name = "btnCheckConnectionPooling"
		Me.btnCheckConnectionPooling.Size = New System.Drawing.Size(203, 23)
		Me.btnCheckConnectionPooling.TabIndex = 0
		Me.btnCheckConnectionPooling.Text = "Check Connection Pooling"
		'
		'btnMisc
		'
		Me.btnMisc.Location = New System.Drawing.Point(2, 66)
		Me.btnMisc.Name = "btnMisc"
		Me.btnMisc.Size = New System.Drawing.Size(203, 23)
		Me.btnMisc.TabIndex = 0
		Me.btnMisc.Text = "Misc."
		'
		'btnReadRowsFromXmlReader
		'
		Me.btnReadRowsFromXmlReader.Location = New System.Drawing.Point(336, 206)
		Me.btnReadRowsFromXmlReader.Name = "btnReadRowsFromXmlReader"
		Me.btnReadRowsFromXmlReader.Size = New System.Drawing.Size(161, 23)
		Me.btnReadRowsFromXmlReader.TabIndex = 0
		Me.btnReadRowsFromXmlReader.Text = "Read Rows from XmlReader"
		'
		'btnClearDataTable
		'
		Me.btnClearDataTable.Location = New System.Drawing.Point(336, 286)
		Me.btnClearDataTable.Name = "btnClearDataTable"
		Me.btnClearDataTable.Size = New System.Drawing.Size(161, 23)
		Me.btnClearDataTable.TabIndex = 0
		Me.btnClearDataTable.Text = "Clear DataTable"
		'
		'btnOpenConnection
		'
		Me.btnOpenConnection.Location = New System.Drawing.Point(2, 122)
		Me.btnOpenConnection.Name = "btnOpenConnection"
		Me.btnOpenConnection.Size = New System.Drawing.Size(203, 23)
		Me.btnOpenConnection.TabIndex = 0
		Me.btnOpenConnection.Text = "Open Connection"
		'
		'btnAcceptOrRejectDataSetChanges
		'
		Me.btnAcceptOrRejectDataSetChanges.Location = New System.Drawing.Point(502, 468)
		Me.btnAcceptOrRejectDataSetChanges.Name = "btnAcceptOrRejectDataSetChanges"
		Me.btnAcceptOrRejectDataSetChanges.Size = New System.Drawing.Size(184, 23)
		Me.btnAcceptOrRejectDataSetChanges.TabIndex = 0
		Me.btnAcceptOrRejectDataSetChanges.Text = "Accept or Reject Detect Changes"
		'
		'btnCloneDataTableStructure
		'
		Me.btnCloneDataTableStructure.Location = New System.Drawing.Point(336, 312)
		Me.btnCloneDataTableStructure.Name = "btnCloneDataTableStructure"
		Me.btnCloneDataTableStructure.Size = New System.Drawing.Size(161, 23)
		Me.btnCloneDataTableStructure.TabIndex = 0
		Me.btnCloneDataTableStructure.Text = "Clone DataTable"
		'
		'lblDescription
		'
		Me.lblDescription.Location = New System.Drawing.Point(33, 16)
		Me.lblDescription.Name = "lblDescription"
		Me.lblDescription.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.lblDescription.Size = New System.Drawing.Size(540, 32)
		Me.lblDescription.TabIndex = 1
		Me.lblDescription.Text = "Not all of the source code has a corresponding button, so please look in the Code" & _
		"Behind file (.vb), for code that doesn't have a button. You can attcah the code " & _
		"to the Misc. button if you want to run it."
		'
		'btnExecuteScalar
		'
		Me.btnExecuteScalar.Location = New System.Drawing.Point(208, 206)
		Me.btnExecuteScalar.Name = "btnExecuteScalar"
		Me.btnExecuteScalar.Size = New System.Drawing.Size(124, 23)
		Me.btnExecuteScalar.TabIndex = 0
		Me.btnExecuteScalar.Text = "Execute Scalar"
		'
		'btnBeginTransaction
		'
		Me.btnBeginTransaction.Location = New System.Drawing.Point(2, 192)
		Me.btnBeginTransaction.Name = "btnBeginTransaction"
		Me.btnBeginTransaction.Size = New System.Drawing.Size(203, 23)
		Me.btnBeginTransaction.TabIndex = 0
		Me.btnBeginTransaction.Text = "Begin Transaction"
		'
		'btnDetectAllDataSetChanges
		'
		Me.btnDetectAllDataSetChanges.Location = New System.Drawing.Point(502, 416)
		Me.btnDetectAllDataSetChanges.Name = "btnDetectAllDataSetChanges"
		Me.btnDetectAllDataSetChanges.Size = New System.Drawing.Size(184, 23)
		Me.btnDetectAllDataSetChanges.TabIndex = 0
		Me.btnDetectAllDataSetChanges.Text = "Detect All DataSet Changes"
		'
		'btnSearchDataTable
		'
		Me.btnSearchDataTable.Location = New System.Drawing.Point(336, 364)
		Me.btnSearchDataTable.Name = "btnSearchDataTable"
		Me.btnSearchDataTable.Size = New System.Drawing.Size(161, 23)
		Me.btnSearchDataTable.TabIndex = 0
		Me.btnSearchDataTable.Text = "Search DataTable"
		'
		'btnSearchDataView
		'
		Me.btnSearchDataView.Location = New System.Drawing.Point(336, 416)
		Me.btnSearchDataView.Name = "btnSearchDataView"
		Me.btnSearchDataView.Size = New System.Drawing.Size(161, 23)
		Me.btnSearchDataView.TabIndex = 0
		Me.btnSearchDataView.Text = "Search DataView"
		'
		'Form1
		'
		Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
		Me.ClientSize = New System.Drawing.Size(693, 507)
		Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnSearchDataView, Me.btnSearchDataTable, Me.btnCopyDataTable, Me.btnCloneDataTableStructure, Me.btnClearDataTable, Me.btnBuildDataTable, Me.btnAcceptOrRejectDataSetChanges, Me.btnDetectDifferentChanges, Me.btnDetectAllDataSetChanges, Me.btnMergeDataSetWithDataTable, Me.btnMergeDataSets, Me.btnMergeDataSetWithDataRows, Me.btnCopyDataSet, Me.btnCloneDataSetStructure, Me.btnClearDataSet, Me.btnUpdateDataSet, Me.btnSetDataAdapterCommands, Me.btnInstantiateDataAdapter, Me.lblDescription, Me.btnReadRowsFromXmlReader, Me.btnInstantiateXmlReader, Me.btnReadRowsFromDataReader, Me.btnInstantiateDataReader, Me.btnExecuteXmlReader, Me.btnExecuteScalar, Me.btnExecuteReader, Me.btnExecuteNonQuery, Me.btnInstantiateCommand, Me.btnMisc, Me.btnDetermineIsolationLevel, Me.btnSavePoints, Me.btnBeginTransaction, Me.btnCheckConnectionPooling, Me.btnOpenConnection})
		Me.Name = "Form1"
		Me.Text = "General SQL Server .NET Data Provider Code"
		Me.ResumeLayout(False)

	End Sub

#End Region

	Private Sub btnOpenConnection_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOpenConnection.Click
		OpenConnection()
	End Sub

	Private Sub btnCheckConnectionPooling_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCheckConnectionPooling.Click
		CheckConnectionPooling()
	End Sub

	Private Sub btnBeginTransaction_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBeginTransaction.Click
		BeginNonDefaultIsolationLevelTransaction()
	End Sub

	Private Sub btnSavePoints_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSavePoints.Click
		UseTransactionSavePoints()
	End Sub

	Private Sub btnDetermineIsolationLevel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDetermineIsolationLevel.Click
		DetermineTransactionIsolationLevel()
	End Sub

	Private Sub btnMisc_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnMisc.Click
		CheckForNullValueInColumn(3)
	End Sub

	Private Sub btnInstantiateCommand_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnInstantiateCommand.Click
		InstantiateCommandObject()
	End Sub

	Private Sub btnExecuteNonQuery_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExecuteNonQuery.Click
		ExecuteNonQueryCommand()
	End Sub

	Private Sub btnExecuteReader_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExecuteReader.Click
		ExecuteReaderCommand()
	End Sub

	Private Sub btnExecuteScalar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExecuteScalar.Click
		ExecuteScalarCommand()
	End Sub

	Private Sub btnExecuteXmlReader_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExecuteXmlReader.Click
		ExecuteXmlReaderCommand()
	End Sub

	Private Sub btnInstantiateDataReader_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnInstantiateDataReader.Click
		InstantiateDataReader()
	End Sub

	Private Sub btnReadRowsFromDataReader_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnReadRowsFromDataReader.Click
		ReadRowsFromDataReader()
	End Sub

	Private Sub btnInstantiateXmlReader_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnInstantiateXmlReader.Click
		InstantiateXmlReader()
	End Sub

	Private Sub btnReadRowsFromXmlReader_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnReadRowsFromXmlReader.Click
		ReadRowsFromXmlReader()
	End Sub

	Private Sub btnInstantiateDataAdapter_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnInstantiateDataAdapter.Click
		InstantiateAndInitializeDataAdapter()
	End Sub

	Private Sub btnSetDataAdapterCommands_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSetDataAdapterCommands.Click
		SetDataAdapterCommandPropertiesUsingCommandBuilder()  'SetDataAdapterCommandProperties()
	End Sub

	Private Sub btnUpdateDataSet_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUpdateDataSet.Click
		UpdateDataSet()
	End Sub

	Private Sub btnClearDataSet_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClearDataSet.Click
		ClearDataSet()
	End Sub

	Private Sub btnCloneDataSetStructure_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCloneDataSetStructure.Click
		CloneDataSetStructure()
	End Sub

	Private Sub btnCopyDataSet_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCopyDataSet.Click
		CopyDataSetStructureAndData()
	End Sub

	Private Sub btnMergeDataSetWithDataRows_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnMergeDataSetWithDataRows.Click
		MergeDataSetWithDataRows()
	End Sub

	Private Sub btnMergeDataSets_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnMergeDataSets.Click
		MergeDataSets()
	End Sub

	Private Sub btnMergeDataSetWithDataTable_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnMergeDataSetWithDataTable.Click
		MergeDataSetWithDataTable()
	End Sub

	Private Sub btnDetectAllDataSetChanges_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDetectAllDataSetChanges.Click
		DetectAllDataSetChanges()
	End Sub

	Private Sub btnDetectDifferentChanges_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDetectDifferentChanges.Click
		DetectDifferentDataSetChanges()
	End Sub

	Private Sub btnAcceptOrRejectDataSetChanges_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAcceptOrRejectDataSetChanges.Click
		AcceptOrRejectDataSetChanges()
	End Sub

	Private Sub btnBuildDataTable_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBuildDataTable.Click
		BuildDataTable()
	End Sub

	Private Sub btnClearDataTable_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClearDataTable.Click
		ClearDataTable()
	End Sub

	Private Sub btnCloneDataTableStructure_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCloneDataTableStructure.Click
		CloneDataTableStructure()
	End Sub

	Private Sub btnCopyDataTable_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCopyDataTable.Click
		CopyDataTable()
	End Sub

	Private Sub btnSearchDataTable_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSearchDataTable.Click
		SearchDataTable()
	End Sub

	Private Sub btnSearchDataView_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSearchDataView.Click
		SearchDataView()
	End Sub
End Class
