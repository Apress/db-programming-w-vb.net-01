Option Strict On

Imports System.Data.SqlClient
Imports System.Xml

Module General
	Private Const PR_STR_CONNECTION_STRING As String = "Data Source=USERMANPC;" & _
	 "User ID=UserMan;Password=userman;Initial Catalog=UserMan"

	' Listing 3A-1
	Public Sub OpenConnection(Optional ByVal vstrConnectionString As String = PR_STR_CONNECTION_STRING)
		' Declare connection object
		Dim cnnUserMan As SqlConnection

		' Instantiate the connection object
		cnnUserMan = New SqlConnection()
		' Set up connection string
		cnnUserMan.ConnectionString = vstrConnectionString

		' Open the connection
		cnnUserMan.Open()
	End Sub

	' Listing 3A-2
	Public Sub CheckConnectionStringWhiteSpace()
		Dim cnnUserMan1 As New SqlConnection()
		Dim cnnUserMan2 As New SqlConnection()

		' Set the connection string for the connections
		cnnUserMan1.ConnectionString = "User Id=UserMan;Password=userman;" & _
		 "Data Source='USERMANPC';Initial Catalog='UserMan';Max Pool Size=1;Connection Timeout=5"
		cnnUserMan2.ConnectionString = "User Id=UserMan;Password=userman; " & _
		 "Data Source='USERMANPC';Initial Catalog='UserMan';Max Pool Size=1;Connection Timeout=5"

		' cnnUserMan1 and cnnUserMan2 will NOT be added to the same connection pool
		' because cnnUserMan2 contains an extra space char right after
		' Password=userman;
		Try
			' Open the cnnUserMan1 connection
			cnnUserMan1.Open()
			' Open the cnnUserMan2 connection
			cnnUserMan2.Open()
		Catch objE As Exception
			' This message will be be displayed if the two connection strings are the same,
			' because then the connection pool will have reached it's max size (1)
			' If you don't see the message, the connections are drawn from different pools
			MsgBox(objE.Message)
		End Try
	End Sub
	' 
	Public Sub CheckConnectionPooling()
		Dim cnnUserMan1 As SqlConnection
		Dim cnnUserMan2 As SqlConnection

		' Instantiate and open the first SQL connection
		cnnUserMan1 = New SqlConnection(PR_STR_CONNECTION_STRING & ";Max Pool Size=1;Connection Timeout=5")
		cnnUserMan1.Open()
		Try
			' Instantiate and open the second SQL connection
			cnnUserMan2 = New SqlConnection(PR_STR_CONNECTION_STRING & ";Max Pool Size=1;Connection Timeout=5")
			cnnUserMan2.Open()
		Catch objE As Exception
			MsgBox(objE.Message)
		End Try
	End Sub

	' Listing 3A-5
	Public Sub BeginNonDefaultIsolationLevelTransaction()
		Dim cnnUserMan As SqlConnection
		Dim strSQL As String
		Dim traUserMan As SqlTransaction

		' Instantiate the connection
		cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
		' Open the connection
		cnnUserMan.Open()
		' Build query string
		strSQL = "SELECT * FROM tblUser"
		' Begin transaction
		traUserMan = cnnUserMan.BeginTransaction(IsolationLevel.ReadCommitted)
	End Sub

	' Listing 3A-6
	Public Sub BeginNamedTransaction()
		Const STR_MAIN_TRANSACTION_NAME As String = "MainTransaction"

		Dim cnnUserMan As SqlConnection
		Dim strSQL As String
		Dim traUserMan As SqlTransaction

		' Instantiate the connection
		cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
		' Open the connection
		cnnUserMan.Open()
		' Build query string
		strSQL = "SELECT * FROM tblUser"
		' Begin transaction
		traUserMan = cnnUserMan.BeginTransaction(STR_MAIN_TRANSACTION_NAME)
	End Sub

	' Listing 3A-7
	Public Sub BeginNamedNonDefaultIsolationLevelTransaction()
		Const STR_MAIN_TRANSACTION_NAME As String = "MainTransaction"

		Dim cnnUserMan As SqlConnection
		Dim strSQL As String
		Dim traUserMan As SqlTransaction

		' Instantiate the connection
		cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
		' Open the connection
		cnnUserMan.Open()
		' Build query string
		strSQL = "SELECT * FROM tblUser"
		' Begin transaction
		traUserMan = cnnUserMan.BeginTransaction(IsolationLevel.ReadCommitted, STR_MAIN_TRANSACTION_NAME)
	End Sub

	' Listing 3A-8
	Public Sub UseTransactionSavePoints()
		Const STR_MAIN_TRANSACTION_NAME As String = "MainTransaction"
		Const STR_FAMILY_TRANSACTION_NAME As String = "FamilyUpdates"
		Const STR_ADDRESS_TRANSACTION_NAME As String = "AddressUpdates"

		Dim cnnUserMan As SqlConnection
		Dim traUserMan As SqlTransaction
		Dim cmmUserMan As SqlCommand

		' Instantiate the connection
		cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
		' Open the connection
		cnnUserMan.Open()

		' Start named transaction
		traUserMan = cnnUserMan.BeginTransaction(STR_MAIN_TRANSACTION_NAME)
		' Update family tables
		' ...

		' Save transaction reference point
		traUserMan.Save(STR_FAMILY_TRANSACTION_NAME)
		' Update address tables
		' ...
		' Save transaction reference point
		traUserMan.Save(STR_ADDRESS_TRANSACTION_NAME)
		' Roll back address table updates
		traUserMan.Rollback(STR_FAMILY_TRANSACTION_NAME)
	End Sub

	' Listing 3A-10
	Public Sub DetermineTransactionIsolationLevel()
		Const STR_MAIN_TRANSACTION_NAME As String = "MainTransaction"

		Dim cnnUserMan As SqlConnection
		Dim traUserMan As SqlTransaction
		Dim intIsolationLevel As Integer

		' Instantiate the connection
		cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
		' Open the connection
		cnnUserMan.Open()

		' Start named transaction with non-default isolation level
		traUserMan = cnnUserMan.BeginTransaction(IsolationLevel.ReadCommitted, _
		 STR_MAIN_TRANSACTION_NAME)

		' Return the isolation level as text
		MsgBox(traUserMan.IsolationLevel.ToString)
		' Return the isolation level as an integer value
		intIsolationLevel = traUserMan.IsolationLevel
		MsgBox(intIsolationLevel)
	End Sub

	' Listing 3A-11
	Public Sub CheckBeginTransactionMethodException()
		Const STR_MAIN_TRANSACTION_NAME As String = "MainTransaction"

		Dim cnnUserMan As SqlConnection
		Dim traUserMan As SqlTransaction

		' Instantiate the connection
		cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
		' Open the connection
		' If the following line is commented out, the BeginTransaction exception will be thrown.
		'cnnUserMan.Open()

		Try
			' Start named transaction with non-default isolation level
			traUserMan = cnnUserMan.BeginTransaction(IsolationLevel.ReadCommitted, _
			 STR_MAIN_TRANSACTION_NAME)
		Catch objException As Exception
			' Check if a BeginTransaction method threw the exception
			If objException.TargetSite.Name = "BeginTransaction" Then
				MsgBox("The BeginTransaction method threw the exception!")
			End If
		End Try
	End Sub

	' Listing 3A-12
	Public Sub CheckConnectionStringPropertyException()
		Dim cnnUserMan As SqlConnection

		' Instantiate the connection
		cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
		' Open the connection
		cnnUserMan.Open()

		Try
			' Set the connection string
			cnnUserMan.ConnectionString = PR_STR_CONNECTION_STRING
		Catch objException As Exception
			' Check if setting the ConnectionString threw the exception
			If objException.TargetSite.Name = "set_ConnectionString" Then
				MsgBox("The ConnectionString property threw the exception!")
			End If
		End Try
	End Sub

	' Listing 3A-13
	Public Sub CheckConnectionTimeoutPropertyException()
		Dim cnnUserMan As SqlConnection

		Try
			' Instantiate the connection
			cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING & ";Connection Timeout=-1")
			' Open the connection
			cnnUserMan.Open()
		Catch objException As Exception
			' Check if setting the Connection Timeout to an invalid value threw the exception
			If objException.TargetSite.Name = "SetConnectTimeout" Then
				MsgBox("The Connection Timeout value threw the exception!")
			End If
		End Try
	End Sub

	' Listing 3A-14
	Public Sub CheckChangeDatabaseMethodException()
		Dim cnnUserMan As SqlConnection

		Try
			' Instantiate the connection
			cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
			' Open the connection
			' If the following line is commented out, the ChangeDatabase exception will be thrown
			'cnnUserMan.Open()
			' Change database
			cnnUserMan.ChangeDatabase("master")
		Catch objException As Exception
			' Check if we tried to change database on an invalid connection
			If objException.TargetSite.Name = "ChangeDatabase" Then
				MsgBox("The ChangeDatabase method threw the exception!")
			End If
		End Try
	End Sub

	' Listing 3A-15
	Public Sub CheckOpenMethodException()
		Dim cnnUserMan As SqlConnection

		Try
			' Instantiate the connection
			cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
			' Open the connection
			cnnUserMan.Open()
			' Open the connection
			cnnUserMan.Open()
		Catch objException As Exception
			' Check if we tried to open an already open connection
			If objException.TargetSite.Name = "Open" Then
				MsgBox("The Open method threw the exception!")
			End If
		End Try
	End Sub

	' Listing 3A-17
	Public Sub InstantiateCommandObject()
		Dim cnnUserMan As SqlConnection
		Dim cmmUserMan As SqlCommand
		Dim strSQL As String

		' Instantiate the connection
		cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
		' Open the connection
		cnnUserMan.Open()
		' Build query string
		strSQL = "SELECT * FROM tblUser"
		' Instantiate the command
		cmmUserMan = New SqlCommand(strSQL, cnnUserMan)
	End Sub

	' Listing 3A-18
	Public Sub ExecuteNonQueryCommand()
		Dim cnnUserMan As SqlConnection
		Dim cmmUserMan As SqlCommand
		Dim strSQL As String

		' Instantiate the connection
		cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
		' Open the connection
		cnnUserMan.Open()
		' Build delete query string
		strSQL = "DELETE FROM tblUser WHERE LoginName='User99'"
		' Instantiate and execute the delete command
		cmmUserMan = New SqlCommand(strSQL, cnnUserMan)
		cmmUserMan.ExecuteNonQuery()
		' Build insert query string
		strSQL = "INSERT INTO tblUser (LoginName) VALUES('User99')"
		' Instantiate and execute the insert command
		cmmUserMan = New SqlCommand(strSQL, cnnUserMan)
		cmmUserMan.ExecuteNonQuery()
	End Sub

	' Listing 3A-19
	Public Sub ExecuteReaderCommand()
		Dim cnnUserMan As SqlConnection
		Dim cmmUserMan As SqlCommand
		Dim drdTest As SqlDataReader
		Dim strSQL As String

		' Instantiate the connection
		cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
		' Open the connection
		cnnUserMan.Open()
		' Build query string
		strSQL = "SELECT * FROM tblUser"
		' Instantiate and execute the command
		cmmUserMan = New SqlCommand(strSQL, cnnUserMan)
		drdTest = cmmUserMan.ExecuteReader()
	End Sub

	' Listing 3A-20
	Public Sub ExecuteScalarCommand()
		Dim cnnUserMan As SqlConnection
		Dim cmmUserMan As SqlCommand
		Dim intNumRows As Integer
		Dim strSQL As String

		' Instantiate the connection
		cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
		' Open the connection
		cnnUserMan.Open()
		' Build query string
		strSQL = "SELECT COUNT(*) FROM tblUser"
		' Instantiate the command
		cmmUserMan = New SqlCommand(strSQL, cnnUserMan)
		' Save the number of rows in the table
		intNumRows = CInt(cmmUserMan.ExecuteScalar().ToString)
	End Sub

	' Listing 3A-21
	Public Sub ExecuteXmlReaderCommand()
		Dim cnnUserMan As SqlConnection
		Dim cmmUserMan As SqlCommand
		Dim drdTest As XmlReader
		Dim strSQL As String

		' Instantiate the connection
		cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
		' Open the connection
		cnnUserMan.Open()
		' Build query string to return result set as XML
		strSQL = "SELECT * FROM tblUser FOR XML AUTO"
		' Instantiate the command
		cmmUserMan = New SqlCommand(strSQL, cnnUserMan)
		' Retrieve the rows as XML
		drdTest = cmmUserMan.ExecuteXmlReader()
	End Sub

	' Listing 3A-22
	Public Sub CheckCommandTimeoutPropertyException()
		Dim cnnUserMan As SqlConnection
		Dim cmmUserMan As SqlCommand
		Dim strSQL As String

		Try
			' Instantiate the connection
			cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
			' Open the connection
			cnnUserMan.Open()
			' Build query string
			strSQL = "SELECT * FROM tblUser"
			' Instantiate the command
			cmmUserMan = New SqlCommand(strSQL, cnnUserMan)
			' Change command timeout
			cmmUserMan.CommandTimeout = -1
		Catch objException As ArgumentException
			' Check if we tried to set command timeout to an invalid value
			If objException.TargetSite.Name = "set_CommandTimeout" Then
				MsgBox("The CommandTimeout property threw the exception.")
			End If
		End Try
	End Sub

	' Listing 3A-23
	Public Sub CheckCommandTypePropertyException()
		Dim cnnUserMan As SqlConnection
		Dim cmmUserMan As SqlCommand
		Dim strSQL As String

		Try
			' Instantiate the connection
			cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
			' Open the connection
			cnnUserMan.Open()
			' Build query string
			strSQL = "SELECT * FROM tblUser"
			' Instantiate the command
			cmmUserMan = New SqlCommand(strSQL, cnnUserMan)
			' Change command type
			cmmUserMan.CommandType = CommandType.TableDirect
		Catch objException As NotSupportedException
			' Check if we tried to set command type to an invalid value
			If objException.TargetSite.Name = "set_CommandType" Then
				MsgBox("The CommandType property threw the exception.")
			End If
		End Try
	End Sub

	' Listing 3A-24
	Public Sub CheckPrepareMethodException()
		Dim cnnUserMan As SqlConnection
		Dim cmmUserMan As SqlCommand
		Dim strSQL As String

		Try
			' Instantiate the connection
			cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
			' Open the connection
			' If the following line is commented out, the ValidateCommand exception will be thrown
			'cnnUserMan.Open()
			' Build query string
			strSQL = "SELECT * FROM tblUser"
			' Instantiate the command
			cmmUserMan = New SqlCommand(strSQL, cnnUserMan)
			' Prepare command
			cmmUserMan.Prepare()
		Catch objException As InvalidOperationException
			' Check if we tried to prepare the command on an invalid connection
			If objException.TargetSite.Name = "ValidateCommand" Then
				MsgBox("The Prepare method threw the exception.")
			End If
		End Try
	End Sub

	' Listing 3A-25
	Public Sub CheckUpdateRowSourcePropertyException()
		Dim cnnUserMan As SqlConnection
		Dim cmmUserMan As SqlCommand
		Dim strSQL As String

		Try
			' Instantiate the connection
			cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
			' Open the connection
			cnnUserMan.Open()
			' Build query string
			strSQL = "SELECT * FROM tblUser"
			' Instantiate the command
			cmmUserMan = New SqlCommand(strSQL, cnnUserMan)
			' Change Row source Update
			' You need to turn Option Strict Off for this to compile
			'cmmUserMan.UpdatedRowSource = 5
		Catch objException As ArgumentException
			' Check if we tried to set the row source update to an invalid value
			If objException.TargetSite.Name = "set_UpdatedRowSource" Then
				MsgBox("The UpdatedRowSource property threw the exception.")
			End If
		End Try
	End Sub

	' Listing 3A-26
	Public Sub InstantiateDataReader()
		Dim cnnUserMan As SqlConnection
		Dim cmmUserMan As SqlCommand
		Dim drdUserMan As SqlDataReader
		Dim strSQL As String

		' Instantiate the connection
		cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
		' Open the connection
		cnnUserMan.Open()
		' Build query string
		strSQL = "SELECT * FROM tblUser"
		' Instantiate the command
		cmmUserMan = New SqlCommand(strSQL, cnnUserMan)
		' Instantiate data reader using the ExecuteReader method 
		' of the command class
		drdUserMan = cmmUserMan.ExecuteReader()
	End Sub

	' Listing 3A-27
	Public Sub ReadRowsFromDataReader()
		Dim cnnUserMan As SqlConnection
		Dim cmmUserMan As SqlCommand
		Dim drdUser As SqlDataReader
		Dim strSQL As String
		Dim lngCounter As Long = 0

		' Instantiate the connection
		cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
		' Open the connection
		cnnUserMan.Open()
		' Build query string
		strSQL = "SELECT * FROM tblUser"
		' Instantiate the command
		cmmUserMan = New SqlCommand(strSQL, cnnUserMan)
		' Excute command and return rows in data reader
		drdUser = cmmUserMan.ExecuteReader()
		' Loop through all the returned rows
		Do While drdUser.Read
			lngCounter = lngCounter + 1
		Loop

		' Display the number of rows returned
		MsgBox(CStr(lngCounter))
	End Sub

	Public Sub CheckForNullValueInColumn(ByVal vintColumn As Integer)
		Dim cnnUserMan As SqlConnection
		Dim cmmUserMan As SqlCommand
		Dim drdUser As SqlDataReader
		Dim strSQL As String

		' Instantiate the connection
		cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
		' Open the connection
		cnnUserMan.Open()
		' Build query string
		strSQL = "SELECT * FROM tblUser"
		' Instantiate the command
		cmmUserMan = New SqlCommand(strSQL, cnnUserMan)
		' Excute command and return rows in data reader
		drdUser = cmmUserMan.ExecuteReader()
		' Advance reader to first row
		drdUser.Read()
		' Check if the column contains a NULL value
		If drdUser.IsDBNull(vintColumn) Then
			MsgBox("Column " & CStr(vintColumn) & " contains a NULL value!")
		Else
			MsgBox("Column " & CStr(vintColumn) & " does not contain a NULL value!")
		End If
	End Sub

	' Listing 3A-28
	Public Sub InstantiateXmlReader()
		Dim cnnUserMan As SqlConnection
		Dim cmmUserMan As SqlCommand
		Dim drdUserMan As XmlReader
		Dim strSQL As String

		' Instantiate the connection
		cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
		' Open the connection
		cnnUserMan.Open()
		' Build query string
		strSQL = "SELECT * FROM tblUser FOR XML AUTO"
		' Instantiate the command
		cmmUserMan = New SqlCommand(strSQL, cnnUserMan)
		' Instantiate data reader using the ExecuteXmlReader method 
		' of the command class
		drdUserMan = cmmUserMan.ExecuteXmlReader()
	End Sub

	' Listing 3A-29
	Public Sub ReadRowsFromXmlReader()
		Dim cnnUserMan As SqlConnection
		Dim cmmUserMan As SqlCommand
		Dim xrdUser As XmlReader
		Dim strSQL As String
		Dim lngCounter As Long = 0

		' Instantiate the connection
		cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
		' Open the connection
		cnnUserMan.Open()
		' Build query string
		strSQL = "SELECT * FROM tblUser FOR XML AUTO"
		' Instantiate the command
		cmmUserMan = New SqlCommand(strSQL, cnnUserMan)
		' Excute command and return rows in data reader
		xrdUser = cmmUserMan.ExecuteXmlReader()
		' Loop through all the returned rows
		Do While xrdUser.Read
			lngCounter = lngCounter + 1
		Loop

		' Display the number of rows returned
		MsgBox(CStr(lngCounter))
	End Sub

	' Listing 3A-30
	Public Sub InstantiateAndInitializeDataAdapter()
		Const STR_SQL_USER As String = "SELECT * FROM tblUser"

		Dim cnnUserMan As SqlConnection
		Dim cmmUser As SqlCommand
		Dim dadDefaultConstructor As SqlDataAdapter
		Dim dadSqlCommandArgument As SqlDataAdapter
		Dim dadSqlConnectionArgument As SqlDataAdapter
		Dim dadStringArguments As SqlDataAdapter

		' Instantiate and open the connection
		cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
		cnnUserMan.Open()
		' Instantiate the command
		cmmUser = New SqlCommand(STR_SQL_USER)

		' Instantiate data adapters
		dadDefaultConstructor = New SqlDataAdapter()
		dadSqlCommandArgument = New SqlDataAdapter(cmmUser)
		dadSqlConnectionArgument = New SqlDataAdapter(STR_SQL_USER, cnnUserMan)
		dadStringArguments = New SqlDataAdapter(STR_SQL_USER, PR_STR_CONNECTION_STRING)
		' Initialize data adapters
		dadDefaultConstructor.SelectCommand = cmmUser
		dadDefaultConstructor.SelectCommand.Connection = cnnUserMan
	End Sub

	' Listing 3A-32
	Public Sub SetDataAdapterCommandProperties()
		Const STR_SQL_USER_SELECT As String = "SELECT * FROM tblUser"
		Const STR_SQL_USER_DELETE As String = "DELETE FROM tblUser WHERE Id=@Id"
		Const STR_SQL_USER_INSERT As String = "INSERT INTO tblUser(FirstName, " & _
		 "LastName, LoginName, Password) VALUES(@FirstName, @LastName, @LoginName, @Password)"
		Const STR_SQL_USER_UPDATE As String = "UPDATE tblUser SET FirstName=" & _
		 "@FirstName, LastName=@LastName, LoginName=@LoginName, Password=@Password WHERE Id=@Id"

		Dim cnnUserMan As SqlConnection
		Dim cmmUserSelect As SqlCommand
		Dim cmmUserDelete As SqlCommand
		Dim cmmUserInsert As SqlCommand
		Dim cmmUserUpdate As SqlCommand
		Dim dadUserMan As SqlDataAdapter
		Dim prmSQLDelete, prmSQLUpdate, prmSQLInsert As SqlParameter

		' Instantiate and open the connection
		cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
		cnnUserMan.Open()
		' Instantiate the commands
		cmmUserSelect = New SqlCommand(STR_SQL_USER_SELECT, cnnUserMan)
		cmmUserDelete = New SqlCommand(STR_SQL_USER_DELETE, cnnUserMan)
		cmmUserInsert = New SqlCommand(STR_SQL_USER_INSERT, cnnUserMan)
		cmmUserUpdate = New SqlCommand(STR_SQL_USER_UPDATE, cnnUserMan)

		' Instantiate data adapter
		dadUserMan = New SqlDataAdapter(STR_SQL_USER_SELECT, cnnUserMan)
		' Set data adapter command properties
		dadUserMan.SelectCommand = cmmUserSelect
		dadUserMan.InsertCommand = cmmUserInsert
		dadUserMan.DeleteCommand = cmmUserDelete
		dadUserMan.UpdateCommand = cmmUserUpdate

		' Add Delete command parameters
		cmmUserDelete.Parameters.Add("@FirstName", SqlDbType.VarChar, 50, "FirstName")
		cmmUserDelete.Parameters.Add("@LastName", SqlDbType.VarChar, 50, "LastName")
		cmmUserDelete.Parameters.Add("@LoginName", SqlDbType.VarChar, 50, "LoginName")
		cmmUserDelete.Parameters.Add("@Password", SqlDbType.VarChar, 50, "Password")

		prmSQLDelete = dadUserMan.DeleteCommand.Parameters.Add("@Id", SqlDbType.Int, Nothing, "Id")
		prmSQLDelete.Direction = ParameterDirection.Input
		prmSQLDelete.SourceVersion = DataRowVersion.Original

		' Add Update command parameters
		cmmUserUpdate.Parameters.Add("@FirstName", SqlDbType.VarChar, 50, "FirstName")
		cmmUserUpdate.Parameters.Add("@LastName", SqlDbType.VarChar, 50, "LastName")
		cmmUserUpdate.Parameters.Add("@LoginName", SqlDbType.VarChar, 50, "LoginName")
		cmmUserUpdate.Parameters.Add("@Password", SqlDbType.VarChar, 50, "Password")

		prmSQLUpdate = dadUserMan.UpdateCommand.Parameters.Add("@Id", SqlDbType.Int, Nothing, "Id")
		prmSQLUpdate.Direction = ParameterDirection.Input
		prmSQLUpdate.SourceVersion = DataRowVersion.Original

		' Add insert command parameters
		cmmUserInsert.Parameters.Add("@FirstName", SqlDbType.VarChar, 50, "FirstName")
		cmmUserInsert.Parameters.Add("@LastName", SqlDbType.VarChar, 50, "LastName")
		cmmUserInsert.Parameters.Add("@LoginName", SqlDbType.VarChar, 50, "LoginName")
		cmmUserInsert.Parameters.Add("@Password", SqlDbType.VarChar, 50, "Password")
	End Sub

	Public Sub SetDataAdapterCommandPropertiesUsingCommandBuilder()
		Const STR_SQL_USER_SELECT As String = "SELECT * FROM tblUser"

		Dim cnnUserMan As SqlConnection
		Dim cmmUserSelect As SqlCommand
		Dim dadUserMan As SqlDataAdapter
		Dim cmbUser As New SqlCommandBuilder(dadUserMan)

		' Instantiate and open the connection
		cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
		cnnUserMan.Open()
		' Instantiate the select command
		cmmUserSelect = New SqlCommand(STR_SQL_USER_SELECT, cnnUserMan)

		' Instantiate data adapter
		dadUserMan = New SqlDataAdapter(STR_SQL_USER_SELECT, cnnUserMan)
		' Set data adapter select command property
		dadUserMan.SelectCommand = cmmUserSelect
	End Sub

	Public Sub InstantiateDataSet()
		Dim dstUnnamed1 As New DataSet()
		Dim dstNamed1 As New DataSet("UserManDataSet")

		Dim dstUnnamed2 As DataSet
		Dim dstNamed2 As DataSet

		dstUnnamed2 = New DataSet()
		dstNamed2 = New DataSet("UserManDataSet")
	End Sub

	' Listing 3B-3
	Public Sub UpdateDataSet()
		Const STR_SQL_USER_SELECT As String = "SELECT * FROM tblUser"
		Const STR_SQL_USER_DELETE As String = "DELETE FROM tblUser WHERE Id=@Id"
		Const STR_SQL_USER_INSERT As String = "INSERT INTO tblUser(FirstName" & _
		 ", LastName, LoginName, Password) VALUES(@FirstName, @LastName, @LoginName, @Password)"
		Const STR_SQL_USER_UPDATE As String = "UPDATE tblUser SET FirstName=" & _
		 "@FirstName, LastName=@LastName, LoginName=@LoginName, Password=@Password WHERE Id=@Id"

		Dim cnnUserMan As SqlConnection
		Dim cmmUserSelect As SqlCommand
		Dim cmmUserDelete As SqlCommand
		Dim cmmUserInsert As SqlCommand
		Dim cmmUserUpdate As SqlCommand
		Dim dadUserMan As SqlDataAdapter
		Dim dstUserMan, dstChanges As DataSet
		Dim drwUser As DataRow
		Dim prmSQLDelete, prmSQLUpdate, prmSQLInsert As SqlParameter

		' Instantiate and open the connection
		cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
		cnnUserMan.Open()

		' Instantiate the commands
		cmmUserSelect = New SqlCommand(STR_SQL_USER_SELECT, cnnUserMan)
		cmmUserDelete = New SqlCommand(STR_SQL_USER_DELETE, cnnUserMan)
		cmmUserInsert = New SqlCommand(STR_SQL_USER_INSERT, cnnUserMan)
		cmmUserUpdate = New SqlCommand(STR_SQL_USER_UPDATE, cnnUserMan)

		' Instantiate data adapter
		dadUserMan = New SqlDataAdapter(STR_SQL_USER_SELECT, cnnUserMan)
		' Set data adapter command properties
		dadUserMan.SelectCommand = cmmUserSelect
		dadUserMan.InsertCommand = cmmUserInsert
		dadUserMan.DeleteCommand = cmmUserDelete
		dadUserMan.UpdateCommand = cmmUserUpdate

		' Add Delete command parameters
		cmmUserDelete.Parameters.Add("@FirstName", SqlDbType.VarChar, 50, "FirstName")
		cmmUserDelete.Parameters.Add("@LastName", SqlDbType.VarChar, 50, "LastName")
		cmmUserDelete.Parameters.Add("@LoginName", SqlDbType.VarChar, 50, "LoginName")
		cmmUserDelete.Parameters.Add("@Password", SqlDbType.VarChar, 50, "Password")

		prmSQLDelete = dadUserMan.DeleteCommand.Parameters.Add("@Id", SqlDbType.Int, Nothing, "Id")
		prmSQLDelete.Direction = ParameterDirection.Input
		prmSQLDelete.SourceVersion = DataRowVersion.Original

		' Add Update command parameters
		cmmUserUpdate.Parameters.Add("@FirstName", SqlDbType.VarChar, 50, "FirstName")
		cmmUserUpdate.Parameters.Add("@LastName", SqlDbType.VarChar, 50, "LastName")
		cmmUserUpdate.Parameters.Add("@LoginName", SqlDbType.VarChar, 50, "LoginName")
		cmmUserUpdate.Parameters.Add("@Password", SqlDbType.VarChar, 50, "Password")

		prmSQLUpdate = dadUserMan.UpdateCommand.Parameters.Add("@Id", SqlDbType.Int, Nothing, "Id")
		prmSQLUpdate.Direction = ParameterDirection.Input
		prmSQLUpdate.SourceVersion = DataRowVersion.Original

		' Add insert command parameters
		cmmUserInsert.Parameters.Add("@FirstName", SqlDbType.VarChar, 50, "FirstName")
		cmmUserInsert.Parameters.Add("@LastName", SqlDbType.VarChar, 50, "LastName")
		cmmUserInsert.Parameters.Add("@LoginName", SqlDbType.VarChar, 50, "LoginName")
		cmmUserInsert.Parameters.Add("@Password", SqlDbType.VarChar, 50, "Password")

		' Instantiate dataset
		dstUserMan = New DataSet()
		' Populate the data set
		dadUserMan.Fill(dstUserMan, "tblUser")

		' Add new row
		drwUser = dstUserMan.Tables("tblUser").NewRow()
		drwUser("FirstName") = "New User"
		drwUser("LastName") = "New User LastName"
		drwUser("LoginName") = "NewUser"
		drwUser("Password") = "password"
		dstUserMan.Tables("tblUser").Rows.Add(drwUser)

		' Update an existing row (with index 3)
		dstUserMan.Tables("tblUser").Rows(3)("FirstName") = "FirstName"
		dstUserMan.Tables("tblUser").Rows(3)("LastName") = "LastName"
		dstUserMan.Tables("tblUser").Rows(3)("LoginName") = "User3"

		' Delete row with index 4
		dstUserMan.Tables("tblUser").Rows(4).Delete()

		' Check if any data has changed in the data set
		If dstUserMan.HasChanges() Then
			' Save all changed rows in a new data set
			dstChanges = dstUserMan.GetChanges()
			' Check if the changed rows contains any errors
			If dstChanges.HasErrors() Then
				' Reject the changes
				dstUserMan.RejectChanges()
			Else
				' Update the data source
				dadUserMan.Update(dstChanges, "tblUser")
			End If
		End If
	End Sub

	' Listing 3B-4
	Public Sub ClearDataSet()
		Dim cnnUserMan As SqlConnection
		Dim cmmUser As SqlCommand
		Dim dadUser As SqlDataAdapter
		Dim dstUser As DataSet

		' Instantiate and open the connection
		cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
		cnnUserMan.Open()
		' Instantiate the command
		cmmUser = New SqlCommand("SELECT * FROM tblUser", cnnUserMan)
		' Instantiate and initialize the data adapter
		dadUser = New SqlDataAdapter()
		dadUser.SelectCommand = cmmUser
		' Instantiate data set
		dstUser = New DataSet()
		' Fill the data set
		dadUser.Fill(dstUser, "tblUser")
		' Do your stuff
		' ...
		' Clear the data from the data set
		dstUser.Clear()
	End Sub

	' Listing 3B-5
	Public Sub CloneDataSetStructure()
		Dim cnnUserMan As SqlConnection
		Dim cmmUser As SqlCommand
		Dim dadUser As SqlDataAdapter
		Dim dstUser As DataSet
		Dim dstClone As DataSet

		' Instantiate and open the connection
		cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
		cnnUserMan.Open()
		' Instantiate the command and data set
		cmmUser = New SqlCommand("SELECT * FROM tblUser", cnnUserMan)
		dstUser = New DataSet()
		' Instantiate and initialize the data adapter
		dadUser = New SqlDataAdapter("SELECT * FROM tblUser", cnnUserMan)
		dadUser.SelectCommand = cmmUser
		' Fill the data set
		dadUser.Fill(dstUser, "tblUser")
		' Clone the data set
		dstClone = dstUser.Clone()
	End Sub

	' Listing 3B-6
	Public Sub CopyDataSetStructureAndData()
		Dim cnnUserMan As SqlConnection
		Dim cmmUser As SqlCommand
		Dim dadUser As SqlDataAdapter
		Dim dstUser As DataSet
		Dim dstCopy As DataSet

		' Instantiate and open the connection
		cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
		cnnUserMan.Open()
		' Instantiate the command and data set
		cmmUser = New SqlCommand("SELECT * FROM tblUser", cnnUserMan)
		dstUser = New DataSet()
		' Instantiate and initialize the data adapter
		dadUser = New SqlDataAdapter("SELECT * FROM tblUser", cnnUserMan)
		dadUser.SelectCommand = cmmUser
		' Fill the data set
		dadUser.Fill(dstUser, "tblUser")
		' Copy the data set
		dstCopy = dstUser.Copy()
	End Sub

	' Listing 3B-7
	Public Sub MergeDataSetWithDataRows()
		Dim cnnUserMan As SqlConnection
		Dim cmmUser As SqlCommand
		Dim dadUser As SqlDataAdapter
		Dim dstUser As DataSet
		Dim dtbUser As DataTable
		Dim arrdrwUser(0) As DataRow
		Dim drwUser As DataRow

		' Instantiate and open the connection
		cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
		cnnUserMan.Open()
		' Instantiate the command, data set and data table
		cmmUser = New SqlCommand("SELECT * FROM tblUser", cnnUserMan)
		dstUser = New DataSet()
		dtbUser = New DataTable()
		' Instantiate and initialize the data adapter
		dadUser = New SqlDataAdapter("SELECT * FROM tblUser", cnnUserMan)
		dadUser.SelectCommand = cmmUser
		' Fill the data set
		dadUser.Fill(dstUser, "tblUser")
		' Create new row and fill with data
		drwUser = dstUser.Tables("tblUser").NewRow()
		drwUser("LoginName") = "NewUser1"
		drwUser("FirstName") = "New"
		drwUser("LastName") = "User"
		arrdrwUser.SetValue(drwUser, 0)
		' Merge the data set with the data row array
		dstUser.Merge(arrdrwUser)
	End Sub

	' Listing 3B-8
	Public Sub MergeDataSets()
		Dim cnnUserMan As SqlConnection
		Dim cmmUser As SqlCommand
		Dim dadUser As SqlDataAdapter
		Dim dstUser As DataSet
		Dim dstCopy As DataSet

		' Instantiate and open the connection
		cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
		cnnUserMan.Open()
		' Instantiate the command and data set
		cmmUser = New SqlCommand("SELECT * FROM tblUser", cnnUserMan)
		dstUser = New DataSet()
		' Instantiate and initialize the data adapter
		dadUser = New SqlDataAdapter("SELECT * FROM tblUser", cnnUserMan)
		dadUser.SelectCommand = cmmUser
		' Fill the data set
		: dadUser.Fill(dstUser, "tblUser")
		' Copy the data set
		dstCopy = dstUser.Copy()
		' Do your stuff with the data sets
		' ...
		' Merge the two data sets
		dstUser.Merge(dstCopy)
	End Sub

	' Listing 3B-9
	Public Sub MergeDataSetWithDataTable()
		Dim cnnUserMan As SqlConnection
		Dim cmmUser As SqlCommand
		Dim dadUser As SqlDataAdapter
		Dim dstUser As DataSet
		Dim dtbUser As DataTable

		' Instantiate and open the connection
		cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
		cnnUserMan.Open()
		' Instantiate the command, data set and data table
		cmmUser = New SqlCommand("SELECT * FROM tblUser", cnnUserMan)
		dstUser = New DataSet()
		dtbUser = New DataTable()
		' Instantiate and initialize the data adapter
		dadUser = New SqlDataAdapter("SELECT * FROM tblUser", cnnUserMan)
		dadUser.SelectCommand = cmmUser
		' Fill the data set and data table
		dadUser.Fill(dstUser, "tblUser")
		dadUser.Fill(dtbUser)
		' Do your stuff with the data set and the data table
		' ...
		' Merge the data set with the data table
		dstUser.Merge(dtbUser)
	End Sub

	' Listing 3B-10
	Public Sub DetectAllDataSetChanges()
		Dim cnnUserMan As SqlConnection
		Dim cmmUser As SqlCommand
		Dim dadUser As SqlDataAdapter
		Dim dstUser As DataSet
		Dim dstChanges As DataSet

		' Instantiate and open the connection
		cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
		cnnUserMan.Open()
		' Instantiate the command and data set
		cmmUser = New SqlCommand("SELECT * FROM tblUser", cnnUserMan)
		dstUser = New DataSet()
		' Instantiate and initialize the data adapter
		dadUser = New SqlDataAdapter("SELECT * FROM tblUser", cnnUserMan)
		dadUser.SelectCommand = cmmUser
		' Fill the data set
		dadUser.Fill(dstUser, "tblUser")
		' Do your stuff with the data set
		' ...
		' Check if any data has changed in the data set
		If dstUser.HasChanges() Then
			' Save all changes in a new data set
			dstChanges = dstUser.GetChanges()
		End If
	End Sub

	' Listing 3B-11
	Public Sub DetectDifferentDataSetChanges()
		Dim cnnUserMan As SqlConnection
		Dim cmmUser As SqlCommand
		Dim dadUser As SqlDataAdapter
		Dim dstUser As DataSet
		Dim dstChanges As DataSet
		Dim dstAdditions As DataSet
		Dim dstDeletions As DataSet

		' Instantiate and open the connection
		cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
		cnnUserMan.Open()
		' Instantiate the command and data set
		cmmUser = New SqlCommand("SELECT * FROM tblUser", cnnUserMan)
		dstUser = New DataSet()
		' Instantiate and initialize the data adapter
		dadUser = New SqlDataAdapter("SELECT * FROM tblUser", cnnUserMan)
		dadUser.SelectCommand = cmmUser
		' Fill the data set
		dadUser.Fill(dstUser, "tblUser")
		' Do your stuff with the data set
		' ...
		' Check if any data has changed in the data set
		If dstUser.HasChanges() Then
			' Save all modified rows in a new data set
			dstChanges = dstUser.GetChanges(DataRowState.Modified)
			' Save all added rows in a new data set
			dstAdditions = dstUser.GetChanges(DataRowState.Added)
			' Save all deleted rows in a new data set
			dstDeletions = dstUser.GetChanges(DataRowState.Deleted)
		End If
	End Sub

	' Listing 3B-12
	Public Sub AcceptOrRejectDataSetChanges()
		Dim cnnUserMan As SqlConnection
		Dim cmmUser As SqlCommand
		Dim dadUser As SqlDataAdapter
		Dim dstUser, dstChanges As DataSet
		Dim drwUser As DataRow
		Dim intCounter As Integer

		' Instantiate and open the connection
		cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
		cnnUserMan.Open()
		' Instantiate the command and the data set
		cmmUser = New SqlCommand("SELECT * FROM tblUser", cnnUserMan)
		dstUser = New DataSet()
		' Instantiate and initialize the data adapter
		dadUser = New SqlDataAdapter("SELECT * FROM tblUser", cnnUserMan)
		dadUser.SelectCommand = cmmUser
		' Fill the data set
		dadUser.Fill(dstUser, "tblUser")
		' Create a new data row with the schema from the user table
		drwUser = dstUser.Tables("tblUser").NewRow()
		' Enter values in the data row columns
		drwUser("LoginName") = "NewUser1"
		drwUser("FirstName") = "New"
		drwUser("LastName") = "User"
		' Add the data row to the user table
		dstUser.Tables("tblUser").Rows.Add(drwUser)
		' Check if any data has changed in the data set
		If dstUser.HasChanges() Then
			' Save all changed rows in a new data set
			dstChanges = dstUser.GetChanges()
			' Check if the changed rows contains any errors
			If dstChanges.HasErrors() Then
				' Display the row state of all rows before rejecting changes
				For intCounter = 0 To dstUser.Tables(0).Rows.Count - 1
					MsgBox("HasErrors=True, Before RejectChanges, RowState=" & _
					 dstUser.Tables(0).Rows(intCounter).RowState.ToString & _
					 ", LoginName=" & _
					 dstUser.Tables(0).Rows(intCounter)("LoginName").ToString)
				Next
				' Reject the changes to the data set
				dstUser.RejectChanges()
				' Display the row state of all rows after rejecting changes
				For intCounter = 0 To dstUser.Tables(0).Rows.Count - 1
					MsgBox("HasErrors=True, After RejectChanges, RowState=" & _
					 dstUser.Tables(0).Rows(intCounter).RowState.ToString & _
					 ", LoginName=" & _
					 dstUser.Tables(0).Rows(intCounter)("LoginName").ToString)
				Next
			Else
				' Display the row state of all rows before accepting changes
				For intCounter = 0 To dstUser.Tables(0).Rows.Count - 1
					MsgBox("HasErrors=False, Before AcceptChanges, RowState=" & _
					 dstUser.Tables(0).Rows(intCounter).RowState.ToString & _
					 ", LoginName=" & _
					 dstUser.Tables(0).Rows(intCounter)("LoginName").ToString)
				Next
				' Accept the changes to the data set
				dstUser.AcceptChanges()
				' Display the row state of all rows after accepting changes
				For intCounter = 0 To dstUser.Tables(0).Rows.Count - 1
					MsgBox("HasErrors=False, After AcceptChanges, RowState=" & _
					 dstUser.Tables(0).Rows(intCounter).RowState.ToString & _
					 ", LoginName=" & _
					 dstUser.Tables(0).Rows(intCounter)("LoginName").ToString)
				Next
			End If
		End If
	End Sub

	Public Sub InstantiateDataTable()
		Dim dtbNoArgumentsWithInitialize As New DataTable()
		Dim dtbTableNameArgumentWithInitialize As New DataTable("TableName")

		Dim dtbNoArgumentsWithoutInitialize As DataTable
		Dim dtbTableNameArgumentWithoutInitialize As DataTable

		dtbNoArgumentsWithoutInitialize = New DataTable()
		dtbTableNameArgumentWithoutInitialize = New DataTable("TableName")
	End Sub

	' Listing 3B-13
	Public Sub BuildDataTable()
		Dim dtbUser As DataTable
		Dim drwUser As DataRow
		Dim dclUser As DataColumn
		Dim arrdclPrimaryKey(0) As DataColumn

		dtbUser = New DataTable("tblUser")

		' Create table structure
		dclUser = New DataColumn()
		dclUser.ColumnName = "Id"
		dclUser.DataType = Type.GetType("System.Int32")
		dclUser.AutoIncrement = True
		dclUser.AutoIncrementSeed = 1
		dclUser.AutoIncrementStep = 1
		dclUser.AllowDBNull = False
		' Add column to data table structure
		dtbUser.Columns.Add(dclUser)
		' Add column to PK array
		arrdclPrimaryKey(0) = dclUser
		' Set primary key
		dtbUser.PrimaryKey = arrdclPrimaryKey

		dclUser = New DataColumn()
		dclUser.ColumnName = "ADName"
		dclUser.DataType = Type.GetType("System.String")
		' Add column to data table structure
		dtbUser.Columns.Add(dclUser)

		dclUser = New DataColumn()
		dclUser.ColumnName = "ADSID"
		dclUser.DataType = Type.GetType("System.Guid")
		' Add column to data table structure
		dtbUser.Columns.Add(dclUser)

		dclUser = New DataColumn()
		dclUser.ColumnName = "FirstName"
		dclUser.DataType = Type.GetType("System.String")
		' Add column to data table structure
		dtbUser.Columns.Add(dclUser)

		dclUser = New DataColumn()
		dclUser.ColumnName = "LastName"
		dclUser.DataType = Type.GetType("System.String")
		' Add column to data table structure
		dtbUser.Columns.Add(dclUser)

		dclUser = New DataColumn()
		dclUser.ColumnName = "LoginName"
		dclUser.DataType = Type.GetType("System.String")
		dclUser.AllowDBNull = False
		dclUser.Unique = True
		' Add column to data table structure
		dtbUser.Columns.Add(dclUser)
		dclUser = New DataColumn()
		dclUser.ColumnName = "Password"
		dclUser.DataType = Type.GetType("System.String")
		dclUser.AllowDBNull = False
		' Add column to data table structure
		dtbUser.Columns.Add(dclUser)
	End Sub

	' Listing 3B-14
	Public Sub ClearDataTable()
		Dim cnnUserMan As SqlConnection
		Dim cmmUser As SqlCommand
		Dim dadUser As SqlDataAdapter
		Dim dtbUser As DataTable

		' Instantiate and open the connection
		cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)

		cnnUserMan.Open()
		' Instantiate the command
		cmmUser = New SqlCommand("SELECT * FROM tblUser", cnnUserMan)
		' Instantiate and initialize the data adapter
		dadUser = New SqlDataAdapter()
		dadUser.SelectCommand = cmmUser
		' Instantiate data table
		dtbUser = New DataTable("tblUser")
		' Fill the data table
		dadUser.Fill(dtbUser)
		' Do your stuff
		' ...
		' Clear the data from the data table
		dtbUser.Clear()
	End Sub

	' Listing 3B-15
	Public Sub CloneDataTableStructure()
		Dim cnnUserMan As SqlConnection
		Dim cmmUser As SqlCommand
		Dim dadUser As SqlDataAdapter
		Dim dtbUser As DataTable
		Dim dtbClone As DataTable

		' Instantiate and open the connection
		cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
		cnnUserMan.Open()
		' Instantiate the command and data table
		cmmUser = New SqlCommand("SELECT * FROM tblUser", cnnUserMan)
		dtbUser = New DataTable()
		' Instantiate and initialize the data adapter
		dadUser = New SqlDataAdapter("SELECT * FROM tblUser", cnnUserMan)
		dadUser.SelectCommand = cmmUser
		' Fill the data table
		dadUser.Fill(dtbUser)
		' Clone the data table
		dtbClone = dtbUser.Clone()
	End Sub

	' Listing 3B-16
	Public Sub CopyDataTable()
		Dim cnnUserMan As SqlConnection
		Dim cmmUser As SqlCommand
		Dim dadUser As SqlDataAdapter
		Dim dtbUser As DataTable
		Dim dtbCopy As DataTable

		' Instantiate and open the connection
		cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
		cnnUserMan.Open()
		' Instantiate the command and data tables
		cmmUser = New SqlCommand("SELECT * FROM tblUser", cnnUserMan)
		dtbUser = New DataTable()
		' Instantiate and initialize the data adapter
		dadUser = New SqlDataAdapter("SELECT * FROM tblUser", cnnUserMan)
		dadUser.SelectCommand = cmmUser
		' Fill the data table
		dadUser.Fill(dtbUser)
		' Copy the data table
		dtbCopy = dtbUser.Copy()
	End Sub

	' Listing 3B-17
	Public Sub SearchDataTable()
		Dim cnnUserMan As SqlConnection
		Dim cmmUser As SqlCommand
		Dim dadUser As SqlDataAdapter
		Dim dtbUser As DataTable
		Dim intCounter As Integer

		' Instantiate and open the connection
		cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
		cnnUserMan.Open()
		' Instantiate the command and data table
		cmmUser = New SqlCommand("SELECT * FROM tblUser", cnnUserMan)
		dtbUser = New DataTable()
		' Instantiate and initialize the data adapter
		dadUser = New SqlDataAdapter("SELECT * FROM tblUser", cnnUserMan)
		dadUser.SelectCommand = cmmUser
		' Fill the data table
		dadUser.Fill(dtbUser)
		' Filter the data table view
		dtbUser.DefaultView.RowFilter = "LastName = 'Doe'"

		' Loop through all the rows in the data table view
		For intCounter = 0 To dtbUser.DefaultView.Count - 1
			MsgBox(dtbUser.DefaultView(0).Row("LastName").ToString())
		Next
	End Sub

	Public Sub InstantiateDataView()
		Dim dstUser As New DataSet()

		Dim dvwNoArgumentsWithInitializer As New DataView()
		Dim dvwTableArgumentWithInitializer As New DataView(dstUser.Tables("tblUser"))

		Dim dvwNoArgumentsWithoutInitializer As DataView
		Dim dvwTableArgumentWithoutInitializer As DataView

		dvwNoArgumentsWithoutInitializer = New DataView()
		dvwTableArgumentWithoutInitializer = New DataView(dstUser.Tables("tblUser"))
	End Sub

	' Listing 3B-18
	Public Sub SearchDataView()
		Dim cnnUserMan As SqlConnection
		Dim cmmUser As SqlCommand
		Dim dadUser As SqlDataAdapter
		Dim dtbUser As DataTable
		Dim dvwUser As DataView
		Dim objPKValue As Object
		Dim intIndex As Integer

		' Instantiate and open the connection
		cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
		cnnUserMan.Open()
		' Instantiate the command and data table
		cmmUser = New SqlCommand("SELECT * FROM tblUser", cnnUserMan)
		dtbUser = New DataTable()
		' Instantiate and initialize the data adapter
		dadUser = New SqlDataAdapter("SELECT * FROM tblUser", cnnUserMan)
		dadUser.SelectCommand = cmmUser
		' Fill the data table
		dadUser.Fill(dtbUser)
		' Filter the data table view
		dtbUser.DefaultView.RowFilter = "LastName = 'Doe'"
		' Create the new data view
		dvwUser = dtbUser.DefaultView
		' Specify a sort order
		dvwUser.Sort = "Id ASC"
		' Find the user with an id of 1
		objPKValue = 1
		intIndex = dvwUser.Find(objPKValue)
	End Sub

	Public Sub InstantiateDataRow()
		Dim dtbUser As New DataTable()
		Dim drwUser As DataRow

		drwUser = dtbUser.NewRow()
	End Sub
End Module