Imports System.Messaging

Module General
	' Listing 8-1
	Public Sub CreatePrivateQueueWithName()
		Dim queUserMan As New MessageQueue()

		queUserMan.Create("USERMANPC\Private$\UserMan")
	End Sub

	' Listing 8-2
	Public Sub CreatePrivateQueue()
		Dim queUserMan As New MessageQueue()

		queUserMan.Create(".\Private$\UserMan")
	End Sub

	' Listing 8-3
	Public Sub CreatePublicQueue()
		Dim queUserMan As New MessageQueue()

		queUserMan.Create(".\UserMan")
	End Sub

	' Listing 8-4
	Public Sub CreateTransactionalPrivateQueue()
		Dim queUserMan As New MessageQueue()

		queUserMan.Create(".\Private$\UserMan", True)
	End Sub

	' Listing 8-5
	Public Sub ChangeQueueLabel()
		Dim queUserMan As New MessageQueue(".\Private$\UserMan")

		queUserMan.Label = "USERMAN1"
	End Sub

	' Listing 8-6
	Public Sub RetrieveQueueId()
		Dim queUserMan As New MessageQueue(".\UserMan")
		Dim uidMessageQueue As Guid

		uidMessageQueue = queUserMan.Id
	End Sub

	' Listing 8-7
	Public Sub BindToExistingQueue()
		Dim queUserManNoArguments As New MessageQueue()
		Dim queUserManPath As New MessageQueue(".\Private$\UserMan")
		Dim queUserManPathAndAccess As New MessageQueue(".\Private$\UserMan", True)

		' Initialize the queue
		queUserManNoArguments.Path = ".\Private$\UserMan"
	End Sub

	' Listing 8-8
	Public Sub BindToExistingQueueUsingFormat()
		Dim queUserManFormatTCP As New MessageQueue("FormatName:DIRECT=TCP:10.8.1.15\Private$\UserMan")
		Dim queUserManFormatOS As New MessageQueue("FormatName:DIRECT=OS:USERMANPC\UserMan")
		Dim queUserManFormatPublic As New MessageQueue("FormatName:Public=AB6B9EF6-B167-43A4-8116-5B72D5C1F81C")
	End Sub

	' Listing 8-9
	Public Sub BindToExistingQueueUsingLabel()
		Dim queUserManLabel As New MessageQueue("Label:Userman")
	End Sub

	' Listing 8-10
	Public Sub SendSimpleMessage()
		Dim queUserMan As New MessageQueue(".\Private$\UserMan")

		' Send simple message to queue
		queUserMan.Send("Test")
	End Sub

	' Listing 8-11
	Public Sub RetrieveSimpleMessage()
		Dim queUserMan As New MessageQueue(".\Private$\UserMan")
		Dim msgUserMan As Message

		' Retrieve first message from queue
		msgUserMan = queUserMan.Receive()
	End Sub

	' Listing 8-12
	Public Sub RetrieveMessage()
		Dim queUserMan As New MessageQueue(".\Private$\UserMan")
		Dim msgUserMan As Message
		Dim strBody As String

		' Set up the formatter
		queUserMan.Formatter = New XmlMessageFormatter(New Type() {GetType(String)})

		' Retrieve first message from queue
		msgUserMan = queUserMan.Receive
		' Save the message body
		strBody = msgUserMan.Body.ToString
	End Sub

	Public Sub SendMessage()
		Dim queUserMan As New MessageQueue(".\Private$\UserMan")
		Dim msgUserMan As New Message()

		' Set up the formatter
		queUserMan.Formatter = New XmlMessageFormatter(New Type() {GetType(String)})

		' Create body as a text message
		msgUserMan.Body = "Test"
		' Send message to queue
		queUserMan.Send(msgUserMan)
	End Sub

	' Listing 8-13-1
	Public Sub SendDifferentMessages()
		Dim queUserMan As New MessageQueue(".\Private$\UserMan")
		Dim msgUserMan As New Message()

		' Set up the formatter
		queUserMan.Formatter = New XmlMessageFormatter(New Type() {GetType(String), GetType(Integer)})

		' Create body as a text message
		msgUserMan.Body = "Test"
		' Send message to queue
		queUserMan.Send(msgUserMan)
		' Create body as an integer
		msgUserMan.Body = 12
		' Send message to queue
		queUserMan.Send(msgUserMan)
	End Sub

	' Listing 8-13-2
	Public Sub RetrieveDifferentMessages()
		Dim queUserMan As New MessageQueue(".\Private$\UserMan")
		Dim msgUserMan As Message
		Dim strBody As String
		Dim intBody As Integer

		' Set up the formatter
		queUserMan.Formatter = New XmlMessageFormatter(New Type() {GetType(String), GetType(Integer)})

		' Retrieve first message from queue
		msgUserMan = queUserMan.Receive
		' Save the message body
		strBody = msgUserMan.Body.ToString
		' Retrieve next message from queue
		msgUserMan = queUserMan.Receive
		' Save the message body
		intBody = msgUserMan.Body
	End Sub

	' Listing 8-14
	Public Sub PeekMessage()
		Dim queUserMan As New MessageQueue(".\Private$\UserMan")
		Dim msgUserMan As Message
		Dim strBody As String

		' Set up the formatter
		queUserMan.Formatter = New XmlMessageFormatter(New Type() {GetType(String)})

		' Peek first message from queue
		msgUserMan = queUserMan.Peek
		' Save the message body
		strBody = msgUserMan.Body.ToString
	End Sub

	' Listing 8-15
	Public Sub RetrieveMessageById()
		Dim queUserMan As New MessageQueue(".\Private$\UserMan")
		Dim msgUserMan As New Message()
		Dim strId As String

		' Set up the formatter
		queUserMan.Formatter = New XmlMessageFormatter(New Type() {GetType(String)})

		' Create body as a text message
		msgUserMan.Body = "Test 1"
		' Send message to queue
		queUserMan.Send(msgUserMan)

		' Create body as a text message
		msgUserMan.Body = "Test 2"
		' Send message to queue
		queUserMan.Send(msgUserMan)
		strId = msgUserMan.Id

		' Create body as a text message
		msgUserMan.Body = "Test 3"
		' Send message to queue
		queUserMan.Send(msgUserMan)

		msgUserMan = queUserMan.ReceiveById(strId)
		MsgBox("Saved Id=" & strId & vbCrLf & "Retrieved Id=" & msgUserMan.Id)
	End Sub

	' Listing 8-16
	Public Function RetrieveMessageByIdSafe(ByVal vstrId As String) As Message
		Dim queUserMan As New MessageQueue(".\Private$\UserMan")
		Dim msgUserMan As New Message()

		' Set up the formatter
		queUserMan.Formatter = New XmlMessageFormatter(New Type() {GetType(String)})

		Try
			msgUserMan = queUserMan.ReceiveById(vstrId)
		Catch objE As InvalidOperationException
			' Message not found, return a Null value
			RetrieveMessageByIdSafe = Nothing

			Exit Function
		End Try

		' Return message
		RetrieveMessageByIdSafe = msgUserMan
	End Function

	' Listing 8-17-1
	Public Sub MessageReceiveCompleteEvent(ByVal vobjSource As Object, _
	 ByVal vobjEventArgs As ReceiveCompletedEventArgs)
		Dim msgUserMan As New Message()
		Dim queUserMan As New MessageQueue()

		' Make sure we bind to the right message queue
		queUserMan = CType(vobjSource, MessageQueue)

		' End async receive
		msgUserMan = queUserMan.EndReceive(vobjEventArgs.AsyncResult)
	End Sub

	' Listing 8-17-2
	Public Sub RetrieveMessagesAsync()
		Dim queUserMan As New MessageQueue(".\Private$\UserMan")
		Dim msgUserMan As New Message()

		' Set up the formatter
		queUserMan.Formatter = New XmlMessageFormatter(New Type() {GetType(String)})

		' Add an event handler
		AddHandler queUserMan.ReceiveCompleted, AddressOf MessageReceiveCompleteEvent

		queUserMan.BeginReceive(New TimeSpan(0, 0, 10))
	End Sub

	' Listing 8-18-1
	Public Sub MessagePeekCompleteEvent(ByVal vobjSource As Object, _
	 ByVal vobjEventArgs As PeekCompletedEventArgs)
		Dim msgUserMan As New Message()
		Dim queUserMan As New MessageQueue()

		' Make sure we bind to the right message queue
		queUserMan = CType(vobjSource, MessageQueue)

		' End async peek
		msgUserMan = queUserMan.EndPeek(vobjEventArgs.AsyncResult)
	End Sub

	' Listing 8-18-2
	Public Sub PeekMessagesAsync()
		Dim queUserMan As New MessageQueue(".\Private$\UserMan")
		Dim msgUserMan As New Message()

		' Set up the formatter
		queUserMan.Formatter = New XmlMessageFormatter(New Type() {GetType(String)})

		' Add an event handler
		AddHandler queUserMan.PeekCompleted, AddressOf MessagePeekCompleteEvent

		queUserMan.BeginPeek(New TimeSpan(0, 0, 10))
	End Sub

	' Listing 8-19
	Public Sub ClearMessageQueue()
		Dim queUserMan As New MessageQueue(".\Private$\UserMan")
		Dim msgUserMan As Message

		' Clear all messages from queue
		queUserMan.Purge()
	End Sub

	' Listing 8-20-1
	Public Sub SendPriorityMessages()
		Dim queUserMan As New MessageQueue(".\Private$\UserMan")
		Dim msgFirst As New Message()
		Dim msgSecond As New Message()

		' Set up the formatter
		queUserMan.Formatter = New XmlMessageFormatter(New Type() {GetType(String), GetType(Integer)})

		' Create first body 
		msgFirst.Body = "First Message"
		' Send message to queue
		queUserMan.Send(msgFirst)

		' Create second body 
		msgSecond.Body = "Second Message"
		' Set priority to highest
		msgSecond.Priority = MessagePriority.Highest
		' Send message to queue
		queUserMan.Send(msgSecond)
	End Sub

	' Listing 8-20-2
	Public Sub RetrievePriorityMessage()
		Dim queUserMan As New MessageQueue(".\Private$\UserMan")
		Dim msgUserMan As Message

		' Set up the formatter
		queUserMan.Formatter = New XmlMessageFormatter(New Type() {GetType(String)})

		' Retrieve first message from queue
		msgUserMan = queUserMan.Receive
		' Display the message body
		MsgBox(msgUserMan.Body.ToString)
	End Sub

	' Listing 8-21
	Public Function CheckQueueExists(ByVal vstrPath As String) As Boolean
		CheckQueueExists = MessageQueue.Exists(vstrPath)
	End Function

	' Listing 8-22
	Public Sub BrowsePrivateQueues()
		Dim arrquePrivate() As MessageQueue = _
		 MessageQueue.GetPrivateQueuesByMachine("USERMANPC")
		Dim queUserMan As MessageQueue

		' Display the name of all the private queues on the machine
		For Each queUserMan In arrquePrivate
			MsgBox(queUserMan.Label)
		Next
	End Sub

	Public Sub BrowsePublicQueuesMachineWide()
		Dim arrquePublic() As MessageQueue = _
		 MessageQueue.GetPublicQueuesByMachine("USERMANPC")
		Dim queUserMan As MessageQueue

		' Display the name of all the private queues on the machine
		For Each queUserMan In arrquePublic
			MsgBox(queUserMan.Label)
		Next
	End Sub

	' Listing 8-23
	Public Sub BrowsePublicQueuesNetworkWide()
		Dim arrquePublic() As MessageQueue = _
		 MessageQueue.GetPublicQueues()
		Dim queUserMan As MessageQueue

		' Display the name of all the public queues on the network
		For Each queUserMan In arrquePublic
			MsgBox(queUserMan.QueueName)
		Next
	End Sub

	' Listing 8-24
	Public Sub BrowsePublicQueuesByCategoryNetworkWide()
		Dim arrquePublic() As MessageQueue = _
		 MessageQueue.GetPublicQueuesByCategory(New Guid("00000000-0000-0000-0000-000000000001"))
		Dim queUserMan As MessageQueue

		' Display the name of all the public queues 
		' on the network within a specific category
		For Each queUserMan In arrquePublic
			MsgBox(queUserMan.QueueName)
		Next
	End Sub

	' Listing 8-25
	Public Sub BrowsePublicQueuesByLabelNetworkWide()
		Dim arrquePublic() As MessageQueue = _
		 MessageQueue.GetPublicQueuesByLabel("userman")
		Dim queUserMan As MessageQueue

		' Display the machine name for all the public queues 
		' on the network with a specific label
		For Each queUserMan In arrquePublic
			MsgBox(queUserMan.MachineName)
		Next
	End Sub

	' Listing 8-26
	Public Sub RemoveMessageQueue(ByVal vstrPath As String)
		MessageQueue.Delete(vstrPath)
	End Sub

	' Listing 8-27
	Public Sub RemoveMessageQueueSafely(ByVal vstrPath As String)
		Try
			MessageQueue.Delete(vstrPath)
		Catch objE As Exception
			MsgBox(objE.Message)
		End Try
	End Sub

	' Listing 8-28
	Public Sub UseMQTransactions()
		Dim qtrUserMan As New MessageQueueTransaction()
		Dim queUserMan As New MessageQueue(".\Private$\UserMan")
		Dim msgUserMan As New Message()

		' Set up the queue formatter
		queUserMan.Formatter = New XmlMessageFormatter(New Type() {GetType(String)})

		' Clear the message queue
		queUserMan.Purge()
		' Start the transaction
		qtrUserMan.Begin()

		Try
			' Create message body
			msgUserMan.Body = "First Message"
			' Send message to queue
			queUserMan.Send(msgUserMan, qtrUserMan)

			' Create message body
			msgUserMan.Body = "Second Message"
			' Send message to queue
			queUserMan.Send(msgUserMan)

			' Retrieve message from queue
			msgUserMan = queUserMan.Receive()
			' Display message body
			MsgBox(msgUserMan.Body)

			' Commit transaction
			qtrUserMan.Commit()

			' Retrieve message from queue
			msgUserMan = queUserMan.Receive()
			' Display message body
			MsgBox(msgUserMan.Body)
		Catch objE As Exception
			' Abort the transaction
			qtrUserMan.Abort()
		End Try
	End Sub

	Public Sub EnableMQJournaling()
		Dim queUserMan As New MessageQueue(".\Private$\UserMan")

		queUserMan.UseJournalQueue = True
	End Sub

	' Listing 8-29
	Public Sub EnableMessageJournaling()
		Dim queUserMan As New MessageQueue(".\Private$\UserMan")
		Dim msgUserMan As New Message()

		' Set up the formatter
		queUserMan.Formatter = New XmlMessageFormatter(New Type() {GetType(String)})

		' Create message body 
		msgUserMan.Body = "Message"
		' Enable message journaling
		msgUserMan.UseJournalQueue = True
		' Send message to queue
		queUserMan.Send(msgUserMan)
	End Sub

	Public Sub RetrieveMessageFromQueueJournal()
		Dim queUserMan As New MessageQueue(".\Private$\UserMan\Journal$")
		Dim msgUserMan As New Message()

		' Set up the formatter
		queUserMan.Formatter = New XmlMessageFormatter(New Type() {GetType(String)})

		Try
			' Retrieve message from journal
			msgUserMan = queUserMan.Receive()
		Catch objE As Exception
			MsgBox(objE.Message)
		End Try
	End Sub

	' Listing 8-30
	Public Sub EnableQueueAuthentication()
		Dim queUserMan As New MessageQueue(".\Private$\UserMan")
		Dim msgUserMan As New Message()

		' Enable queue authentication
		queUserMan.Authenticate = True
	End Sub

	' Listing 8-31
	Public Sub RejectNonauthenticatedMessage()
		Dim queUserMan As New MessageQueue(".\Private$\UserMan")
		Dim msgUserMan As New Message()

		' Enable queue authentication
		queUserMan.Authenticate = True
		' Set up the queue formatter
		queUserMan.Formatter = New XmlMessageFormatter(New Type() {GetType(String)})

		' Create message body
		msgUserMan.Body = "Message Body"
		' Make sure a rejected message is placed in the dead-letter queue
		msgUserMan.UseDeadLetterQueue = True

		' Send message to queue
		queUserMan.Send(msgUserMan)
	End Sub

	Public Sub SendDeadLetterMessage()
		Dim queUserMan As New MessageQueue(".\UserMan")
		Dim msgUserMan As New Message()

		' Set up the formatter
		queUserMan.Formatter = New XmlMessageFormatter(New Type() {GetType(String)})

		' Create message body 
		msgUserMan.Body = "Message"
		' Set max time to be in queue
		msgUserMan.TimeToBeReceived = New TimeSpan(0, 1, 0)
		' Make sure that a dead-letter ends up in dead-letter queue
		msgUserMan.UseJournalQueue = True
		' Send message to queue
		queUserMan.Send(msgUserMan)
	End Sub

	Public Sub RetrieveMessageFromDeadLetterQueue()
		Dim queUserMan As New MessageQueue(".\DeadLetter$")
		Dim msgUserMan As New Message()

		' Set up the formatter
		queUserMan.Formatter = New XmlMessageFormatter(New Type() {GetType(String)})

		Try
			' Retrieve message from journal
			msgUserMan = queUserMan.Receive()
		Catch objE As Exception
			MsgBox(objE.Message)
		End Try
	End Sub

	' Listing 8-32
	Public Sub PlaceNonauthenticatedMessageInAdminQueue()
		Dim queUserManAdmin As New MessageQueue(".\Private$\UserManAdmin")
		Dim queUserMan As New MessageQueue(".\Private$\UserMan")
		Dim msgUserMan As New Message()

		' Enable queue authentication
		queUserMan.Authenticate = True
		' Set up the queue formatter
		queUserMan.Formatter = New XmlMessageFormatter(New Type() {GetType(String)})

		' Create message body
		msgUserMan.Body = "Message Body"
		' Make sure a rejected message is placed in the admin queue
		msgUserMan.AdministrationQueue = queUserManAdmin
		' These types of rejected messages
		msgUserMan.AcknowledgeType = AcknowledgeTypes.NotAcknowledgeReachQueue

		' Send message to queue
		queUserMan.Send(msgUserMan)
	End Sub

	' Listing 8-33
	Public Sub AcceptAuthenticatedMessage()
		Dim queUserMan As New MessageQueue(".\Private$\UserMan")
		Dim msgUserMan As New Message()

		' Enable queue authentication
		queUserMan.Authenticate = True
		' Set up the queue formatter
		queUserMan.Formatter = New XmlMessageFormatter(New Type() {GetType(String)})

		' Make sure a rejected message is placed in the dead-letter queue
		msgUserMan.UseDeadLetterQueue = True
		' Make sure that message queuing attaches the sender id and
		' is digitally signed before it is sent
		msgUserMan.UseAuthentication = True
		msgUserMan.AttachSenderId = True
		' Create message body
		msgUserMan.Body = "Message Body"

		' Send message to queue
		queUserMan.Send(msgUserMan)
	End Sub

	' Listing 8-34
	Public Sub EnableRequireBodyEncryption()
		Dim queUserMan As New MessageQueue(".\Private$\UserMan")
		Dim msgUserMan As New Message()

		' Enable body encryption requirement
		queUserMan.EncryptionRequired = EncryptionRequired.Body
	End Sub

	' Listing 8-35
	Public Sub SendAndReceiveEncryptedMessage()
		Dim queUserMan As New MessageQueue(".\Private$\UserMan")
		Dim msgUserMan As New Message()

		' Require message body encryption
		queUserMan.EncryptionRequired = EncryptionRequired.Body
		' Set up the queue formatter
		queUserMan.Formatter = New XmlMessageFormatter(New Type() {GetType(String)})

		' Make sure that message is encrypted before it is sent
		msgUserMan.UseEncryption = True
		' Create message body
		msgUserMan.Body = "Message Body"

		' Send message to queue
		queUserMan.Send(msgUserMan)

		' Retrieve message from queue
		msgUserMan = queUserMan.Receive()
		' Show decrypted message body
		MsgBox(msgUserMan.Body.ToString)
	End Sub

	' Listing 8-36
	Public Sub SetUserPermissions()
		Dim queUserMan As New MessageQueue(".\Private$\UserMan")
		Dim msgUserMan As New Message()
		Dim aclUserMan As New AccessControlList()

		' Give UserMan user full control over private UserMan queue
		queUserMan.SetPermissions("UserMan", MessageQueueAccessRights.FullControl)
		' Give UserMan user full control over private UserMan queue
		queUserMan.SetPermissions(New MessageQueueAccessControlEntry(New Trustee("UserMan"), _
		 MessageQueueAccessRights.FullControl))
		' Deny UserMan deleting the private UserMan queue
		queUserMan.SetPermissions("UserMan", MessageQueueAccessRights.DeleteQueue, _
		 AccessControlEntryType.Deny)
		' Deny UserMan all access rights on the private UserMan queue
		aclUserMan.Add(New AccessControlEntry(New Trustee("UserMan"), _
		 GenericAccessRights.All, StandardAccessRights.All, AccessControlEntryType.Deny))
		queUserMan.SetPermissions(aclUserMan)
	End Sub
End Module