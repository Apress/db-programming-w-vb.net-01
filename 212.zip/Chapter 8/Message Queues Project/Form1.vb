Public Class Form1
	Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

	Public Sub New()
		MyBase.New()

		'This call is required by the Windows Form Designer.
		InitializeComponent()

		'Add any initialization after the InitializeComponent() call

	End Sub

	'Form overrides dispose to clean up the component list.
	Public Overloads Overrides Sub Dispose()
		MyBase.Dispose()
		If Not (components Is Nothing) Then
			components.Dispose()
		End If
	End Sub
	Private WithEvents btnSend As System.Windows.Forms.Button
	Friend WithEvents btnRetrieve As System.Windows.Forms.Button
	Friend WithEvents brnPurge As System.Windows.Forms.Button
	Friend WithEvents btnExists As System.Windows.Forms.Button
	Friend WithEvents btnBrowse As System.Windows.Forms.Button
	Friend WithEvents btnRemove As System.Windows.Forms.Button
	Friend WithEvents btnCreateTransactional As System.Windows.Forms.Button
	Friend WithEvents btnTransactions As System.Windows.Forms.Button
	Friend WithEvents btnCreatePrivateQueue As System.Windows.Forms.Button
	Friend WithEvents btnJournaling As System.Windows.Forms.Button
	Friend WithEvents btnMisc As System.Windows.Forms.Button

	'Required by the Windows Form Designer
	Private components As System.ComponentModel.Container

	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.  
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
		Me.btnSend = New System.Windows.Forms.Button()
		Me.btnCreatePrivateQueue = New System.Windows.Forms.Button()
		Me.btnBrowse = New System.Windows.Forms.Button()
		Me.btnExists = New System.Windows.Forms.Button()
		Me.btnRemove = New System.Windows.Forms.Button()
		Me.btnRetrieve = New System.Windows.Forms.Button()
		Me.brnPurge = New System.Windows.Forms.Button()
		Me.btnCreateTransactional = New System.Windows.Forms.Button()
		Me.btnTransactions = New System.Windows.Forms.Button()
		Me.btnJournaling = New System.Windows.Forms.Button()
		Me.btnMisc = New System.Windows.Forms.Button()
		Me.SuspendLayout()
		'
		'btnSend
		'
		Me.btnSend.Location = New System.Drawing.Point(8, 208)
		Me.btnSend.Name = "btnSend"
		Me.btnSend.TabIndex = 0
		Me.btnSend.Text = "Send"
		'
		'btnCreatePrivateQueue
		'
		Me.btnCreatePrivateQueue.Location = New System.Drawing.Point(112, 136)
		Me.btnCreatePrivateQueue.Name = "btnCreatePrivateQueue"
		Me.btnCreatePrivateQueue.Size = New System.Drawing.Size(168, 23)
		Me.btnCreatePrivateQueue.TabIndex = 0
		Me.btnCreatePrivateQueue.Text = "Create Private Queue"
		'
		'btnBrowse
		'
		Me.btnBrowse.Location = New System.Drawing.Point(208, 208)
		Me.btnBrowse.Name = "btnBrowse"
		Me.btnBrowse.TabIndex = 0
		Me.btnBrowse.Text = "Browse"
		'
		'btnExists
		'
		Me.btnExists.Location = New System.Drawing.Point(112, 240)
		Me.btnExists.Name = "btnExists"
		Me.btnExists.TabIndex = 0
		Me.btnExists.Text = "Exists"
		'
		'btnRemove
		'
		Me.btnRemove.Location = New System.Drawing.Point(208, 240)
		Me.btnRemove.Name = "btnRemove"
		Me.btnRemove.TabIndex = 0
		Me.btnRemove.Text = "Remove"
		'
		'btnRetrieve
		'
		Me.btnRetrieve.Location = New System.Drawing.Point(8, 240)
		Me.btnRetrieve.Name = "btnRetrieve"
		Me.btnRetrieve.TabIndex = 0
		Me.btnRetrieve.Text = "Retrieve"
		'
		'brnPurge
		'
		Me.brnPurge.Location = New System.Drawing.Point(112, 208)
		Me.brnPurge.Name = "brnPurge"
		Me.brnPurge.TabIndex = 0
		Me.brnPurge.Text = "Purge"
		'
		'btnCreateTransactional
		'
		Me.btnCreateTransactional.Location = New System.Drawing.Point(112, 168)
		Me.btnCreateTransactional.Name = "btnCreateTransactional"
		Me.btnCreateTransactional.Size = New System.Drawing.Size(168, 23)
		Me.btnCreateTransactional.TabIndex = 0
		Me.btnCreateTransactional.Text = "Create Transactional"
		'
		'btnTransactions
		'
		Me.btnTransactions.Location = New System.Drawing.Point(8, 168)
		Me.btnTransactions.Name = "btnTransactions"
		Me.btnTransactions.Size = New System.Drawing.Size(80, 23)
		Me.btnTransactions.TabIndex = 0
		Me.btnTransactions.Text = "Transactions"
		'
		'btnJournaling
		'
		Me.btnJournaling.Location = New System.Drawing.Point(8, 136)
		Me.btnJournaling.Name = "btnJournaling"
		Me.btnJournaling.Size = New System.Drawing.Size(80, 23)
		Me.btnJournaling.TabIndex = 0
		Me.btnJournaling.Text = "Journaling"
		'
		'btnMisc
		'
		Me.btnMisc.Location = New System.Drawing.Point(113, 88)
		Me.btnMisc.Name = "btnMisc"
		Me.btnMisc.TabIndex = 0
		Me.btnMisc.Text = "Misc."
		'
		'Form1
		'
		Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
		Me.ClientSize = New System.Drawing.Size(296, 273)
		Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnMisc, Me.btnJournaling, Me.btnCreatePrivateQueue, Me.btnTransactions, Me.btnCreateTransactional, Me.btnRemove, Me.btnBrowse, Me.btnExists, Me.brnPurge, Me.btnRetrieve, Me.btnSend})
		Me.Name = "Form1"
		Me.Text = "Message Queues Project"
		Me.ResumeLayout(False)

	End Sub

#End Region

	Private Sub btnSend_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSend.Click
		SendPriorityMessages()
	End Sub

	Private Sub btnRetrieve_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRetrieve.Click
		RetrievePriorityMessage()
	End Sub

	Private Sub brnPurge_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles brnPurge.Click
		ClearMessageQueue()
	End Sub

	Private Sub btnExists_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExists.Click
		MsgBox(CheckQueueExists(".\Private$\UserMan"))
	End Sub

	Private Sub btnBrowse_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBrowse.Click
		BrowsePublicQueuesByLabelNetworkWide()
	End Sub

	Private Sub btnRemove_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRemove.Click
		RemoveMessageQueue(".\userman")
	End Sub

	Private Sub btnCreateTransactional_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCreateTransactional.Click
		CreateTransactionalPrivateQueue()
	End Sub

	Private Sub btnTransactions_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTransactions.Click
		UseMQTransactions()
	End Sub

	Private Sub btnCreatePrivateQueue_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCreatePrivateQueue.Click
		CreatePrivateQueue()
	End Sub

	Private Sub btnJournaling_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnJournaling.Click
		EnableMessageJournaling()
	End Sub

	Private Sub btnMisc_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnMisc.Click
		SetUserPermissions()
	End Sub
End Class
