Imports System.Data.SqlClient

Module General
	' Listing 5-15
	Public Sub EnableUnstructuredExceptionHandling1()
		' Enable local exception handling
		On Error Goto Err_EnableUnstructuredExceptionHandlingFromLabel

		Exit Sub
Err_EnableUnstructuredExceptionHandlingFromLabel:
	End Sub

	' Listing 5-16
	Public Sub EnableUnstructuredExceptionHandling2()
		' Enable local exception handling
		On Error Goto 5

		Exit Sub
5:
	End Sub

	' Listing 5-17
	Public Sub EnableUnstructuredExceptionHandling3()
		On Error Goto Err_EnableUnstructuredExceptionHandlingFromLabel1

		On Error Goto Err_EnableUnstructuredExceptionHandlingFromLabel2

		Exit Sub
Err_EnableUnstructuredExceptionHandlingFromLabel1:
		Exit Sub
Err_EnableUnstructuredExceptionHandlingFromLabel2:
	End Sub

	' Listing 5-18
	Public Sub EnableUnstructuredExceptionHandling4()
		Dim intResult As Integer
		Dim intValue As Integer

		On Error Goto Err_EnableUnstructuredExceptionHandlingFromLabel1
		Goto 20
19:
		intValue = 0
		intResult = 9 / intValue

		On Error Goto Err_EnableUnstructuredExceptionHandlingFromLabel2
20:
		intValue = 0
		intResult = 9 / intValue

		Exit Sub
Err_EnableUnstructuredExceptionHandlingFromLabel1:
		MsgBox("Err_EnableUnstructuredExceptionHandlingFromLabel1")
		Exit Sub
Err_EnableUnstructuredExceptionHandlingFromLabel2:
		Goto 19
	End Sub

	' Listing 5-19-1
	Public Sub UsingParentExceptionHandling()
		On Error Goto Err_EnableUnstructuredExceptionHandling

		UsesParentExceptionHandling()

		Exit Sub
Err_EnableUnstructuredExceptionHandling:
		MsgBox("Err_EnableUnstructuredExceptionHandling")
	End Sub

	' Listing 5-19-2
	Public Sub UsesParentExceptionHandling()
		Dim intResult As Integer
		Dim intValue As Integer

		intValue = 0
		intResult = 9 / intValue
	End Sub

	' Listing 5-20
	Public Sub DisableUnstructuredExceptionHandling()
		' Enable structured exception handling
		On Error Goto 5

		' Disable structured Exception handling
		On Error Goto -1
		UsesParentExceptionHandling()
		Exit Sub
5:
		Exit Sub
0:
		MsgBox("Line Number 0 has been reached!")
	End Sub

	' Listing 5-21
	Public Sub IgnoreExceptions()
		Dim intResult As Integer
		Dim intValue As Integer

		On Error Resume Next

		' Throw an exception
		intValue = 0
		intResult = 9 / intValue

		MsgBox("Was an exception thrown?", MsgBoxStyle.Question)
	End Sub

	' Listing 5-22
	Public Sub ResolveException()
		On Error Goto Err_EnableUnstructuredExceptionHandling

		Exit Sub
Err_EnableUnstructuredExceptionHandling:
		' Resolve exception
		'...

		' Continue execution by retrying the offending line of code
		Resume
	End Sub

	' Listing 5-23
	Public Sub WorkingAroundAnException()
		On Error Goto Err_EnableUnstructuredExceptionHandling

		Exit Sub
Err_EnableUnstructuredExceptionHandling:
		' Take other actions to work around the exception
		'...

		' Continue execution from the following line
		Resume Next
	End Sub

	' Listing 5-24
	Public Sub RaiseSystemException(ByVal vintExceptionNum As Integer)
		Err.Raise(vintExceptionNum)
	End Sub

	' Listing 5-25
	Public Sub RaiseUserException(ByVal vintExceptionNum As Integer)
		Err.Raise(vbObjectError + vintExceptionNum)
	End Sub

	' Listing 5-26
	Public Sub DetermineUserException(ByVal vlngExceptionNum As Long)
		Dim lngExceptionNum As Long

		lngExceptionNum = vlngExceptionNum - vbObjectError

		' Determine if this is a user-defined exception number
		If lngExceptionNum > 0 And lngExceptionNum < 65535 Then
			MsgBox("User-defined Exception")
		Else
			MsgBox("Visual Basic Exception")
		End If
	End Sub

	' Listing 5-27
	Public Sub CatchOpenConnectionException()
		Const STR_CONNECTION_STRING As String = "Data Source=USERMANPC1;" & _
		 "User ID=UserMan;Password=userman;Initial Catalog=UserMan"

		Dim cnnUserMan As SqlConnection

		On Error Goto Err_EnableUnstructuredExceptionHandling

		' Instantiate and open the connection
		cnnUserMan = New SqlConnection(STR_CONNECTION_STRING)
		cnnUserMan.Open()

		Exit Sub
Err_EnableUnstructuredExceptionHandling:
		MsgBox(Err.Description & vbCrLf & Err.Erl & vbCrLf & Err.Number & vbCrLf & _
		 Err.Source)
	End Sub
End Module
