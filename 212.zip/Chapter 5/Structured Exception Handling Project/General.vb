Imports System.Data.SqlClient

Module General
	Private Const PR_STR_CONNECTION_STRING As String = "Data Source=USERMANPC;" & _
	  "User ID=UserMan;Password=userman;Initial Catalog=UserMan"
	Private Const PR_STR_SQL_USER_SELECT As String = "SELECT * FROM tblUser"

	Public Sub StructuredExceptionHandler()
		Dim lngResult As Long
		Dim lngValue As Long = 0

		Try
			lngResult = 8 / lngValue
		Catch
			MsgBox("Catch")
		Finally
			MsgBox("Finally")
		End Try
	End Sub

	' Listing 5-2
	Public Sub TwoStructuredExceptionHandlers()
		Dim lngResult As Long
		Dim lngValue As Long = 0

		Try		 ' First exception handler
			lngResult = 8 / lngValue
		Catch objFirst As Exception
			MsgBox(objFirst.Message)
		End Try

		Try		 ' Second exception handler
			lngResult = 8 / lngValue
		Catch objSecond As Exception
			MsgBox(objSecond.Source)
		End Try
	End Sub

	' Listing 5-3
	Public Sub SimpleCatchBlock()
		Dim lngResult As Long
		Dim lngValue As Long = 0

		Try
			lngResult = 8 / lngValue
		Catch
			MsgBox("Catch")
		End Try
	End Sub

	' Listing 5-4
	Public Sub CatchBlockWithDefaultExceptionObject()
		Dim lngResult As Long
		Dim lngValue As Long = 0
		Dim objE As Exception

		Try
			lngResult = 8 / lngValue
		Catch objE
			MsgBox(objE.ToString)
		End Try
	End Sub

	' Listing 5-5
	Public Sub ThrowIndexOutOfRangeException()
		Dim arrlngException(2) As Long

		Try
			arrlngException(3) = 5
		Catch objE As Exception
			MsgBox(objE.ToString)
		End Try
	End Sub

	' Listing 5-6
	Public Sub ThrowNullreferenceException()
		Dim objException As Exception

		Try
			MsgBox(objException.Message)
		Catch objE As Exception
			MsgBox(objE.ToString)
		End Try
	End Sub

	' Listing 5-7
	Public Sub ThrowInvalidOperationException()
		Dim cnnUserMan As SqlConnection
		Dim cmmUser As SqlCommand
		Dim drdUser As SqlDataReader

		Try
			' Instantiate and open the connection
			cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
			cnnUserMan.Open()
			' Instantiate command
			cmmUser = New SqlCommand(PR_STR_SQL_USER_SELECT, cnnUserMan)
			' Instantiate and populate data reader
			drdUser = cmmUser.ExecuteReader()
			' Execute query while data reader is open
			cmmUser.ExecuteNonQuery()
		Catch objE As Exception
			MsgBox(objE.ToString)
		End Try
	End Sub

	' Listing 5-8
	Public Sub ThrowArgumentNullException()
		Dim cnnUserMan As SqlConnection
		Dim cmmUser As SqlCommand
		Dim dstUser As DataSet
		Dim dadUser As SqlDataAdapter

		Try
			' Instantiate and open the connection
			cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
			cnnUserMan.Open()
			' Instantiate command
			cmmUser = New SqlCommand()
			' Instatiate data adapter
			dadUser = New SqlDataAdapter(cmmUser)
			' Update data source
			dadUser.Update(dstUser)
		Catch objE As Exception
			MsgBox(objE.ToString)
		End Try
	End Sub

	' Listing 5-9
	Public Sub ThrowArgumentOutOfRangeException()
		Try
			' Display the first 200 chars from the connection string
			MsgBox(PR_STR_CONNECTION_STRING.Substring(1, 200))
		Catch objE As Exception
			MsgBox(objE.ToString)
		End Try
	End Sub

	' Listing 5-10
	Public Sub TypeFilterExceptions()
		Dim arrlngException(2) As Long
		Dim objException As Exception
		Dim lngResult As Long
		Dim lngValue As Long = 0

		Try
			arrlngException(3) = 5
			MsgBox(objException.Message)
			lngResult = 8 / lngValue
		Catch objE As NullReferenceException
			MsgBox("NullReferenceException")
		Catch objE As IndexOutOfRangeException
			MsgBox("IndexOutOfRangeException")
		Catch objE As Exception
			MsgBox("Exception")
		End Try
	End Sub

	' Listing 5-11
	Public Sub UserFilterExceptions()
		Dim objException1 As New Exception()
		Dim objException2 As Exception

		Try
			MsgBox(objException1.Message)
			MsgBox(objException2.Message)
		Catch objE As NullReferenceException When objException1 Is Nothing
			MsgBox("objException NullReferenceException1")
		Catch objE As NullReferenceException When objException2 Is Nothing
			MsgBox("objException NullReferenceException2")
		Catch objE As Exception
			MsgBox("Exception")
		End Try
	End Sub

	Public Sub ThrowException()
		Dim objUM As New UserManException()

		objUM.Source = "Test"
		Try
			Throw objUM
		Catch objE As Exception
			MsgBox(objE.Source)
		End Try
	End Sub

	' Listing 5-13
	Public Sub ExitSEH()
		Dim lngTest As Long = 0

		Try
			' Check to avoid a division by zero exception
			If lngTest = 0 Then Exit Sub

			lngTest = lngTest \ 0
		Catch objException As Exception
			MsgBox("This code is executed when an exception is thrown.")
		Finally
			MsgBox("This code is ALWAYS executed.")
		End Try

		MsgBox("This code is executed after the SEH ends. This is also true if you use an Exit Try statement.")
	End Sub

	' Listing 5-14
	Public Sub CatchSqlConnectionClassExceptions()
		Dim cnnUserMan As SqlConnection

		Try
			' Instantiate the connection
			cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING & ";Connection Timeout=-1")
		Catch objException As ArgumentException
			If objException.TargetSite.Name = "SetConnectTimeout" Then
				MsgBox(objException.StackTrace)
			End If
		End Try
	End Sub
End Module