' Listing 5-12
Public Class UserManException
	Inherits ApplicationException

	Private prstrSource As String = "UserManException"

	Public Overrides ReadOnly Property Message() As String
		Get
			Message = "This exception was thrown because you..."
		End Get
	End Property

	Public Overrides Property Source() As String
		Get
			Source = prstrSource
		End Get

		Set(ByVal Value As String)
			prstrSource = Value
		End Set
	End Property
End Class