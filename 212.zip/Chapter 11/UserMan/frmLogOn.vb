Option Strict On
Option Explicit On 

Imports System.Data.SqlClient

Public Class frmLogOn
	Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

	Public Sub New()
		MyBase.New()

		'This call is required by the Windows Form Designer.
		InitializeComponent()

		'Add any initialization after the InitializeComponent() call

	End Sub

	'Form overrides dispose to clean up the component list.
	Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
		If disposing Then
			If Not (components Is Nothing) Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(disposing)
	End Sub
	Friend WithEvents lblPassword As System.Windows.Forms.Label
	Friend WithEvents lblUserId As System.Windows.Forms.Label
	Friend WithEvents txtLoginName As System.Windows.Forms.TextBox
	Friend WithEvents txtPassword As System.Windows.Forms.TextBox
	Friend WithEvents btnOK As System.Windows.Forms.Button
	Friend WithEvents btnCancel As System.Windows.Forms.Button

	'Required by the Windows Form Designer
	Private components As System.ComponentModel.Container

	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.  
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
		Me.txtLoginName = New System.Windows.Forms.TextBox()
		Me.btnOK = New System.Windows.Forms.Button()
		Me.txtPassword = New System.Windows.Forms.TextBox()
		Me.lblUserId = New System.Windows.Forms.Label()
		Me.lblPassword = New System.Windows.Forms.Label()
		Me.btnCancel = New System.Windows.Forms.Button()
		Me.SuspendLayout()
		'
		'txtLoginName
		'
		Me.txtLoginName.Location = New System.Drawing.Point(70, 16)
		Me.txtLoginName.Name = "txtLoginName"
		Me.txtLoginName.Size = New System.Drawing.Size(165, 20)
		Me.txtLoginName.TabIndex = 1
		Me.txtLoginName.Text = ""
		'
		'btnOK
		'
		Me.btnOK.BackColor = System.Drawing.SystemColors.Control
		Me.btnOK.DialogResult = System.Windows.Forms.DialogResult.OK
		Me.btnOK.Location = New System.Drawing.Point(42, 76)
		Me.btnOK.Name = "btnOK"
		Me.btnOK.TabIndex = 4
		Me.btnOK.Text = "OK"
		'
		'txtPassword
		'
		Me.txtPassword.Location = New System.Drawing.Point(70, 38)
		Me.txtPassword.MaxLength = 50
		Me.txtPassword.Name = "txtPassword"
		Me.txtPassword.PasswordChar = ChrW(42)
		Me.txtPassword.Size = New System.Drawing.Size(165, 20)
		Me.txtPassword.TabIndex = 3
		Me.txtPassword.Text = ""
		'
		'lblUserId
		'
		Me.lblUserId.AutoSize = True
		Me.lblUserId.Location = New System.Drawing.Point(10, 20)
		Me.lblUserId.Name = "lblUserId"
		Me.lblUserId.Size = New System.Drawing.Size(44, 13)
		Me.lblUserId.TabIndex = 0
		Me.lblUserId.Text = "&User Id:"
		'
		'lblPassword
		'
		Me.lblPassword.AutoSize = True
		Me.lblPassword.Location = New System.Drawing.Point(10, 40)
		Me.lblPassword.Name = "lblPassword"
		Me.lblPassword.Size = New System.Drawing.Size(57, 13)
		Me.lblPassword.TabIndex = 2
		Me.lblPassword.Text = "&Password:"
		'
		'btnCancel
		'
		Me.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel
		Me.btnCancel.Location = New System.Drawing.Point(128, 76)
		Me.btnCancel.Name = "btnCancel"
		Me.btnCancel.TabIndex = 5
		Me.btnCancel.Text = "Cancel"
		'
		'frmLogOn
		'
		Me.AcceptButton = Me.btnOK
		Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
		Me.CancelButton = Me.btnCancel
		Me.ClientSize = New System.Drawing.Size(246, 116)
		Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnCancel, Me.btnOK, Me.txtPassword, Me.lblUserId, Me.lblPassword, Me.txtLoginName})
		Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
		Me.Name = "frmLogOn"
		Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
		Me.Text = "Log On"
		Me.ResumeLayout(False)

	End Sub

#End Region

	Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
		' Close the dialog
		Me.Close()
	End Sub

	Private Sub btnOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOK.Click
		Dim cnnUserMan As New SqlConnection()
		Dim cmmUser As New SqlCommand()
		Dim drdUser As SqlDataReader

		' Check if the Login Name is empty
		If txtLoginName.Text = "" Then
			' The password and/or loginname was incorrect
			MsgBox("You must type in the User Id!")
			' Set focus to the Login name text box
			ActiveControl = txtLoginName

			Exit Sub
		End If

		' Iniatialize and open the connection
		cnnUserMan.ConnectionString = "Data Source=USERMANPC;" & _
		 "User ID=UserMan;Password=userman;Initial Catalog=UserMan"
		cnnUserMan.Open()

		' Initialize the command
		cmmUser.Connection = cnnUserMan
		cmmUser.CommandType = CommandType.Text
		cmmUser.CommandText = "SELECT * FROM tblUser WHERE LoginName='" & txtLoginName.Text & _
		 "' AND Password='" & txtPassword.Text & "'"
		' Execute the command
		drdUser = cmmUser.ExecuteReader()

		' Check if a user was returned
		If drdUser.Read Then
			' The user can be logged on so fill the admin user object with returned values
			objAdminUser.SetUserProperties(drdUser("ADName"), drdUser("ADSID"), _
			 CType(drdUser("Id"), Long), drdUser("LoginName").ToString, drdUser("FirstName").ToString, _
			 drdUser("LastName"), drdUser("Password").ToString)
			LoggedOn = True
			' Close the dialog
			Me.Close()
		Else
			' The password and/or loginname was incorrect
			MsgBox("The User Id and/or Password supplied does not match a user in the system!")
			ActiveControl = txtLoginName
		End If
	End Sub
End Class