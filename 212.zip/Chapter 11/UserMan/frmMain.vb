Option Strict On
Option Explicit On 

Public Class frmMain
	Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

	Public Sub New()
		MyBase.New()

		'This call is required by the Windows Form Designer.
		InitializeComponent()

		'Add any initialization after the InitializeComponent() call
	End Sub

	'Form overrides dispose to clean up the component list.
	Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
		If disposing Then
			If Not (components Is Nothing) Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(disposing)
	End Sub
	Friend WithEvents mnuMain As System.Windows.Forms.MainMenu
	Friend WithEvents MdiClient1 As System.Windows.Forms.MdiClient
	Friend WithEvents mnuAdmin As System.Windows.Forms.MenuItem
	Friend WithEvents mnuAdminLogOn As System.Windows.Forms.MenuItem
	Friend WithEvents mnuAdminLogOff As System.Windows.Forms.MenuItem
	Friend WithEvents MenuItem1 As System.Windows.Forms.MenuItem
	Friend WithEvents mnuAdminProperties As System.Windows.Forms.MenuItem
	Friend WithEvents MenuItem2 As System.Windows.Forms.MenuItem
	Friend WithEvents mnuWindow As System.Windows.Forms.MenuItem
	Friend WithEvents mnuUser As System.Windows.Forms.MenuItem
	Friend WithEvents mnuAdminExit As System.Windows.Forms.MenuItem
	Friend WithEvents lblUserManWebSite As System.Windows.Forms.LinkLabel
	Friend WithEvents mnuUserViewAll As System.Windows.Forms.MenuItem
	Friend WithEvents mnuWindowArrangeAll As System.Windows.Forms.MenuItem
	
	'Required by the Windows Form Designer
	Private components As System.ComponentModel.Container

	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.  
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
		Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmMain))
		Me.mnuWindow = New System.Windows.Forms.MenuItem()
		Me.mnuUserViewAll = New System.Windows.Forms.MenuItem()
		Me.mnuAdmin = New System.Windows.Forms.MenuItem()
		Me.mnuAdminProperties = New System.Windows.Forms.MenuItem()
		Me.MenuItem1 = New System.Windows.Forms.MenuItem()
		Me.mnuAdminLogOn = New System.Windows.Forms.MenuItem()
		Me.mnuAdminLogOff = New System.Windows.Forms.MenuItem()
		Me.MenuItem2 = New System.Windows.Forms.MenuItem()
		Me.mnuAdminExit = New System.Windows.Forms.MenuItem()
		Me.mnuUser = New System.Windows.Forms.MenuItem()
		Me.MdiClient1 = New System.Windows.Forms.MdiClient()
		Me.lblUserManWebSite = New System.Windows.Forms.LinkLabel()
		Me.mnuMain = New System.Windows.Forms.MainMenu()
		Me.mnuWindowArrangeAll = New System.Windows.Forms.MenuItem()
		Me.SuspendLayout()
		'
		'mnuWindow
		'
		Me.mnuWindow.Index = 2
		Me.mnuWindow.MdiList = True
		Me.mnuWindow.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuWindowArrangeAll})
		Me.mnuWindow.Text = "&Window"
		'
		'mnuUserViewAll
		'
		Me.mnuUserViewAll.Index = 0
		Me.mnuUserViewAll.Text = "&View All"
		'
		'mnuAdmin
		'
		Me.mnuAdmin.Index = 0
		Me.mnuAdmin.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuAdminProperties, Me.MenuItem1, Me.mnuAdminLogOn, Me.mnuAdminLogOff, Me.MenuItem2, Me.mnuAdminExit})
		Me.mnuAdmin.Text = "&Admin"
		'
		'mnuAdminProperties
		'
		Me.mnuAdminProperties.Enabled = False
		Me.mnuAdminProperties.Index = 0
		Me.mnuAdminProperties.Text = "&Properties"
		'
		'MenuItem1
		'
		Me.MenuItem1.Index = 1
		Me.MenuItem1.Text = "-"
		'
		'mnuAdminLogOn
		'
		Me.mnuAdminLogOn.Index = 2
		Me.mnuAdminLogOn.Text = "Log &On..."
		'
		'mnuAdminLogOff
		'
		Me.mnuAdminLogOff.Enabled = False
		Me.mnuAdminLogOff.Index = 3
		Me.mnuAdminLogOff.Text = "Log O&ff"
		'
		'MenuItem2
		'
		Me.MenuItem2.Index = 4
		Me.MenuItem2.Text = "-"
		'
		'mnuAdminExit
		'
		Me.mnuAdminExit.Index = 5
		Me.mnuAdminExit.Text = "E&xit"
		'
		'mnuUser
		'
		Me.mnuUser.Enabled = False
		Me.mnuUser.Index = 1
		Me.mnuUser.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuUserViewAll})
		Me.mnuUser.Text = "&User"
		'
		'MdiClient1
		'
		Me.MdiClient1.Dock = System.Windows.Forms.DockStyle.Fill
		Me.MdiClient1.Name = "MdiClient1"
		Me.MdiClient1.TabIndex = 0
		'
		'lblUserManWebSite
		'
		Me.lblUserManWebSite.AccessibleRole = System.Windows.Forms.AccessibleRole.Link
		Me.lblUserManWebSite.Image = CType(resources.GetObject("lblUserManWebSite.Image"), System.Drawing.Bitmap)
		Me.lblUserManWebSite.Location = New System.Drawing.Point(188, 125)
		Me.lblUserManWebSite.Name = "lblUserManWebSite"
		Me.lblUserManWebSite.Size = New System.Drawing.Size(173, 75)
		Me.lblUserManWebSite.TabIndex = 1
		Me.lblUserManWebSite.TabStop = True
		Me.lblUserManWebSite.Text = "www.userman.dk"
		Me.lblUserManWebSite.TextAlign = System.Drawing.ContentAlignment.BottomCenter
		Me.lblUserManWebSite.UseMnemonic = False
		'
		'mnuMain
		'
		Me.mnuMain.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuAdmin, Me.mnuUser, Me.mnuWindow})
		'
		'mnuWindowArrangeAll
		'
		Me.mnuWindowArrangeAll.Index = 0
		Me.mnuWindowArrangeAll.Text = "&Arrange All"
		'
		'frmMain
		'
		Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
		Me.ClientSize = New System.Drawing.Size(569, 356)
		Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.lblUserManWebSite, Me.MdiClient1})
		Me.IsMdiContainer = True
		Me.Menu = Me.mnuMain
		Me.Name = "frmMain"
		Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
		Me.Text = "UserMan Example Application [Not Logged On]"
		Me.ResumeLayout(False)

	End Sub

#End Region

	Private Sub mnuAdminLogOn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuAdminLogOn.Click
		Dim frmLogon As New frmLogOn()

		' Show logon form as modal dialog
		frmLogon.ShowDialog()

		' Check if the user was logged on
		If LoggedOn Then
			Me.Text = "UserMan Example Application [" & objAdminUser.LoginName & "]"
			' Update the menus
			prEnableMenus(True)
			lblUserManWebSite.SendToBack()
		End If
	End Sub

	Private Sub mnuAdminLogOff_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuAdminLogOff.Click
		LoggedOn = False
		objAdminUser = Nothing
		objAdminUser = New CUser()
		Me.Text = "UserMan Example Application [Not Logged On]"
		' Update the menus
		prEnableMenus(False)
	End Sub

	Private Sub mnuAdminProperties_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuAdminProperties.Click
		Dim frmProperties As New frmProperties(True)

		' Make the properties form an MDI child of this form
		frmProperties.MdiParent = Me
		frmProperties.Show()
	End Sub

	Private Sub prEnableMenus(ByVal vblnLoggedOn As Boolean)
		mnuAdminLogOff.Enabled = vblnLoggedOn
		mnuAdminProperties.Enabled = vblnLoggedOn
		mnuUser.Enabled = vblnLoggedOn
	End Sub

	Private Sub mnuAdminExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuAdminExit.Click
		' Unload application
		Me.Close()
	End Sub

	Private Sub lblUserManWebSite_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles lblUserManWebSite.LinkClicked
		lblUserManWebSite.LinkVisited = True
		' Open the default browser 
		System.Diagnostics.Process.Start("http://www.userman.dk")
	End Sub

	Private Sub frmMain_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Resize
		' Center the link label
		lblUserManWebSite.Top = (Me.Height - lblUserManWebSite.Height) \ 2
		lblUserManWebSite.Left = (Me.Width - lblUserManWebSite.Width) \ 2
	End Sub

	Private Sub mnuUserViewAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuUserViewAll.Click
		Dim frmUsers As New frmUsers()

		' Make the users form an MDI child of this form
		frmUsers.MdiParent = Me
		frmUsers.Show()
	End Sub

	Private Sub mnuWindowArrangeAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuWindowArrangeAll.Click
		Me.LayoutMdi(Windows.Forms.MdiLayout.TileHorizontal)
	End Sub
End Class
