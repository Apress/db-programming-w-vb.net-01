Option Strict On
Option Explicit On 

' Listing 11-12
Imports System.Data.OleDb

Public Class CActiveDirectory
	' Database objects
	Private prcnnAD As OleDbConnection
	Private prcmmAD As OleDbCommand
	Private prdrdAD As OleDbDataReader

	Private Sub OpenConnection()
		' Instantiate and open connection
		prcnnAD = New OleDbConnection("Provider=ADsDSOObject;" & _
		 "User Id=UserMan;Password=userman")
		prcnnAD.Open()
	End Sub

	Private Sub RetrieveUserInformation()
		' Instantiate command
		prcmmAD = New OleDbCommand("SELECT cn, adsPath FROM " & _
		 "'LDAP://userman.com' WHERE objectCategory='person' AND " & _
		 "objectClass='user' AND cn='UserMan'", prcnnAD)
		' Retrieve UserMan info in data reader
		prdrdAD = prcmmAD.ExecuteReader()
	End Sub
End Class