Public Class frmUsers
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub
	Friend WithEvents OleDbSelectCommand1 As System.Data.OleDb.OleDbCommand
	Friend WithEvents OleDbInsertCommand1 As System.Data.OleDb.OleDbCommand
	Friend WithEvents OleDbUpdateCommand1 As System.Data.OleDb.OleDbCommand
	Friend WithEvents OleDbDeleteCommand1 As System.Data.OleDb.OleDbCommand
	Friend WithEvents objUsers As UserMan.Users
	Friend WithEvents OleDbConnection1 As System.Data.OleDb.OleDbConnection
	Friend WithEvents OleDbDataAdapter1 As System.Data.OleDb.OleDbDataAdapter
	Friend WithEvents btnLoad As System.Windows.Forms.Button
	Friend WithEvents btnUpdate As System.Windows.Forms.Button
	Friend WithEvents btnCancelAll As System.Windows.Forms.Button
	Friend WithEvents grdtblUser As System.Windows.Forms.DataGrid
	Friend WithEvents objTableStylegrdtblUsertblUser As System.Windows.Forms.DataGridTableStyle
	Friend WithEvents objColumnStylegrdtblUserId As System.Windows.Forms.DataGridTextBoxColumn
	Friend WithEvents objColumnStylegrdtblUserADName As System.Windows.Forms.DataGridTextBoxColumn
	Friend WithEvents objColumnStylegrdtblUserFirstName As System.Windows.Forms.DataGridTextBoxColumn
	Friend WithEvents objColumnStylegrdtblUserLastName As System.Windows.Forms.DataGridTextBoxColumn
	Friend WithEvents objColumnStylegrdtblUserLoginName As System.Windows.Forms.DataGridTextBoxColumn
	Friend WithEvents objColumnStylegrdtblUserPassword As System.Windows.Forms.DataGridTextBoxColumn
	Friend WithEvents DataGridTableStyle1 As System.Windows.Forms.DataGridTableStyle
	Friend WithEvents DataGridTextBoxColumn1 As System.Windows.Forms.DataGridTextBoxColumn
	Friend WithEvents DataGridTextBoxColumn2 As System.Windows.Forms.DataGridTextBoxColumn
	Friend WithEvents DataGridTextBoxColumn3 As System.Windows.Forms.DataGridTextBoxColumn
	Friend WithEvents DataGridTextBoxColumn4 As System.Windows.Forms.DataGridTextBoxColumn
	Friend WithEvents DataGridTextBoxColumn5 As System.Windows.Forms.DataGridTextBoxColumn
	Friend WithEvents DataGridTextBoxColumn6 As System.Windows.Forms.DataGridTextBoxColumn

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
		Me.grdtblUser = New System.Windows.Forms.DataGrid()
		Me.objUsers = New UserMan.Users()
		Me.OleDbDeleteCommand1 = New System.Data.OleDb.OleDbCommand()
		Me.OleDbConnection1 = New System.Data.OleDb.OleDbConnection()
		Me.OleDbUpdateCommand1 = New System.Data.OleDb.OleDbCommand()
		Me.OleDbSelectCommand1 = New System.Data.OleDb.OleDbCommand()
		Me.OleDbDataAdapter1 = New System.Data.OleDb.OleDbDataAdapter()
		Me.OleDbInsertCommand1 = New System.Data.OleDb.OleDbCommand()
		Me.btnUpdate = New System.Windows.Forms.Button()
		Me.btnLoad = New System.Windows.Forms.Button()
		Me.btnCancelAll = New System.Windows.Forms.Button()
		Me.DataGridTableStyle1 = New System.Windows.Forms.DataGridTableStyle()
		Me.DataGridTextBoxColumn1 = New System.Windows.Forms.DataGridTextBoxColumn()
		Me.DataGridTextBoxColumn2 = New System.Windows.Forms.DataGridTextBoxColumn()
		Me.DataGridTextBoxColumn3 = New System.Windows.Forms.DataGridTextBoxColumn()
		Me.DataGridTextBoxColumn4 = New System.Windows.Forms.DataGridTextBoxColumn()
		Me.DataGridTextBoxColumn5 = New System.Windows.Forms.DataGridTextBoxColumn()
		Me.DataGridTextBoxColumn6 = New System.Windows.Forms.DataGridTextBoxColumn()
		CType(Me.grdtblUser, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.objUsers, System.ComponentModel.ISupportInitialize).BeginInit()
		Me.SuspendLayout()
		'
		'grdtblUser
		'
		Me.grdtblUser.DataMember = "tblUser"
		Me.grdtblUser.DataSource = Me.objUsers
		Me.grdtblUser.Location = New System.Drawing.Point(10, 76)
		Me.grdtblUser.Name = "grdtblUser"
		Me.grdtblUser.Size = New System.Drawing.Size(491, 164)
		Me.grdtblUser.TabIndex = 3
		Me.grdtblUser.TableStyles.AddRange(New System.Windows.Forms.DataGridTableStyle() {Me.DataGridTableStyle1})
		'
		'objUsers
		'
		Me.objUsers.DataSetName = "Users"
		Me.objUsers.Locale = New System.Globalization.CultureInfo("en-US")
		Me.objUsers.Namespace = "http://www.tempuri.org/Users.xsd"
		'
		'OleDbDeleteCommand1
		'
		Me.OleDbDeleteCommand1.CommandText = "DELETE FROM tblUser WHERE (Id = ?) AND (ADName = ? OR ? IS NULL AND ADName IS NUL" & _
		"L) AND (ADSID = ? OR ? IS NULL AND ADSID IS NULL) AND (FirstName = ? OR ? IS NUL" & _
		"L AND FirstName IS NULL) AND (LastName = ? OR ? IS NULL AND LastName IS NULL) AN" & _
		"D (LoginName = ?) AND (Password = ?)"
		Me.OleDbDeleteCommand1.Connection = Me.OleDbConnection1
		Me.OleDbDeleteCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Id", System.Data.OleDb.OleDbType.Integer, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Id", System.Data.DataRowVersion.Original, Nothing))
		Me.OleDbDeleteCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("ADName", System.Data.OleDb.OleDbType.VarChar, 100, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "ADName", System.Data.DataRowVersion.Original, Nothing))
		Me.OleDbDeleteCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("ADName1", System.Data.OleDb.OleDbType.VarChar, 100, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "ADName", System.Data.DataRowVersion.Original, Nothing))
		Me.OleDbDeleteCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("ADSID", System.Data.OleDb.OleDbType.Guid, 16, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "ADSID", System.Data.DataRowVersion.Original, Nothing))
		Me.OleDbDeleteCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("ADSID1", System.Data.OleDb.OleDbType.Guid, 16, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "ADSID", System.Data.DataRowVersion.Original, Nothing))
		Me.OleDbDeleteCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("FirstName", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "FirstName", System.Data.DataRowVersion.Original, Nothing))
		Me.OleDbDeleteCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("FirstName1", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "FirstName", System.Data.DataRowVersion.Original, Nothing))
		Me.OleDbDeleteCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("LastName", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "LastName", System.Data.DataRowVersion.Original, Nothing))
		Me.OleDbDeleteCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("LastName1", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "LastName", System.Data.DataRowVersion.Original, Nothing))
		Me.OleDbDeleteCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("LoginName", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "LoginName", System.Data.DataRowVersion.Original, Nothing))
		Me.OleDbDeleteCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Password", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Password", System.Data.DataRowVersion.Original, Nothing))
		'
		'OleDbConnection1
		'
		Me.OleDbConnection1.ConnectionString = "Provider=SQLOLEDB.1;Integrated Security=SSPI;Persist Security Info=False;Initial " & _
		"Catalog=UserMan;Data Source=USERMANPC;Use Procedure for Prepare=1;Auto Tran" & _
		"slate=True;Packet Size=4096;Workstation ID=INTERNET-GATE;Use Encryption for Data" & _
		"=False;Tag with column collation when possible=False"
		'
		'OleDbUpdateCommand1
		'
		Me.OleDbUpdateCommand1.CommandText = "UPDATE tblUser SET ADName = ?, ADSID = ?, FirstName = ?, LastName = ?, LoginName " & _
		"= ?, Password = ? WHERE (Id = ?) AND (ADName = ? OR ? IS NULL AND ADName IS NULL" & _
		") AND (ADSID = ? OR ? IS NULL AND ADSID IS NULL) AND (FirstName = ? OR ? IS NULL" & _
		" AND FirstName IS NULL) AND (LastName = ? OR ? IS NULL AND LastName IS NULL) AND" & _
		" (LoginName = ?) AND (Password = ?); SELECT Id, ADName, ADSID, FirstName, LastNa" & _
		"me, LoginName, Password FROM tblUser WHERE (Id = ?)"
		Me.OleDbUpdateCommand1.Connection = Me.OleDbConnection1
		Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("ADName", System.Data.OleDb.OleDbType.VarChar, 100, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "ADName", System.Data.DataRowVersion.Current, Nothing))
		Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("ADSID", System.Data.OleDb.OleDbType.Guid, 16, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "ADSID", System.Data.DataRowVersion.Current, Nothing))
		Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("FirstName", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "FirstName", System.Data.DataRowVersion.Current, Nothing))
		Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("LastName", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "LastName", System.Data.DataRowVersion.Current, Nothing))
		Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("LoginName", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "LoginName", System.Data.DataRowVersion.Current, Nothing))
		Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Password", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Password", System.Data.DataRowVersion.Current, Nothing))
		Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_Id", System.Data.OleDb.OleDbType.Integer, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Id", System.Data.DataRowVersion.Original, Nothing))
		Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_ADName", System.Data.OleDb.OleDbType.VarChar, 100, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "ADName", System.Data.DataRowVersion.Original, Nothing))
		Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_ADName1", System.Data.OleDb.OleDbType.VarChar, 100, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "ADName", System.Data.DataRowVersion.Original, Nothing))
		Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_ADSID", System.Data.OleDb.OleDbType.Guid, 16, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "ADSID", System.Data.DataRowVersion.Original, Nothing))
		Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_ADSID1", System.Data.OleDb.OleDbType.Guid, 16, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "ADSID", System.Data.DataRowVersion.Original, Nothing))
		Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_FirstName", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "FirstName", System.Data.DataRowVersion.Original, Nothing))
		Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_FirstName1", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "FirstName", System.Data.DataRowVersion.Original, Nothing))
		Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_LastName", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "LastName", System.Data.DataRowVersion.Original, Nothing))
		Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_LastName1", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "LastName", System.Data.DataRowVersion.Original, Nothing))
		Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_LoginName", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "LoginName", System.Data.DataRowVersion.Original, Nothing))
		Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_Password", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Password", System.Data.DataRowVersion.Original, Nothing))
		Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Select_Id", System.Data.OleDb.OleDbType.Integer, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Id", System.Data.DataRowVersion.Current, Nothing))
		'
		'OleDbSelectCommand1
		'
		Me.OleDbSelectCommand1.CommandText = "SELECT Id, ADName, ADSID, FirstName, LastName, LoginName, Password FROM tblUser"
		Me.OleDbSelectCommand1.Connection = Me.OleDbConnection1
		'
		'OleDbDataAdapter1
		'
		Me.OleDbDataAdapter1.DeleteCommand = Me.OleDbDeleteCommand1
		Me.OleDbDataAdapter1.InsertCommand = Me.OleDbInsertCommand1
		Me.OleDbDataAdapter1.SelectCommand = Me.OleDbSelectCommand1
		Me.OleDbDataAdapter1.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "tblUser", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("Id", "Id"), New System.Data.Common.DataColumnMapping("ADName", "ADName"), New System.Data.Common.DataColumnMapping("ADSID", "ADSID"), New System.Data.Common.DataColumnMapping("FirstName", "FirstName"), New System.Data.Common.DataColumnMapping("LastName", "LastName"), New System.Data.Common.DataColumnMapping("LoginName", "LoginName"), New System.Data.Common.DataColumnMapping("Password", "Password")})})
		Me.OleDbDataAdapter1.UpdateCommand = Me.OleDbUpdateCommand1
		'
		'OleDbInsertCommand1
		'
		Me.OleDbInsertCommand1.CommandText = "INSERT INTO tblUser(ADName, ADSID, FirstName, LastName, LoginName, Password) VALU" & _
		"ES (?, ?, ?, ?, ?, ?); SELECT Id, ADName, ADSID, FirstName, LastName, LoginName," & _
		" Password FROM tblUser WHERE (Id = @@IDENTITY)"
		Me.OleDbInsertCommand1.Connection = Me.OleDbConnection1
		Me.OleDbInsertCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("ADName", System.Data.OleDb.OleDbType.VarChar, 100, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "ADName", System.Data.DataRowVersion.Current, Nothing))
		Me.OleDbInsertCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("ADSID", System.Data.OleDb.OleDbType.Guid, 16, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "ADSID", System.Data.DataRowVersion.Current, Nothing))
		Me.OleDbInsertCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("FirstName", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "FirstName", System.Data.DataRowVersion.Current, Nothing))
		Me.OleDbInsertCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("LastName", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "LastName", System.Data.DataRowVersion.Current, Nothing))
		Me.OleDbInsertCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("LoginName", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "LoginName", System.Data.DataRowVersion.Current, Nothing))
		Me.OleDbInsertCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Password", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Password", System.Data.DataRowVersion.Current, Nothing))
		'
		'btnUpdate
		'
		Me.btnUpdate.Location = New System.Drawing.Point(426, 10)
		Me.btnUpdate.Name = "btnUpdate"
		Me.btnUpdate.TabIndex = 1
		Me.btnUpdate.Text = "&Update"
		'
		'btnLoad
		'
		Me.btnLoad.Location = New System.Drawing.Point(10, 10)
		Me.btnLoad.Name = "btnLoad"
		Me.btnLoad.TabIndex = 0
		Me.btnLoad.Text = "&Load"
		'
		'btnCancelAll
		'
		Me.btnCancelAll.Location = New System.Drawing.Point(426, 43)
		Me.btnCancelAll.Name = "btnCancelAll"
		Me.btnCancelAll.TabIndex = 2
		Me.btnCancelAll.Text = "Ca&ncel All"
		'
		'DataGridTableStyle1
		'
		Me.DataGridTableStyle1.DataGrid = Me.grdtblUser
		Me.DataGridTableStyle1.GridColumnStyles.AddRange(New System.Windows.Forms.DataGridColumnStyle() {Me.DataGridTextBoxColumn1, Me.DataGridTextBoxColumn2, Me.DataGridTextBoxColumn3, Me.DataGridTextBoxColumn4, Me.DataGridTextBoxColumn5, Me.DataGridTextBoxColumn6})
		Me.DataGridTableStyle1.MappingName = "tblUser"
		'
		'DataGridTextBoxColumn1
		'
		Me.DataGridTextBoxColumn1.Format = ""
		Me.DataGridTextBoxColumn1.FormatInfo = Nothing
		Me.DataGridTextBoxColumn1.HeaderText = "Id"
		Me.DataGridTextBoxColumn1.MappingName = "Id"
		Me.DataGridTextBoxColumn1.Width = 75
		'
		'DataGridTextBoxColumn2
		'
		Me.DataGridTextBoxColumn2.Format = ""
		Me.DataGridTextBoxColumn2.FormatInfo = Nothing
		Me.DataGridTextBoxColumn2.HeaderText = "ADName"
		Me.DataGridTextBoxColumn2.MappingName = "ADName"
		Me.DataGridTextBoxColumn2.Width = 75
		'
		'DataGridTextBoxColumn3
		'
		Me.DataGridTextBoxColumn3.Format = ""
		Me.DataGridTextBoxColumn3.FormatInfo = Nothing
		Me.DataGridTextBoxColumn3.HeaderText = "FirstName"
		Me.DataGridTextBoxColumn3.MappingName = "FirstName"
		Me.DataGridTextBoxColumn3.Width = 75
		'
		'DataGridTextBoxColumn4
		'
		Me.DataGridTextBoxColumn4.Format = ""
		Me.DataGridTextBoxColumn4.FormatInfo = Nothing
		Me.DataGridTextBoxColumn4.HeaderText = "LastName"
		Me.DataGridTextBoxColumn4.MappingName = "LastName"
		Me.DataGridTextBoxColumn4.Width = 75
		'
		'DataGridTextBoxColumn5
		'
		Me.DataGridTextBoxColumn5.Format = ""
		Me.DataGridTextBoxColumn5.FormatInfo = Nothing
		Me.DataGridTextBoxColumn5.HeaderText = "LoginName"
		Me.DataGridTextBoxColumn5.MappingName = "LoginName"
		Me.DataGridTextBoxColumn5.Width = 75
		'
		'DataGridTextBoxColumn6
		'
		Me.DataGridTextBoxColumn6.Format = ""
		Me.DataGridTextBoxColumn6.FormatInfo = Nothing
		Me.DataGridTextBoxColumn6.HeaderText = "Password"
		Me.DataGridTextBoxColumn6.MappingName = "Password"
		Me.DataGridTextBoxColumn6.Width = 75
		'
		'frmUsers
		'
		Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
		Me.AutoScroll = True
		Me.ClientSize = New System.Drawing.Size(492, 209)
		Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnLoad, Me.btnUpdate, Me.btnCancelAll, Me.grdtblUser})
		Me.Name = "frmUsers"
		Me.Text = "Users"
		CType(Me.grdtblUser, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.objUsers, System.ComponentModel.ISupportInitialize).EndInit()
		Me.ResumeLayout(False)

	End Sub

#End Region

	Private Sub btnUpdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUpdate.Click
		Try
			Me.UpdateDataSet()
		Catch eUpdate As System.Exception
			System.Windows.Forms.MessageBox.Show(eUpdate.Message)
		End Try

	End Sub
	Private Sub btnLoad_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLoad.Click
		Try
			Me.LoadDataSet()
		Catch eLoad As System.Exception
			System.Windows.Forms.MessageBox.Show(eLoad.Message)
		End Try

	End Sub
	Private Sub btnCancelAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancelAll.Click
		Me.objUsers.RejectChanges()

	End Sub
	Public Sub UpdateDataSet()
		'Get a new dataset that holds only the changes that have been made to the main dataset
		Dim objDataSetChanges As UserMan.Users = New UserMan.Users()
		Dim objDataSetUpdated As System.Data.DataSet = New UserMan.Users()
		'Clear out the current edits
		Me.BindingContext(objUsers, "tblUser").EndCurrentEdit()
		'Get a new dataset that holds only the changes that have been made to the main dataset
		objDataSetChanges = CType(objUsers.GetChanges, UserMan.Users)
		'Check to see if the objCustomersDatasetChanges holds any records
		If (Not (objDataSetChanges) Is Nothing) Then
			Try
				'Call the update method passing inthe dataset and any parameters
				Me.UpdateDataSource(objDataSetChanges)
			Catch eUpdate As System.Exception
				'If the update failed and is part of a transaction, this is the place to put your rollback
				Throw eUpdate
			End Try
			'If the update succeeded and is part of a transaction, this is the place to put your commit
			'Add code to Check the returned dataset - objCustomersDataSetUpdate for any errors that may have been
			'pushed into the row object's error
			'Merge the returned changes back into the main dataset
			Try
				objUsers.Merge(objDataSetUpdated)
			Catch eUpdateMerge As System.Exception
				'Add exception handling code here
				Throw eUpdateMerge
			End Try
			'Commit the changes that were just merged
			'This moves any rows marked as updated, inserted or changed to being marked as original values
			objUsers.AcceptChanges()
		End If

	End Sub
	Public Sub LoadDataSet()
		Dim objDataSetTemp As UserMan.Users
		objDataSetTemp = New UserMan.Users()
		Try
			'Execute the SelectCommand on the DatasetCommmand and fill the dataset
			Me.FillDataSet(objDataSetTemp)
		Catch eFillDataSet As System.Exception
			'Add exception handling code here.
			Throw eFillDataSet
		End Try
		Try
			'Merge the records that were just pulled from the data store into the main dataset
			objUsers.Merge(objDataSetTemp)
		Catch eLoadMerge As System.Exception
			'Add exception handling code here
			Throw eLoadMerge
		End Try

	End Sub
	Public Function UpdateDataSource(ByVal dataSet As UserMan.Users) As System.Int32
		Me.OleDbConnection1.Open()

		Dim UpdatedRows As System.Data.DataSet
		Dim InsertedRows As System.Data.DataSet
		Dim DeletedRows As System.Data.DataSet
		Dim AffectedRows As Integer = 0

		UpdatedRows = dataSet.GetChanges(System.Data.DataRowState.Modified)
		InsertedRows = dataSet.GetChanges(System.Data.DataRowState.Added)
		DeletedRows = dataSet.GetChanges(System.Data.DataRowState.Deleted)
		Try
			If (Not (UpdatedRows) Is Nothing) Then
				AffectedRows = OleDbDataAdapter1.Update(UpdatedRows)
			End If
			If (Not (InsertedRows) Is Nothing) Then
				AffectedRows = (AffectedRows + OleDbDataAdapter1.Update(InsertedRows))
			End If
			If (Not (DeletedRows) Is Nothing) Then
				AffectedRows = (AffectedRows + OleDbDataAdapter1.Update(DeletedRows))
			End If
		Catch updateException As System.Exception
			Throw updateException
		Finally
			Me.OleDbConnection1.Close()
		End Try


	End Function
	Public Sub FillDataSet(ByVal dataSet As UserMan.Users)
		Me.OleDbConnection1.Open()

		dataSet.EnforceConstraints = False
		Try
			Me.OleDbDataAdapter1.Fill(dataSet)
		Catch fillException As System.Exception
			Throw fillException
		Finally
			dataSet.EnforceConstraints = True
			Me.OleDbConnection1.Close()
		End Try

	End Sub
End Class
