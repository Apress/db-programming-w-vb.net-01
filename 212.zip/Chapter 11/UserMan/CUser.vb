Option Strict On
Option Explicit On 

Imports System.Data.SqlClient

Public Class CUser
	' Listing 11-1-1
	' Database constants
	Private Const PR_STR_CONNECTION As String = "Data Source=USERMANPC;" & _
	 "User ID=UserMan;Password=userman;Initial Catalog=UserMan"
	Private Const PR_STR_SQL_USER_SELECT As String = "SELECT * FROM tblUser"
	Private Const PR_STR_SQL_USER_DELETE As String = "DELETE FROM tblUser WHERE Id=@Id"
	Private Const PR_STR_SQL_USER_INSERT As String = "INSERT INTO tblUser(FirstName, LastName, LoginName, Password) VALUES(@FirstName, @LastName, @LoginName, @Password)"
	Private Const PR_STR_SQL_USER_UPDATE As String = "UPDATE tblUser SET FirstName=@FirstName, LastName=@LastName, LoginName=@LoginName, Password=@Password WHERE Id=@Id"
	Private Const PR_STR_SQL_TABLE_USER_FIELD_ID As String = "Id"

	' User table column values
	Private prlngId As Long = 0
	Private prstrADName As String
	Private prguiADSID As Guid
	Private prstrFirstName As String = ""
	Private prstrLastName As String = ""
	Private prstrLoginName As String = ""
	Private prstrPassword As String = ""
	' User table column max lengths
	Private prshtADNameMaxLen As Short
	Private prshtFirstNameMaxLen As Short
	Private prshtLastNameMaxLen As Short
	Private prshtLoginNameMaxLen As Short
	Private prshtPasswordMaxLen As Short

	' Listing 11-1-2
	' Database variables
	Private Shared prshcnnUserMan As SqlConnection
	Private prdadUserMan As SqlDataAdapter
	Private prdstUserMan As DataSet

	' Listing 11-1-3
	' For direct user table manipulation
	Private prcmmUser As SqlCommand
	' The command objects for the dataset manipulation
	Private prcmmUserSelect As SqlCommand
	Private prcmmUserDelete As SqlCommand
	Private prcmmUserInsert As SqlCommand
	Private prcmmUserUpdate As SqlCommand

	' Listing 11-1-4
	' Parameter objects for the data set manipulation
	Private prprmSQLDelete, prprmSQLUpdate, prprmSQLInsert As SqlParameter

	' For logging user activity
	Private probjLog As New CLog()

	' Listing 11-2
	Private Sub OpenDatabaseConnection()
		Try
			' Check if the connection has already been instantiated
			If prshcnnUserMan Is Nothing Then
				' Instantiate the connection
				prshcnnUserMan = New SqlConnection(PR_STR_CONNECTION)
				' Check if the connection is closed
				If CBool(prshcnnUserMan.State = ConnectionState.Closed) Then
					' Open the connection
					prshcnnUserMan.Open()
					' Log activity if the user has already been logged on
					If prlngId > 0 Then
						probjLog.Logged = Now
						probjLog.Description = "Database connection opened."
						probjLog.UserId = prlngId
						probjLog.AddLogEntry()
					End If
				End If
			End If
		Catch objSqlException As SqlException
			' A Connection low-level exception was thrown. Add a description and re-throw
			' the exception to the caller of this class
			Throw New Exception("The connection to the UserMan database could not be " & _
			 "established, due to a connection low-level error", objSqlException)
		Catch objE As Exception
			' Any other exception thrown is handled here
			Throw New Exception("The connection to the UserMan database could not be " & _
			 "established.", objE)
		End Try
	End Sub

	' Listing 11-3
	Public Sub New()
		' Perform standard inherited instantiation
		MyBase.New()
		' Open the connection to the database
		OpenDatabaseConnection()
		' Instantiate the command objects
		InstantiateCommands()
		' Instantiate the dataset
		InstantiateDataSet()
		' Instantiate and populate the data adapter
		InstantiateAndInitializeDataAdapter()
		' Add paramerts to the command objects
		AddCommandObjectParameters()
		' Get source table schema
		prSetColumnMaxLength()
		' Populate the data set with data
		PopulateDataSet()
		' Save the dataset valuies
		SaveDataSetValues()
	End Sub

	' Listing 11-4
	Private Sub CloseDatabaseConnection()
		Try
			' Close the connection
			prshcnnUserMan.Close()
			' Log activity if the user has already been logged on
			If prlngId > 0 Then
				probjLog.Logged = Now
				probjLog.Description = "Database connection closed."
				probjLog.UserId = prlngId
				probjLog.AddLogEntry()
			End If
		Catch objE As Exception
			Throw New Exception("The connection to the UserMan database could not be closed properly.", objE)
		End Try
	End Sub

	' Listing 11-5
	Protected Overrides Sub Finalize()
		' Close the database connection
		CloseDatabaseConnection()
		MyBase.Finalize()
	End Sub

	' Listing 11-6
	Private Sub InstantiateCommands()
		' Instantiate the data set command objects
		prcmmUserSelect = New SqlCommand(PR_STR_SQL_USER_SELECT, prshcnnUserMan)
		prcmmUserDelete = New SqlCommand(PR_STR_SQL_USER_DELETE, prshcnnUserMan)
		prcmmUserInsert = New SqlCommand(PR_STR_SQL_USER_INSERT, prshcnnUserMan)
		prcmmUserUpdate = New SqlCommand(PR_STR_SQL_USER_UPDATE, prshcnnUserMan)
		' Instantiate and initialize generic command object
		prcmmUser = New SqlCommand()
		prcmmUser.Connection = prshcnnUserMan
	End Sub

	' Listing 11-7
	Private Sub InstantiateDataSet()
		prdstUserMan = New DataSet()
	End Sub

	' Listing 11-8
	Private Sub InstantiateAndInitializeDataAdapter()
		prdadUserMan = New SqlDataAdapter()
		prdadUserMan.SelectCommand = prcmmUserSelect
		prdadUserMan.InsertCommand = prcmmUserInsert
		prdadUserMan.DeleteCommand = prcmmUserDelete
		prdadUserMan.UpdateCommand = prcmmUserUpdate
	End Sub

	' Listing 11-9
	Private Sub AddCommandObjectParameters()
		' Add delete command parameters
		prcmmUserDelete.Parameters.Add("@FirstName", SqlDbType.VarChar, 50, _
		 "FirstName")
		prcmmUserDelete.Parameters.Add("@LastName", SqlDbType.VarChar, 50, _
		 "LastName")
		prcmmUserDelete.Parameters.Add("@LoginName", SqlDbType.VarChar, 50, _
		 "LoginName")
		prcmmUserDelete.Parameters.Add("@Password", SqlDbType.VarChar, 50, _
		 "Password")
		prprmSQLDelete = prdadUserMan.DeleteCommand.Parameters.Add("@Id", _
		 SqlDbType.Int, 0, "Id")
		prprmSQLDelete.Direction = ParameterDirection.Input
		prprmSQLDelete.SourceVersion = DataRowVersion.Original

		' Add update command parameters
		prcmmUserUpdate.Parameters.Add("@FirstName", SqlDbType.VarChar, 50, _
		 "FirstName")
		prcmmUserUpdate.Parameters.Add("@LastName", SqlDbType.VarChar, 50, _
		 "LastName")
		prcmmUserUpdate.Parameters.Add("@LoginName", SqlDbType.VarChar, 50, _
		 "LoginName")
		prcmmUserUpdate.Parameters.Add("@Password", SqlDbType.VarChar, 50, _
		 "Password")
		prprmSQLUpdate = prdadUserMan.UpdateCommand.Parameters.Add("@Id", _
		 SqlDbType.Int, 0, "Id")
		prprmSQLUpdate.Direction = ParameterDirection.Input
		prprmSQLUpdate.SourceVersion = DataRowVersion.Original

		' Add insert command parameters
		prcmmUserInsert.Parameters.Add("@FirstName", SqlDbType.VarChar, 50, _
		 "FirstName")
		prcmmUserInsert.Parameters.Add("@LastName", SqlDbType.VarChar, 50, _
		 "LastName")
		prcmmUserInsert.Parameters.Add("@LoginName", SqlDbType.VarChar, 50, _
		 "LoginName")
		prcmmUserInsert.Parameters.Add("@Password", SqlDbType.VarChar, 50, _
		 "Password")
	End Sub

	' Listing 11-10
	Private Sub PopulateDataSet()
		Try
			prdadUserMan.Fill(prdstUserMan, "tblUser")
		Catch objSystemException As SystemException
			Throw New Exception("The dataset could not be populated, " & _
			 "because the source table was invalid.", objSystemException)
		Catch objE As Exception
			Throw New Exception("The dataset could not be populated.", objE)
		End Try
	End Sub

	' Listing 11-11
	Private Sub SaveDataSetValues()
		' Save user id
		prlngId = CType(prdstUserMan.Tables("tbluser").Rows(0).Item("Id"), Long)
		' Check if ADName is Null
		If prdstUserMan.Tables("tbluser").Rows(0).IsNull("ADName") Then
			prstrADName = ""
		Else
			prstrADName = CType(prdstUserMan.Tables("tbluser").Rows(0).Item("ADName"), String)
		End If
		' Check if ADSID is Null
		If Not prdstUserMan.Tables("tbluser").Rows(0).IsNull("ADSID") Then
			prguiADSID = CType(prdstUserMan.Tables("tbluser").Rows(0).Item("ADSID"), Guid)
		End If
		' Check if first name is Null
		If prdstUserMan.Tables("tbluser").Rows(0).IsNull("FirstName") Then
			prstrFirstName = ""
		Else
			prstrFirstName = CType(prdstUserMan.Tables("tbluser").Rows(0).Item("FirstName"), String)
		End If
		' Check if last name is Null
		If prdstUserMan.Tables("tbluser").Rows(0).IsNull("LastName") Then
			prstrLastName = ""
		Else
			prstrLastName = CType(prdstUserMan.Tables("tbluser").Rows(0).Item("LastName"), String)
		End If
		' Check if login name is Null
		If prdstUserMan.Tables("tbluser").Rows(0).IsNull("LoginName") Then
			prstrLoginName = ""
		Else
			prstrLoginName = CType(prdstUserMan.Tables("tbluser").Rows(0).Item("LoginName"), String)
		End If
		' Check if password is Null
		If prdstUserMan.Tables("tbluser").Rows(0).IsNull("Password") Then
			prstrPassword = ""
		Else
			prstrPassword = CType(prdstUserMan.Tables("tbluser").Rows(0).Item("Password"), String)
		End If
	End Sub

	Public Sub SetUserProperties(ByVal vstrADName As Object, ByVal vguiADSID As Object, ByVal vlngId As Long, _
	 ByVal vstrLoginName As String, ByVal vstrFirstName As Object, ByVal vstrLastName As Object, _
	 ByVal vstrPassword As String)
		If vstrADName Is Nothing Then
			prstrADName = ""
		Else
			prstrADName = vstrADName.ToString
		End If

		If vstrADName.GetType.ToString = "System.DBNull" Then
			prguiADSID = Nothing
		Else
			prguiADSID = CType(vguiADSID, Guid)
		End If

		prlngId = vlngId

		If vstrADName Is Nothing Then
			prstrFirstName = ""
		Else
			prstrFirstName = vstrFirstName.ToString
		End If

		If vstrADName Is Nothing Then
			prstrLastName = ""
		Else
			prstrLastName = vstrLastName.ToString
		End If

		prstrLoginName = vstrLoginName
		prstrPassword = vstrPassword
	End Sub

	Private Sub prSetColumnMaxLength()
		Dim drdSchema As SqlDataReader
		Dim dtbSchema As DataTable

		prcmmUser.CommandType = CommandType.Text
		prcmmUser.Connection = prshcnnUserMan
		prcmmUser.CommandText = "SELECT * FROM tblUser"

		' Return data reader
		drdSchema = prcmmUser.ExecuteReader()

		' Read schema from source table
		dtbSchema = drdSchema.GetSchemaTable()

		' Save the maxlength values
		prshtADNameMaxLen = CShort(dtbSchema.Rows(1).Item(2))
		prshtFirstNameMaxLen = CShort(dtbSchema.Rows(3).Item(2))
		prshtLastNameMaxLen = CShort(dtbSchema.Rows(4).Item(2))
		prshtLoginNameMaxLen = CShort(dtbSchema.Rows(5).Item(2))
		prshtPasswordMaxLen = CShort(dtbSchema.Rows(6).Item(2))

		' Close datareader
		drdSchema.Close()
	End Sub

	Public ReadOnly Property IsDBOpen() As Boolean
		Get
			IsDBOpen = CBool(prshcnnUserMan.State And ConnectionState.Open)
		End Get
	End Property

	Public ReadOnly Property Id() As Long
		Get
			Id = prlngId
		End Get
	End Property

	Public Property ADName() As String
		Get
			ADName = prstrADName
		End Get

		Set(ByVal vstrADName As String)
			If Len(vstrADName) <= prshtADNameMaxLen Then
				prstrADName = vstrADName
			Else
				prstrADName = Left(vstrADName, prshtADNameMaxLen)
			End If
		End Set
	End Property

	Public Property ADSID() As Guid
		Get
			ADSID = prguiADSID
		End Get

		Set(ByVal vguiADSID As Guid)
			prguiADSID = vguiADSID
		End Set
	End Property

	Public Property FirstName() As String
		Get
			FirstName = prstrFirstName
		End Get

		Set(ByVal vstrFirstName As String)
			If Len(vstrFirstName) <= prshtFirstNameMaxLen Then
				prstrFirstName = vstrFirstName
			Else
				prstrFirstName = Left(vstrFirstName, prshtFirstNameMaxLen)
			End If
		End Set
	End Property

	Public Property LastName() As String
		Get
			LastName = prstrLastName
		End Get

		Set(ByVal vstrLastName As String)
			If Len(vstrLastName) <= prshtLastNameMaxLen Then
				prstrLastName = vstrLastName
			Else
				prstrLastName = Left(vstrLastName, prshtLastNameMaxLen)
			End If
		End Set
	End Property

	Public Property LoginName() As String
		Get
			LoginName = prstrLoginName
		End Get

		Set(ByVal vstrLoginName As String)
			If Len(vstrLoginName) <= prshtLoginNameMaxLen Then
				prstrLoginName = vstrLoginName
			Else
				prstrLoginName = Left(vstrLoginName, prshtLoginNameMaxLen)
			End If
		End Set
	End Property

	Public Property Password() As String
		Get
			' Return the password
			Password = prstrPassword
		End Get

		Set(ByVal vstrPassword As String)
			' Check if the length of the passed password is shorter 
			' than or equal to the max length allowed
			If Len(vstrPassword) <= prshtPasswordMaxLen Then
				' Save the password
				prstrPassword = vstrPassword
			Else
				' Throw exception
				prstrPassword = Left(vstrPassword, prshtPasswordMaxLen)
			End If
		End Set
	End Property

	Public Sub UpdateDataSource()
		prdstUserMan.Tables("tbluser").Rows(0).Item("ADName") = prstrADName
		prdstUserMan.Tables("tbluser").Rows(0).Item("FirstName") = prstrFirstName
		prdstUserMan.Tables("tbluser").Rows(0).Item("LastName") = prstrLastName
		prdstUserMan.Tables("tbluser").Rows(0).Item("LoginName") = prstrLoginName
		prdstUserMan.Tables("tbluser").Rows(0).Item("Password") = prstrPassword
		prdadUserMan.Update(prdstUserMan, "tblUser")
	End Sub
End Class