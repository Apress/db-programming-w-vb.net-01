Option Strict On
Option Explicit On 

Public Class frmProperties
	Inherits System.Windows.Forms.Form

	Private prblnAdmin As Boolean
		Friend WithEvents mnuUpdate As System.Windows.Forms.MenuItem
	Friend WithEvents mnuProperties As System.Windows.Forms.ContextMenu
		Private probjUser As CUser

#Region " Windows Form Designer generated code "

	Public Sub New(ByVal vblnAdmin As Boolean)
		MyBase.New()

		'This call is required by the Windows Form Designer.
		InitializeComponent()

		prblnAdmin = vblnAdmin

		' Is this the admin user?
		If prblnAdmin Then
			Me.Text = "Admin Properties"
			probjUser = objAdminUser
		Else
			probjUser = New CUser()
		End If

		prDisplayUserProperties()
	End Sub

	'Form overrides dispose to clean up the component list.
	Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
		If disposing Then
			If Not (components Is Nothing) Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(disposing)
	End Sub
	Friend WithEvents lblPassword As System.Windows.Forms.Label
	Friend WithEvents lblUserId As System.Windows.Forms.Label
	Friend WithEvents txtPassword As System.Windows.Forms.TextBox
	Friend WithEvents txtLoginName As System.Windows.Forms.TextBox
	Friend WithEvents txtId As System.Windows.Forms.TextBox
	Friend WithEvents lblId As System.Windows.Forms.Label
	Friend WithEvents txtADName As System.Windows.Forms.TextBox
	Friend WithEvents lblADName As System.Windows.Forms.Label
	Friend WithEvents txtLastName As System.Windows.Forms.TextBox
	Friend WithEvents lblLastName As System.Windows.Forms.Label
	Friend WithEvents txtFirstName As System.Windows.Forms.TextBox
	Friend WithEvents lblFirstName As System.Windows.Forms.Label

	'Required by the Windows Form Designer
	Private components As System.ComponentModel.Container

	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.  
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
		Me.mnuProperties = New System.Windows.Forms.ContextMenu()
		Me.mnuUpdate = New System.Windows.Forms.MenuItem()
		Me.lblUserId = New System.Windows.Forms.Label()
		Me.lblADName = New System.Windows.Forms.Label()
		Me.txtFirstName = New System.Windows.Forms.TextBox()
		Me.lblPassword = New System.Windows.Forms.Label()
		Me.txtADName = New System.Windows.Forms.TextBox()
		Me.lblId = New System.Windows.Forms.Label()
		Me.lblFirstName = New System.Windows.Forms.Label()
		Me.txtPassword = New System.Windows.Forms.TextBox()
		Me.txtId = New System.Windows.Forms.TextBox()
		Me.txtLastName = New System.Windows.Forms.TextBox()
		Me.txtLoginName = New System.Windows.Forms.TextBox()
		Me.lblLastName = New System.Windows.Forms.Label()
		Me.SuspendLayout()
		'
		'mnuProperties
		'
		Me.mnuProperties.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuUpdate})
		'
		'mnuUpdate
		'
		Me.mnuUpdate.DefaultItem = True
		Me.mnuUpdate.Index = 0
		Me.mnuUpdate.Text = "&Update"
		'
		'lblUserId
		'
		Me.lblUserId.AutoSize = True
		Me.lblUserId.Location = New System.Drawing.Point(10, 38)
		Me.lblUserId.Name = "lblUserId"
		Me.lblUserId.Size = New System.Drawing.Size(44, 13)
		Me.lblUserId.TabIndex = 4
		Me.lblUserId.Text = "&User Id:"
		'
		'lblADName
		'
		Me.lblADName.AutoSize = True
		Me.lblADName.Location = New System.Drawing.Point(244, 12)
		Me.lblADName.Name = "lblADName"
		Me.lblADName.Size = New System.Drawing.Size(56, 13)
		Me.lblADName.TabIndex = 2
		Me.lblADName.Text = "&AD Name:"
		'
		'txtFirstName
		'
		Me.txtFirstName.Location = New System.Drawing.Point(70, 56)
		Me.txtFirstName.Name = "txtFirstName"
		Me.txtFirstName.Size = New System.Drawing.Size(165, 20)
		Me.txtFirstName.TabIndex = 9
		Me.txtFirstName.Text = "txtFirstName"
		'
		'lblPassword
		'
		Me.lblPassword.AutoSize = True
		Me.lblPassword.Location = New System.Drawing.Point(244, 36)
		Me.lblPassword.Name = "lblPassword"
		Me.lblPassword.Size = New System.Drawing.Size(57, 13)
		Me.lblPassword.TabIndex = 6
		Me.lblPassword.Text = "&Password:"
		'
		'txtADName
		'
		Me.txtADName.Location = New System.Drawing.Point(304, 8)
		Me.txtADName.Name = "txtADName"
		Me.txtADName.ReadOnly = True
		Me.txtADName.Size = New System.Drawing.Size(165, 20)
		Me.txtADName.TabIndex = 3
		Me.txtADName.Text = "txtADName"
		'
		'lblId
		'
		Me.lblId.AutoSize = True
		Me.lblId.Location = New System.Drawing.Point(10, 12)
		Me.lblId.Name = "lblId"
		Me.lblId.Size = New System.Drawing.Size(17, 13)
		Me.lblId.TabIndex = 0
		Me.lblId.Text = "Id:"
		'
		'lblFirstName
		'
		Me.lblFirstName.AutoSize = True
		Me.lblFirstName.Location = New System.Drawing.Point(10, 60)
		Me.lblFirstName.Name = "lblFirstName"
		Me.lblFirstName.Size = New System.Drawing.Size(63, 13)
		Me.lblFirstName.TabIndex = 8
		Me.lblFirstName.Text = "&First Name:"
		'
		'txtPassword
		'
		Me.txtPassword.Location = New System.Drawing.Point(304, 34)
		Me.txtPassword.MaxLength = 50
		Me.txtPassword.Name = "txtPassword"
		Me.txtPassword.Size = New System.Drawing.Size(165, 20)
		Me.txtPassword.TabIndex = 7
		Me.txtPassword.Text = "txtPassword"
		'
		'txtId
		'
		Me.txtId.Location = New System.Drawing.Point(70, 8)
		Me.txtId.Name = "txtId"
		Me.txtId.ReadOnly = True
		Me.txtId.Size = New System.Drawing.Size(165, 20)
		Me.txtId.TabIndex = 1
		Me.txtId.Text = "txtId"
		'
		'txtLastName
		'
		Me.txtLastName.Location = New System.Drawing.Point(304, 56)
		Me.txtLastName.MaxLength = 50
		Me.txtLastName.Name = "txtLastName"
		Me.txtLastName.Size = New System.Drawing.Size(165, 20)
		Me.txtLastName.TabIndex = 11
		Me.txtLastName.Text = "txtLastName"
		'
		'txtLoginName
		'
		Me.txtLoginName.Location = New System.Drawing.Point(70, 34)
		Me.txtLoginName.Name = "txtLoginName"
		Me.txtLoginName.Size = New System.Drawing.Size(165, 20)
		Me.txtLoginName.TabIndex = 5
		Me.txtLoginName.Text = "txtLoginName"
		'
		'lblLastName
		'
		Me.lblLastName.AutoSize = True
		Me.lblLastName.Location = New System.Drawing.Point(244, 58)
		Me.lblLastName.Name = "lblLastName"
		Me.lblLastName.Size = New System.Drawing.Size(62, 13)
		Me.lblLastName.TabIndex = 10
		Me.lblLastName.Text = "&Last Name:"
		'
		'frmProperties
		'
		Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
		Me.ClientSize = New System.Drawing.Size(483, 89)
		Me.ContextMenu = Me.mnuProperties
		Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.txtLastName, Me.lblLastName, Me.txtFirstName, Me.lblFirstName, Me.txtADName, Me.lblADName, Me.txtId, Me.lblId, Me.lblPassword, Me.lblUserId, Me.txtPassword, Me.txtLoginName})
		Me.MaximizeBox = False
		Me.MinimizeBox = False
		Me.Name = "frmProperties"
		Me.ShowInTaskbar = False
		Me.Text = "Properties"
		Me.ResumeLayout(False)

	End Sub

#End Region

	Private Sub prDisplayUserProperties()
		txtId.Text = probjUser.Id.ToString
		txtADName.Text = probjUser.ADName
		txtLoginName.Text = probjUser.LoginName
		txtFirstName.Text = probjUser.FirstName
		txtLastName.Text = probjUser.LastName
		txtPassword.Text = probjUser.Password
	End Sub

	Private Sub prUpdateUserProperties()
		probjUser.ADName = txtADName.Text
		probjUser.LoginName = txtLoginName.Text
		probjUser.FirstName = txtFirstName.Text
		probjUser.LastName = txtLastName.Text
		probjUser.Password = txtPassword.Text
	End Sub

	Private Sub mnuUpdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuUpdate.Click
		prUpdateUserProperties()
		probjUser.UpdateDataSource()
	End Sub
End Class
